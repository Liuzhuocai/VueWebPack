import Vue from 'vue/dist/vue.runtime.esm';
import ajax from '@ul/vue-plugin-ajax';
import sjcl from '@ul/vue-plugin-sjcl';
import scroll from '@ul/vue-directive-scroll';
// import messages from '@ul/xerror/messages.esm';
import messages from './messages';

import './login-message';
import xcode from '@ul/xerror/codes'
import XError from '@ul/xerror';


//自己的代码实现
import './config';
import store from './store/store';
import router from './routers';

import ACTIONS from '../eduplatform_ui/platform-common/stores/actions/user_actions';
import user_config from '../eduplatform_ui/platform-common/configs/user_config';

import index from './mian.vue';
import {install} from './importComponents'
// import './assets/less/common.less';
import './assets/less/web.less'

XError.MESSAGES = messages;

//Vue.use(ajax,{APIBASE:CONFIG.APIBASE,prefix:CONFIG.APPID});//?????
Vue.use(sjcl);//????
Vue.use(ajax, {config: {baseURL: Vue.prototype.$CONFIG.APIBASE, timeout: 30000}, security: 1 | 2 | 4 | 8})
install(Vue);
Vue.use(scroll);


const vue = new Vue({
    el: '#app',
    router,
    store,
    render: (h) => h(index),
    catchErrors: {},
    data() {
        return {
            bannerMenus: [{
                text: '注销并关闭', ico: 'ico-logout', onClick: () => {
                    this.$showConfirm('提示', '确定要注销并关闭当前页面吗？', () => {
                        this.$store.dispatch(ACTIONS.USER_LOGOUT).then(d => {
                            window.close();
                        })
                    })
                }
            }],
            loading: false,
            loading2: false,
            errorFlag: false
        };
    },
    created() {
        let _self = this
        this.$ajax.onError = (e, config) => {
            console.log(e.message + '<br>错误接口：' + config.url, null, '提示')
            // if (_self.errorFlag) {
            //     return false
            // }
            switch (e.code) {
                case this.$XCODES.OLD_TOKEN_EXPIRED:
                case this.$XCODES.TOKEN_INVALID:
                case this.$XCODES.TOKEN_EXPIRED:
                case this.$XCODES.TOKEN_NOT_EXIST:
                    // _self.errorFlag = true
                    if (this.$options.catchErrors.relogin) return false;
                    this.$options.catchErrors.relogin = true;
                    _self.$store.dispatch(ACTIONS.USER_LOGOUT);
                    this.$showAlert(e.message, () => {
                        window.location.href = this.$CONFIG.PLATFORM;
                    }, '需要返回平台重新登录，即将关闭页面', '确定')
                    return false;
            }
        }
        this.$ajax.onSend = (data, config) => {
            console.log(data)
        }
        // this.$store.
        //     const search=querystring.parse(window.location.search.substr(1));
        //     console.log(search,'oll',window.location.search);
        // // ifdebug
        //     search.token='';//这里的token应该是后台动态给前端的
        //     // search.token=search.token.replace(/\//g,'_').replace(/\+/g,'-');
        //     //fidebug

        // if(search.token){
        //     search.token=search.token.replace(/\-/g,'+').replace(/\_/g,'/');
        //     this.$ajax.token=search.token;//
        // }

    },
    methods: {
        getMenus() {
            if (!this.$store.getters.isLoginned) {
                return [];
            }
            let menu = [
                {name: '国家学籍同步', id: 1, url: '/index', ico: 'ico-sider-synchronize'},
                {name: '未分班学生', id: 2, url: '/noclassStudent', ico: 'ico-sider-student-unknown'},
                {name: '学生查询', id: 3, url: '/studentslete', ico: 'ico-sider-student-query', line: 2},
                {name: '年级管理', id: 4, url: '/grademanagemen', ico: 'ico-sider-grade-manage'},
                {name: '班级管理', id: 5, url: '/classmanagment', ico: 'ico-sider-class-manage'},
                {name: '学生管理', id: 6, url: '/studentmanagment', ico: 'ico-sider-student-manage'},
                {name: '调班/退班', id: 7, url: '/changeshift', ico: 'ico-quitchange-manage'},
                {name: '学生绑定开关', id: 8, url: '/stuBindSwitch', ico: 'ico-sider-switch', line: 1},
                {name: '学生绑定管理', id: 9, url: '/stuBindManage', ico: 'ico-sider-linkage'},
            ]
            // switch (this.$store.state.user.UserInfo.SOURCETYPE) {
            //     case user_config.USERTYPE_SCHOOL_CAMPUS:
            //         menu.push(
            //             {name: '年级管理', id: 4, url: '/grademanagemen', ico: 'ico-sider-grade-manage'},
            //             {name: '班级管理', id: 5, url: '/classmanagment', ico: 'ico-sider-class-manage'},
            //             {name: '学生管理', id: 6, url: '/studentmanagment', ico: 'ico-sider-student-manage'},
            //             {name: '调班/退班', id: 7, url: '/changeshift', ico: 'ico-quitchange-manage'},
            //             {name: '学生绑定开关', id: 8, url: '/stuBindSwitch', ico: 'ico-sider-switch'},
            //             {name: '学生绑定管理', id: 9, url: '/stuBindManage', ico: 'ico-sider-linkage'},
            //         )
            //         break;
            // }
            menu.sort(function (a, b) {
                return a.id - b.id;
            })
            return menu;
        },
        getPermission(d) {
            if (d.token) {
                this.$ajax.token = d.token
            }
            // return [user_config.USERTYPE_BUREAU, user_config.USERTYPE_ORG, user_config.USERTYPE_SCHOOL_CAMPUS, user_config.USERTYPE_SCHOOL].indexOf(d.SOURCETYPE) > -1;
            return true;
        },
        //转换文件大小单位
        renderSize(value) {
            if (null == value || value == '') {
                return "0 KB";
            }
            var unitArr = new Array("KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB");
            var index = 0;
            var srcsize = parseFloat(value);
            index = Math.floor(Math.log(srcsize) / Math.log(1024));
            var size = srcsize / Math.pow(1024, index);
            size = size.toFixed(2);//保留的小数位数
            return size + unitArr[index];
        },
        //截取文件名去掉后缀
        splitFileName(text) {
            var pattern = /\.{1}[a-z]{1,}$/;
            if (pattern.exec(text) !== null) {
                return (text.slice(0, pattern.exec(text).index));
            } else {
                return text;
            }
        },
        getImgFileUrl(fid, localUrl) {
            if (localUrl) {
                return localUrl
            } else {
                let token = this.$ajax.token.split("+").join('-').split("/").join('_')
                return this.$CONFIG.APIBASE + '/api/file/download?token=' + token + '&fid=' + fid
            }
        },
        isImg(extension) {
            return extension == 'jpg' || extension == 'png'
        },
        getFileExtension(fileName) {
            if (fileName) return fileName.substring(fileName.lastIndexOf('.') + 1);
        },
        formatAction(action) {
            let codeList = ['新增', '修改', '删除']
            return codeList[action - 1]
        },
        formatActionStyle(action) {
            let codeList = ['font-color-orange', 'font-color-blue', 'font-color-red']
            return codeList[action - 1]
        },
        formatTime(time) {
            var date = new Date(time);
            var y = date.getFullYear();
            var m = date.getMonth() + 1;
            m = m < 10 ? ('0' + m) : m;
            var d = date.getDate();
            d = d < 10 ? ('0' + d) : d;
            var h = date.getHours();
            h = h < 10 ? ('0' + h) : h;
            var minute = date.getMinutes();
            var second = date.getSeconds();
            minute = minute < 10 ? ('0' + minute) : minute;
            second = second < 10 ? ('0' + second) : second;
            // return y + '-' + m + '-' + d + ' ' + h + ':' + minute + ':' + second;
            return y + '-' + m + '-' + d
        },
        format_EMPLOYEENAME(row) {
            return row.EMPLOYEENAME || '--'
        }
    }

});