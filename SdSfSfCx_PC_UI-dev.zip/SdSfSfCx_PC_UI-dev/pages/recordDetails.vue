<template>
    <div class="recordDetails xPage">
        <div class="watermark"></div>
        <div class="xHeadBox">
            <div class="xTitle">记录详情</div>
            <div>
                <ul-button v-if="!$store.getters.isQX&&!$store.getters.isGX&&!$route.query.isSearch" @click="deleteBtn()" class="red" :disabled="loading">删除</ul-button>
                <ul-button v-if="!$store.getters.isQX&&!$store.getters.isGX&&!$route.query.isSearch" @click="$router.push({path: '/recordAddEdit',query:{edit:true,id:$route.query.id,bcode:params.bcode}})">修改
                </ul-button>
                <ul-button @click="$router.back()" class="">返回</ul-button>
            </div>
        </div>
        <div class="mainBox" v-preloader:show.loading.delay="loading">
            <div class="statusBox">
                <div class="statusItem">{{action.organize}}<span class="font-color-gray"> 于 </span>{{$root.formatTime(action.rtime)}} <span class="font-color-gray"> 更新</span></div>
                <div class="statusItem font-color-red" v-if="params.hidden==2">该条记录已被 四川省教育厅 设置为“隐藏”，在查询中将不会显示，若有疑问，请与 四川省教育厅 联系</div>
            </div>
            <div class="contentBox">
                <div class="contentLeft">
                    <div class="label">失范教师</div>
                    <div class="contentLeftItem">
                        <span class="inlineLabel">学校所在地</span>
                        <span class="value">{{params.bcode_n}}</span>
                    </div>
                    <div class="contentLeftItem">
                        <span class="inlineLabel">学校名称</span>
                        <span class="value">{{params.sname}}</span>
                    </div>
                    <div class="contentLeftItem">
                        <span class="inlineLabel">姓名</span>
                        <span class="value">{{params.uname}}</span>
                    </div>
                    <div class="contentLeftItem">
                        <span class="inlineLabel">性别</span>
                        <span class="value">{{params.gender_n}}</span>
                    </div>
                    <div class="contentLeftItem">
                        <span class="inlineLabel">身份证件号</span>
                        <span class="value">{{params.idcard}}</span>
                    </div>
                    <div class="contentLeftItem">
                        <span class="inlineLabel">政治面貌</span>
                        <span class="value">{{params.zzmmid_n}}</span>
                    </div>
                    <div class="contentLeftItem">
                        <span class="inlineLabel">职务职称</span>
                        <span class="value">{{params.duty}}</span>
                    </div>
                </div>
                <div style="width:1px;flex-shrink:0;background:#ededf0;"></div>
                <div class="contentRight">
                    <div class="contentRightItem">
                        <div class="label">失范行为</div>
                        <div class="contentRightItemSubitem">
                            <span class="inlineLabel">具体内容</span>
                            <span class="inlineValue">{{params.descp}}</span>
                        </div>
                    </div>
                    <div class="contentRightItem">
                        <div class="label">处理单位</div>
                        <div class="contentRightItemSubitem">
                            <span class="inlineLabel">单位名称</span>
                            <span class="inlineValue">{{params.dispose_org}}</span>
                        </div>
                    </div>
                    <div class="contentRightItem">
                        <div class="label">处理情况</div>
                        <div class="valueBox">
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">依据</span>
                                <span class="inlineValue">{{params.dispose_yj}}</span>
                            </div>
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">类型</span>
                                <span class="inlineValue">{{params.dispose_lb_n}}</span>
                            </div>
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">结论</span>
                                <span class="inlineValue">{{params.dispose_jl}}</span>
                            </div>
                        </div>
                    </div>
                    <div class="contentRightItem">
                        <div class="label">结果适用</div>
                        <div class="valueBox">
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">类别</span>
                                <span class="inlineValue">{{params.result_lb}}</span>
                            </div>
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">开始时间</span>
                                <span class="inlineValue">{{$root.formatTime(params.result_s)}}</span>
                            </div>
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">终止时间</span>
                                <span class="inlineValue">{{$root.formatTime(params.result_e)}}</span>
                            </div>
                        </div>
                    </div>
                    <div class="contentRightItem" v-if="$store.getters.isST||params.oid==$store.state.user.UserInfo.oid">
                        <div class="label">附件</div>
                        <div style="color:#b2b2b2" v-if="params.files&&!Object.keys(params.files).length">无</div>
                        <div style="display:flex;flex-wrap:wrap;margin-left:4px;">
                            <div class="fileCardBox" v-for="item in params.files" v-loading="downloadLoading[item.fid]">
                                <i v-show="!$root.isImg($root.getFileExtension(item.name))" class="fileCardLeft ico attach_other_file_icon"
                                   :class="$root.getFileExtension(item.name)"></i>
                                <img v-if="$root.isImg($root.getFileExtension(item.name))" class="fileCardLeft" :src="$root.getImgFileUrl(item.fid)" alt="加载失败" @click="previewFile(item.fid)">
                                <image-viewer :visible="showImgViewer" @close="showImgViewer=false" :url="ImgViewerUrl"></image-viewer>
                                <div class="fileCardRight">
                                    <div class="fileCardRightTop">{{item.name}}</div>
                                    <div class="fileCardRightBottom flex-justify-sb">
                                        <span class="fileCardSize">{{$root.renderSize(item.bufferlimit)}}</span>
                                        <span>
                                        <ul-button v-show="$root.isImg($root.getFileExtension(item.name))" @click="previewFile(item.fid)">预览</ul-button>
                                        <ul-button @click="downloadFile(item)">下载</ul-button>
                                    </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="contentRightItem" v-if="$store.getters.isST||params.oid==$store.state.user.UserInfo.oid">
                        <div class="label">录入人</div>
                        <div class="valueBox">
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">姓名</span>
                                <span class="inlineValue">{{params.enter_name}}</span>
                            </div>
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">电话</span>
                                <span class="inlineValue">{{params.enter_phone}}</span>
                            </div>
                        </div>
                    </div>
                    <div class="contentRightItem" v-if="$store.getters.isST||params.oid==$store.state.user.UserInfo.oid">
                        <div class="label">审核人</div>
                        <div class="valueBox">
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">姓名</span>
                                <span class="inlineValue">{{params.check_name}}</span>
                            </div>
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">电话</span>
                                <span class="inlineValue">{{params.check_phone}}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <popup ref="popup" @popup:block="$refs.popup.hide()" :destory-on-hide="false">
            <dialogs footer :toolbar="false" column title="删除记录？" height="340px" width="440px" @ok="deleteOk" @cancel="$refs.popup.hide()">
                <forms :label-width="100" msgPosition="bottom" ref="forms">
                    <inputs name="reason" label="删除原因" required v-model="reason" type="textarea" width="100%;"></inputs>
                </forms>
            </dialogs>
        </popup>
        <a ref="downloadBtn" v-show="false"></a>
    </div>
</template>

<script>
    import ImageViewer from '../components/ImageViewer'

    export default {
        name: "recordDetails",
        components: {ImageViewer},
        data() {
            return {
                params: {},
                loading: false,
                action: [],
                reason: '',
                showImgViewer: false,
                ImgViewerUrl: '',
                downloadLoading: {}
            };
        },
        computed: {},
        watch: {},
        created() {
        },
        mounted() {
            this.getData()
        },
        methods: {
            previewFile(fid) {
                this.ImgViewerUrl = this.$root.getImgFileUrl(fid)
                this.showImgViewer = true
            },
            downloadFile(item) {
                this.$set(this.downloadLoading, item.fid, true)
                this.$ajax.get('/api/file/download?token=' + this.$ajax.token + '&fid=' + item.fid, null, {responseType: 'blob'}).then(d => {
                    let blob = d;
                    this.$refs.downloadBtn.href = window.URL.createObjectURL(blob);
                    this.$refs.downloadBtn.download = item.name;
                    this.$refs.downloadBtn.click();
                    window.URL.revokeObjectURL(this.$refs.downloadBtn.href);
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.$set(this.downloadLoading, item.fid, false)
                })
            },
            getData() {
                this.loading = true
                this.$ajax.post('/api/record/detial', {rid: this.$route.query.id}).then(d => {
                    console.log(d)
                    this.action = d.actions[0]
                    this.params = d.record
                    if (d.record.hidden == 2) {
                        this.$showAlert('<div>该条记录已被 <span>四川省教育厅</span> 设置为“<span class="color-red">隐藏</span>”，在查询中将不会显示</div><br><div>若有疑问，请与 <span>四川省教育厅</span> 联系</div>', null, '注意')
                    }
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.loading = false
                })
            },
            deleteBtn() {
                this.$refs.popup.show()
            },
            deleteOk() {
                if (!this.$refs.forms.validate()) {
                    let msg = this.$refs.forms.msgs[0]
                    this.$showAlert('错误项' + '：' + msg.label + '<br>错误提示：' + msg.msg, null, '填写信息有误')
                    return
                }
                this.$ajax.post('/api/record/edit', {rid: this.$route.query.id, etype: 2, reason: this.reason}).then(d => {
                    this.$showToast('提交成功')
                    this.$router.back()
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.$refs.popup.hide()
                })
            },

        }
    }
</script>

<style lang="less">
    .recordDetails {
        .statusBox {
            background-color: #fff;
            border-radius: 8px;
            padding: 10px 20px;
            box-sizing: border-box;
            margin-bottom: 20px;
            font-size: 14px;

            .statusItem {
                color: #333;
                line-height: 24px;
                font-size: 14px;
                padding: 6px 0;
                box-sizing: border-box;
            }
        }

        .contentBox {
            display: flex;
            box-sizing: border-box;
            font-size: 14px;
            color: #333;

            .label {
                height: 50px;
                line-height: 50px;
                font-size: 15px;
                color: #405580;
                font-weight: bold;
            }

            .inlineLabel {
                display: inline-block;
                width: 110px;
                color: #b3b3b3;
                flex-shrink: 0;
            }

            .contentLeft {
                flex-shrink: 0;
                padding: 0 20px;

                .contentLeftItem {
                    line-height: 24px;
                    padding-top: 13px;
                    padding-bottom: 13px;
                    box-sizing: border-box;
                    display: flex;
                    justify-content: flex-start;

                    .value {
                        display: inline-block;
                        width: 220px;
                    }
                }
            }

            .contentRight {
                flex-grow: 1;
                width: 1px;
                padding: 0 20px;

                .contentRightItem {
                    margin-bottom: 40px;
                    border-top: solid 1px #ededf0;

                    &:first-child {
                        border-top: unset;
                    }

                    .valueBox {
                        margin-left: 4px;
                    }

                    .contentRightItemSubitem {
                        line-height: 24px;
                        padding-top: 13px;
                        padding-bottom: 13px;
                        box-sizing: border-box;
                        display: flex;
                        justify-content: flex-start;
                    }
                }
            }
        }
    }
</style>