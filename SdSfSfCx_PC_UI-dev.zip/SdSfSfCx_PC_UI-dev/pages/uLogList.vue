<template>
    <div class="uLogList xPage">
        <div class="watermark"></div>
        <div class="xHeadBox">
            <div>
                <span class="xTitle font-color-yellow">操作日志</span>
            </div>
            <div>
                <ul-button @click="$router.back()">返回</ul-button>
            </div>
        </div>
        <div class="mainBox" v-preloader:show.loading.delay="loading">
            <div style="height:400px;display:flex;align-items:center;justify-content:center;" v-show="!logList||(logList&&!Object.keys(logList).length)">
                暂无数据。
            </div>
            <div class="logItemOverBox" v-for="item,index in logList">
                <div class="logItemDate">{{index}}</div>
                <div class="logItem" v-for="i in item.list" @click="$router.push({path: '/logDetails',query:{id:i.id}})">
                    <span>{{i.time}} </span><span> {{i.organize}} </span><span :class="$root.formatActionStyle(i.action)"> {{$root.formatAction(i.action)}} </span>
                    <span>{{i.sname}}</span>-<span>{{i.uname}}</span> 的 失范记录
                </div>
            </div>
        </div>
        <div class="footBox">
            <pagination :total="total" @change="getData" ref="pager" :page="currentPage" :pageOfCount="limit"></pagination>
        </div>
    </div>
</template>

<script>
    export default {
        name: "uLogList",
        data() {
            return {
                logList: {},
                total: 0,
                currentPage: 1,
                loading: false,
                limit: 20
            };
        },
        computed: {},
        watch: {},
        created() {
            this.getData()
        },
        mounted() {
        },
        methods: {
            getData(page) {
                page = page || 1
                this.loading = true
                this.$ajax.post('/api/actions/alist', {pageNo: page, limit: this.limit}).then(d => {
                    let logList = {}
                    for (let i of d.data) {
                        i.date = this.formatDate(i.rtime)
                        i.time = this.formatTime(i.rtime)
                        if (!logList[i.date]) {
                            logList[i.date] = {}
                            logList[i.date].list = []
                        }
                        logList[i.date].list.push(i)
                    }
                    this.currentPage = page
                    this.total = parseInt(d.total)
                    this.logList = logList
                    console.log(this.logList)
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.loading = false
                    // this.$hidePreloader();
                })
            },
            formatDate(time) {
                var date = new Date(time);
                var y = date.getFullYear();
                var m = date.getMonth() + 1;
                m = m < 10 ? ('0' + m) : m;
                var d = date.getDate();
                d = d < 10 ? ('0' + d) : d;
                var h = date.getHours();
                h = h < 10 ? ('0' + h) : h;
                var minute = date.getMinutes();
                var second = date.getSeconds();
                minute = minute < 10 ? ('0' + minute) : minute;
                second = second < 10 ? ('0' + second) : second;
                return y + '-' + m + '-' + d
            },
            formatTime(time) {
                var date = new Date(time);
                var y = date.getFullYear();
                var m = date.getMonth() + 1;
                m = m < 10 ? ('0' + m) : m;
                var d = date.getDate();
                d = d < 10 ? ('0' + d) : d;
                var h = date.getHours();
                h = h < 10 ? ('0' + h) : h;
                var minute = date.getMinutes();
                var second = date.getSeconds();
                minute = minute < 10 ? ('0' + minute) : minute;
                second = second < 10 ? ('0' + second) : second;
                return h + ':' + minute + ':' + second;
            }
        }
    }
</script>

<style lang="less">
    .uLogList {
        .mainBox {
            .logItemOverBox {
                .logItemDate {
                    font-size: 14px;
                    color: #808080;
                    padding-left: 5px;
                    box-sizing: border-box;
                    height: 24px;
                    line-height: 24px;
                    margin-top: 15px;
                    margin-bottom: 6px;
                }

                .logItem {
                    height: 40px;
                    line-height: 40px;
                    border-radius: 5px;
                    padding: 0 12px;
                    box-sizing: border-box;
                    cursor: pointer;
                    font-size: 12px;
                    color: #333;

                    &:hover {
                        background-color: #ededf0;
                    }
                }
            }
        }
    }
</style>