<template>
    <div class="indexPage">
        <div class="watermark"></div>
        <div class="mainItem searchItem">
            <div class="searchItemTop">
                四川省教师违反职业道德信息查询系统
            </div>
            <div class="searchItemBottom">
                <div @keyup.13="handleSearch" class="searchStyle">
                    <input type="text" class="searchInputStyle" v-model.trim="searchValue" placeholder="姓名\身份证件号"/>
                    <span class="searchBtn" @click="handleSearch">查询</span>
                </div>
                <button v-if="$store.getters.isST" class="searchManageBtn" @click="$router.push({path: '/searchManage'})">查询管理</button>
            </div>
        </div>
        <div class="mainItem recordItem" v-if="!$store.getters.isQX&&!$store.getters.isGX">
            <div class="titleBox">
                <div class="titleText">我单位录入的失范记录<span class="titleTips">(不含已删除的记录)</span></div>
                <button class="addBtn" @click="$router.push({path: '/recordAddEdit'})">新增</button>
            </div>
            <div class="contentBox" v-preloader:show.loading.delay="recordItemLoading">
                <div style="height:100px;width:100%;display:flex;align-items:center;justify-content:center;" v-show="!Object.keys(recordList).length">
                    <div>暂无数据</div>
                </div>
                <div class="cardBox">
                    <div class="card" v-for="item in recordList.slice(0,3)" @click="$router.push({path: '/recordDetails',query:{id:item.rid}})">
                        <div>
                            <div class="cardTitle">{{item.uname}}</div>
                            <div class="cardText">{{item.sname}}</div>
                        </div>
                        <div class="cardBottom"><span class="cardTAG">{{item.dispose_lb_n}}</span><span class="cardTime">{{$root.formatTime(item.edit_time)}}</span></div>
                    </div>
                </div>
                <button class="showAllBtn" @click="$router.push({path: '/recordList'})" style="position:absolute;bottom:0;right:0;">查看所有</button>
            </div>
        </div>
        <div class="mainItem logItemBox" v-if="!$store.getters.isQX&&!$store.getters.isGX">
            <div class="titleBox">
                <div class="titleText">操作日志</div>
                <button class="showAllBtn" @click="$router.push({path: '/uLogList'})">查看所有</button>
            </div>
            <div class="contentBox" v-preloader:show.loading.delay="logItemLoading">
                <div class="logItemOverBox" style="height:100px;display:flex;align-items:center;justify-content:center;" v-show="!Object.keys(logList).length">
                    <div>暂无数据</div>
                </div>
                <div class="logItemOverBox" v-for="item,index in logList">
                    <div class="logItemDate">{{index}}</div>
                    <div class="logItem" v-for="i in item.list" @click="$router.push({path: '/logDetails',query:{id:i.id}})">
                        <span>{{i.time}} </span><span> {{i.organize}} </span><span :class="$root.formatActionStyle(i.action)"> {{$root.formatAction(i.action)}} </span>
                        <span>{{i.sname}}</span>-<span>{{i.uname}}</span> 的 失范记录
                    </div>
                </div>
            </div>
        </div>
        <div class="mainItem logItemBox searchlogItemBox">
            <div class="titleBox">
                <div class="titleText">查询日志</div>
                <button class="showAllBtn" @click="$router.push({path: '/searchLogList'})">查看所有</button>
            </div>
            <div class="contentBox" v-preloader:show.loading.delay="searchLogItemLoading">
                <div class="logItemOverBox" style="height:100px;display:flex;align-items:center;justify-content:center;" v-show="!Object.keys(searchLogList).length">
                    <div>暂无数据</div>
                </div>
                <div class="logItemOverBox" v-for="item,index in searchLogList">
                    <div class="logItemDate">{{index}}</div>
                    <div class="logItem" v-for="i in item.list">
                        <span>{{i.time}} </span><span> {{i.organize}} </span><span> {{i.name}} </span><span class="font-color-gray">通过条件</span><span> {{'“'+i.search+'”'}} </span>
                        <span class="font-color-gray">查询到</span><span> {{i.replength}} </span><span class="font-color-gray">条失范记录</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    // import bc_mixin from "../../eduplatform_ui/platform-common/mixins/breadcrumb_mixin";
    export default {
        name: "index",
        // mixins: [bc_mixin],
        // components: {popup, totast},
        data() {
            return {
                searchValue: '',
                recordList: [],
                logList: [],
                searchLogList: [],
                recordItemLoading: [],
                logItemLoading: [],
                searchLogItemLoading: [],
            };
        },
        computed: {},
        watch: {},
        created() {
            if (!this.$store.getters.isLoginned) {
                this.$root.$on('login:success', () => {
                    this.init();
                })
            } else {
                this.init();
            }
        },
        mounted() {
            console.log(this.$store.getters.isGX)
        },
        methods: {
            init() {
                this.recordItemLoading = true
                this.$ajax.post('/api/record/rlist', {search: this.searchValue, mylist: 1}).then(d => {
                    this.recordList = d.data
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.recordItemLoading = false
                    // this.$hidePreloader();
                })
                this.logItemLoading = true
                this.$ajax.post('/api/actions/alist', {pageNo: 1, limit: 5}).then(d => {
                    let logList = {}
                    for (let i of d.data) {
                        i.date = this.formatDate(i.rtime)
                        i.time = this.formatTime(i.rtime)
                        if (!logList[i.date]) {
                            logList[i.date] = {}
                            logList[i.date].list = []
                        }
                        logList[i.date].list.push(i)
                    }
                    this.logList = logList
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.logItemLoading = false
                    // this.$hidePreloader();
                })
                this.searchLogItemLoading = true
                this.$ajax.post('/api/search/slist', {pageNo: 1, limit: 5}).then(d => {
                    let searchLogList = {}
                    for (let i of d.data) {
                        i.date = this.formatDate(i.search_time)
                        i.time = this.formatTime(i.search_time)
                        if (!searchLogList[i.date]) {
                            searchLogList[i.date] = {}
                            searchLogList[i.date].list = []
                        }
                        searchLogList[i.date].list.push(i)
                    }
                    this.searchLogList = searchLogList
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.searchLogItemLoading = false
                    // this.$hidePreloader();
                })
            },
            handleSearch() {
                this.$router.push({
                    path: "/searchResult",
                    query: {searchValue: this.searchValue}
                });
            },
            formatDate(time) {
                var date = new Date(time);
                var y = date.getFullYear();
                var m = date.getMonth() + 1;
                m = m < 10 ? ('0' + m) : m;
                var d = date.getDate();
                d = d < 10 ? ('0' + d) : d;
                var h = date.getHours();
                h = h < 10 ? ('0' + h) : h;
                var minute = date.getMinutes();
                var second = date.getSeconds();
                minute = minute < 10 ? ('0' + minute) : minute;
                second = second < 10 ? ('0' + second) : second;
                return y + '-' + m + '-' + d
            },
            formatTime(time) {
                var date = new Date(time);
                var y = date.getFullYear();
                var m = date.getMonth() + 1;
                m = m < 10 ? ('0' + m) : m;
                var d = date.getDate();
                d = d < 10 ? ('0' + d) : d;
                var h = date.getHours();
                h = h < 10 ? ('0' + h) : h;
                var minute = date.getMinutes();
                var second = date.getSeconds();
                minute = minute < 10 ? ('0' + minute) : minute;
                second = second < 10 ? ('0' + second) : second;
                return h + ':' + minute + ':' + second;
            }
        }
    };
</script>

<style lang="less">
    .indexPage {
        .titleBox {
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 40px;
            line-height: 40px;

            .titleText {
                font-size: 17px;
                font-weight: bold;
                color: #6b7a99;
            }

            .titleTips {
                margin-left: 10px;
                font-size: 12px;
                font-weight: bold;
                color: #6b7a99;
            }
        }

        .addBtn {
            color: #fff;
            background: #ff6a00;
            width: 80px;
            height: 40px;
            line-height: 40px;
            border-radius: 5px;
            font-weight: bold;
            font-size: 15px;
            cursor: pointer;
        }

        .showAllBtn {
            color: #0080ff;
            background: transparent;
            height: 20px;
            line-height: 20px;
            font-weight: bolder;
            font-size: 15px;
            cursor: pointer;
            margin-right: 5px;
        }

        .mainItem {
            background: #FAFAFA;
            border-radius: 10px;
            margin: 15px 0;
            padding: 25px 30px;
            box-sizing: border-box;
        }

        .searchItem {
            text-align: center;

            .searchItemTop {
                height: 220px;
                line-height: 220px;
                font-size: 40px;
                font-weight: bold;
                color: #4b5873;
            }

            .searchItemBottom {
                height: 200px;
                position: relative;

                .searchManageBtn {
                    position: absolute;
                    bottom: 0;
                    right: 0;
                    color: #0080ff;
                    background: transparent;
                    height: 20px;
                    line-height: 20px;
                    font-weight: bolder;
                    font-size: 15px;
                    margin-right: 5px;
                    cursor: pointer;
                }
            }

            .searchStyle {
                display: flex;
                justify-content: center;

                .searchInputStyle {
                    font-size: 16px;
                    width: 510px;
                    height: 60px;
                    outline: none;
                    padding-left: 30px;
                    box-sizing: border-box;
                    border-top-left-radius: 50px;
                    border-bottom-left-radius: 50px;
                    background-color: #EDECF1;
                }

                .searchBtn {
                    display: inline-block;
                    width: 100px;
                    height: 60px;
                    line-height: 60px;
                    border-top-right-radius: 50px;
                    border-bottom-right-radius: 50px;
                    border-top-left-radius: 8px;
                    border-bottom-left-radius: 8px;
                    background-color: #0080FF;
                    color: #fff;
                    cursor: pointer;
                    font-weight: bold;
                    font-size: 17px;
                }
            }


        }

        .recordItem {
            .contentBox {
                display: flex;
                align-items: flex-end;
                justify-content: space-between;
                position: relative;
                margin-top: 10px;

                .cardBox {
                    display: flex;

                    .card {
                        width: 250px;
                        height: 120px;
                        margin-right: 10px;
                        border-radius: 8px;
                        background-color: #fff;
                        padding: 10px 15px;
                        box-sizing: border-box;
                        cursor: pointer;
                        box-shadow: 0px 2px 6px #f2f2f2;
                        display: flex;
                        flex-direction: column;
                        justify-content: space-between;

                        &:hover {
                            box-shadow: 0px 4px 10px #e5e5e5;
                        }

                        .cardTitle {
                            height: 30px;
                            line-height: 30px;
                            color: #595959;
                            font-size: 18px;
                            font-weight: bold;
                        }

                        .cardText {
                            margin-top: 4px;
                            line-height: 20px;
                            color: #4c4c4c;
                            font-size: 14px;
                            display: -webkit-box;
                            overflow: hidden;
                            -webkit-box-orient: vertical;
                            text-overflow: ellipsis;
                            -webkit-line-clamp: 2;
                        }

                        .cardBottom {
                            display: flex;
                            justify-content: space-between;

                            .cardTAG {
                                color: #ff6a00;
                                font-size: 14px;
                            }

                            .cardTime {
                                color: #b2b2b2;
                                font-size: 12px;
                            }
                        }

                    }
                }

            }

        }

        .logItemBox {
            .logItemOverBox {
                .logItemDate {
                    font-size: 14px;
                    color: #808080;
                    padding-left: 5px;
                    box-sizing: border-box;
                    height: 24px;
                    line-height: 24px;
                    margin-top: 15px;
                    margin-bottom: 6px;
                }

                .logItem {
                    height: 40px;
                    line-height: 40px;
                    border-radius: 5px;
                    padding: 0 12px;
                    box-sizing: border-box;
                    cursor: pointer;
                    font-size: 12px;
                    color: #333;

                    &:hover {
                        background-color: #ededf0;
                    }
                }
            }
        }

        .searchlogItemBox {
            .logItem {
                cursor: unset !important;
            }
        }
    }
</style>