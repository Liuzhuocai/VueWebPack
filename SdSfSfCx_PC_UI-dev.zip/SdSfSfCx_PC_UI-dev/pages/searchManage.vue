<template>
    <div class="xPage searchManage">
        <div class="watermark"></div>
        <div class="xHeadBox">
            <div>
                <span class="xTitle">查询管理</span>
                <span class="xLittleVerticalLine">|</span>
                <span>共{{total}}条记录</span>
            </div>
            <div @keyup.13="handleSearch" class="searchStyle">
                <input type="text" class="searchInputStyle" v-model.trim="searchValue" placeholder="请输入姓名\身份证件号"/>
                <span class="searchBtn" @click="handleSearch">查询</span>
            </div>
            <div>
                <!--                <ul-button @click="exportBtn" style="margin-right:10px;">导出</ul-button>-->
                <ul-button @click="$router.back()">返回</ul-button>
            </div>
        </div>
        <div class="mainBox" v-preloader:show.loading.delay="loading">
            <div style="height:400px;display:flex;align-items:center;justify-content:center;" v-show="!recordList||(recordList&&!recordList.length)">
                暂无数据。
            </div>
            <div class="xCard" v-for="item in recordList" @click.stop="$router.push({path: '/recordDetails',query: {id: item.rid}})">
                <div class="xCardTitle">
                    <span><span class="xCardUname">{{item.uname}}</span><span class="xCardLittleTransverseLine">-</span><span class="xCardSname">{{item.sname}}</span></span>
                    <span class="xCardTips">录入单位：{{item.edit_organize}}</span>
                </div>
                <div class="xCardTag">{{item.dispose_lb_n}}</div>
                <div class="xCardTextBox">
                    <div class="xCardTextBoxLeft">
                        <div class="xCardText"><i class="ico card_ID_icon"></i>{{item.idcard}}</div>
                        <div class="xCardText"><i class="ico card_local_icon"></i>{{item.bcode_n}}</div>
                        <div class="xCardText"><i class="ico card_bio_icon"></i>{{item.zzmmid_n+' '+item.duty+' '+item.gender_n}}</div>
                        <div class="xCardText"><i class="ico card_timel_icon"></i>{{$root.formatTime(item.edit_time)}}</div>
                    </div>
                    <div class="xCardTextBoxRight">
                        {{item.descp}}
                    </div>
                </div>
                <div class="xCardFoot" @click.stop>
                    <span v-show="item.hidden==2" class="font-color-red" style="margin-right:15px;">该条记录已隐藏，在查询中不会显示</span>
                    <div style="margin-top:1px;">
                        <el-radio v-model="item.hidden" :label="1" @change="setHidden(item,1)">查询开放</el-radio>
                        <el-radio v-model="item.hidden" :label="2" @change="setHidden(item,2)">查询隐藏</el-radio>
                    </div>
                </div>
            </div>
        </div>
        <div class="footBox">
            <pagination :total="total" @change="getData" ref="pager" :page="currentPage" :pageOfCount="limit"></pagination>
        </div>
    </div>
</template>

<script>
    // import bc_mixin from "../../eduplatform_ui/platform-common/mixins/breadcrumb_mixin";
    export default {
        name: "searchManage",
        // mixins: [bc_mixin],
        // components: {popup, totast},
        data() {
            return {
                searchValue: '',
                recordList: [],
                total: 0,
                currentPage: 1,
                loading: false,
                limit: 20,
                hiden: 2,
            };
        },
        computed: {},
        watch: {},
        created() {
        },
        mounted() {
            this.getData()
        },
        methods: {
            getData(page) {
                page = page || 1
                // this.$showPreloader('加载中...');
                this.loading = true
                this.$ajax.post('/api/record/rlist', {pageNo: page, search: this.searchValue, limit: this.limit, all: 1}).then(d => {
                    this.currentPage = page
                    this.total = parseInt(d.total)
                    this.recordList = d.data
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.loading = false
                    // this.$hidePreloader();
                })
            },
            setHidden(item, v) {
                this.$ajax.post('/api/record/edit', {rid: item.rid, etype: 3, hidden: v}).then(d => {
                    this.$showToast('设置成功')
                    this.getData()
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.loading = false
                })
            },
            handleSearch() {
                this.getData()
            },
            handlePageChange() {

            },
            exportBtn() {

            },
            resultItemClk(item) {
            }
        }
    };
</script>

<style lang="less">
    .searchManage {
        .xHeadBox {
            .searchStyle {
                display: flex;
                justify-content: center;

                .searchInputStyle {
                    width: 300px;
                    height: 40px;
                    outline: none;
                    padding-left: 20px;
                    box-sizing: border-box;
                    border-top-left-radius: 50px;
                    border-bottom-left-radius: 50px;
                    background-color: #EDECF1;
                }

                .searchBtn {
                    display: inline-block;
                    width: 100px;
                    height: 40px;
                    line-height: 40px;
                    border-top-right-radius: 50px;
                    border-bottom-right-radius: 50px;
                    border-top-left-radius: 8px;
                    border-bottom-left-radius: 8px;
                    background-color: #0080FF;
                    color: #fff;
                    cursor: pointer;
                    font-weight: bold;
                    font-size: 15px;
                    text-align: center;
                }
            }
        }

        .mainBox {
            .xCard {
                .xCardFoot {
                    display: flex;
                    justify-content: flex-end;
                    margin-top: 10px;
                }
            }
        }
    }
</style>