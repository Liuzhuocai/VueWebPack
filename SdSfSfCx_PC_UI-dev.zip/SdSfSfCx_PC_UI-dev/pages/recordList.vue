<template>
    <div class="xPage recordList">
        <div class="watermark"></div>
        <div class="xHeadBox">
            <div>
                <span class="xTitle">我单位录入的失范记录</span>
                <span class="xLittleVerticalLine">|</span>
                <span>不含已删除的记录，共{{total}}条记录</span>
            </div>
            <div>
                <ul-button @click="exportExcel" style="margin-right:10px;">导出</ul-button>
                <a ref="exportBtn" v-show="false"></a>
                <ul-button @click="$router.back()">返回</ul-button>
            </div>
        </div>
        <div class="mainBox" v-preloader:show.loading.delay="loading">
            <div style="height:400px;display:flex;align-items:center;justify-content:center;" v-show="!recordList||(recordList&&!recordList.length)">
                暂无数据。
            </div>
            <div class="xCard" v-for="item in recordList" @click="$router.push({path: '/recordDetails',query: {id: item.rid}})">
                <div class="xCardTitle">
                    <span><span class="xCardUname">{{item.uname}}</span><span class="xCardLittleTransverseLine">-</span><span class="xCardSname">{{item.sname}}</span></span>
                    <span class="xCardTips">录入单位：{{item.edit_organize}}</span>
                </div>
                <div class="xCardTag">{{item.dispose_lb_n}}</div>
                <div class="xCardTextBox">
                    <div class="xCardTextBoxLeft">
                        <div class="xCardText"><i class="ico card_ID_icon"></i>{{item.idcard}}</div>
                        <div class="xCardText"><i class="ico card_local_icon"></i>{{item.bcode_n}}</div>
                        <div class="xCardText"><i class="ico card_bio_icon"></i>{{item.zzmmid_n+' '+item.duty+' '+item.gender_n}}</div>
                        <div class="xCardText"><i class="ico card_timel_icon"></i>{{$root.formatTime(item.edit_time)}}</div>
                    </div>
                    <div class="xCardTextBoxRight">
                        {{item.descp}}
                    </div>
                </div>
            </div>
        </div>
        <div class="footBox">
            <pagination :total="total" @change="getData" ref="pager" :page="currentPage" :pageOfCount="limit"></pagination>
        </div>
    </div>
</template>

<script>
    // import bc_mixin from "../../eduplatform_ui/platform-common/mixins/breadcrumb_mixin";
    // import Excel from '../assets/js/exceljs.min'

    export default {
        name: "recordList",
        // mixins: [bc_mixin],
        // components: {popup, totast},
        data() {
            return {
                searchValue: '',
                recordList: [],
                total: 0,
                currentPage: 1,
                loading: false,
                limit: 20,

            };
        },
        computed: {},
        watch: {},
        created() {
        },
        mounted() {
            this.getData()
        },
        methods: {
            handleSearch() {

            },
            getData(page) {
                page = page || 1
                this.loading = true
                this.$ajax.post('/api/record/rlist', {pageNo: page, limit: this.limit, mylist: 1}).then(d => {
                    // for (let i = 0; i < 20; i++) {
                    //     d.data.push(d.data[0])
                    // }
                    this.currentPage = page
                    this.total = parseInt(d.total)
                    this.recordList = d.data
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.loading = false
                })
            },
            exportExcel() {
                this.$showPreloader(null, 'loading')
                this.$ajax.post('/api/record/rlist', {mylist: 1}).then(d => {
                    let exportsRecordList = []
                    exportsRecordList = d.data
                    let workbook = new window.ExcelJS.Workbook()
                    workbook.creator = 'test'
                    workbook.lastModifiedBy = 'test'
                    workbook.created = new Date()
                    workbook.modified = new Date()
                    let worksheet = workbook.addWorksheet('我单位录入的失范记录表')
                    worksheet.columns = [
                        {header: '区域名称', key: 'bcode_n'},
                        {header: '姓名', key: 'uname'},
                        {header: '性别', key: 'gender_n'},
                        {header: '处罚类别', key: 'dispose_lb_n'},
                        {header: '职务职称', key: 'duty'},
                        {header: '记录所属机构名称', key: 'edit_organize'},
                        {header: '编辑时间', key: 'edit_time'},
                        {header: '证件号', key: 'idcard'},
                        {header: '所属机构', key: 'sname'},
                        {header: '政治面貌', key: 'zzmmid_n'},
                    ]
                    worksheet.addRows(exportsRecordList)
                    workbook.xlsx.writeBuffer().then(buf => {
                        let blob = new Blob([buf], {type: "application/octet-stream"});
                        let fName = '我单位录入的失范记录表'
                        fName += '.xlsx'
                        this.$hidePreloader();
                        this.$refs.exportBtn.href = window.URL.createObjectURL(blob);
                        this.$refs.exportBtn.download = fName;
                        this.$refs.exportBtn.click();
                        window.URL.revokeObjectURL(this.$refs.exportBtn.href);
                    })
                }).catch(e => {
                    if (!e) return
                    this.$hidePreloader();
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                })
            },
            resultItemClk(item) {
                this.$router.push({
                    path: "/recordDetails",
                    query: {id: item.id}
                });
            }
        }
    };
</script>

<style lang="less">
    .recordList {
        .xHeadBox {
            .searchStyle {
                display: flex;
                justify-content: center;

                .searchInputStyle {
                    width: 300px;
                    height: 40px;
                    outline: none;
                    padding-left: 20px;
                    box-sizing: border-box;
                    border-top-left-radius: 50px;
                    border-bottom-left-radius: 50px;
                    background-color: #EDECF1;
                }

                .searchBtn {
                    display: inline-block;
                    width: 100px;
                    height: 40px;
                    line-height: 40px;
                    border-top-right-radius: 50px;
                    border-bottom-right-radius: 50px;
                    border-top-left-radius: 8px;
                    border-bottom-left-radius: 8px;
                    background-color: #0080FF;
                    color: #fff;
                    cursor: pointer;
                    font-weight: bold;
                    font-size: 15px;
                    text-align: center;
                }
            }
        }
    }
</style>