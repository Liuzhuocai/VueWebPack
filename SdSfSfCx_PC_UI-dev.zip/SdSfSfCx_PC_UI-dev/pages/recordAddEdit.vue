<template>
    <div class="recordAddEdit xPage">
        <div class="watermark"></div>
        <div class="xHeadBox">
            <div class="xTitle">{{$route.query.edit?'修改记录':'新增记录'}}</div>
            <div>
                <ul-button @click="done()" :disabled="loading||!fileUploadComplete">保存</ul-button>
                <ul-button @click="$router.back()" class="">取消</ul-button>
            </div>
        </div>
        <div style="height:1px;background:#ededf0;"></div>
        <div class="mainBox">
            <forms ref="form" :edit="true" :label-width="100" marginTop="0" msgPosition="bottom">
                <div class="reasonBox" v-if="$route.query.edit">
                    <inputs ref="inputs" :value="reason" name="reason" label="修改原因" type="textarea" v-model="reason" required width="100%"></inputs>
                </div>
                <div class="contentBox">
                    <div class="contentLeft">
                        <div class="xLabel">失范教师</div>
                        <div class="contentLeftItem">
                            <inputs ref="xxszdInput" :value="formData.bcode" name="xxszd" label="学校所在地" required>
                                <el-cascader @change="cascaderChange" @blur="$refs.xxszdInput.handleBlur()" :props="cascaderProps" :value="formData.bcode"></el-cascader>
                            </inputs>
                        </div>
                        <div class="contentLeftItem">
                            <inputs ref="inputs" :value="formData.sname" name="sname" label="学校名称" type="text" v-model="formData.sname" required></inputs>
                        </div>
                        <div class="contentLeftItem">
                            <inputs ref="inputs" :value="formData.uname" name="uname" label="姓名" type="text" v-model="formData.uname" required></inputs>
                        </div>
                        <div class="contentLeftItem">
                            <inputs ref="inputs" :value="formData.gender" name="gender" label="性别" type="radio" v-model="formData.gender" required :groups="codeList.sex"></inputs>
                        </div>
                        <div class="contentLeftItem">
                            <inputs ref="idcardInputs" :value="formData.idcard" name="idcard" label="身份证件号" :pattern="validateID" type="text" v-model="formData.idcard" required width="370"></inputs>
                        </div>
                        <div class="contentLeftItem">
                            <inputs ref="zzmmInput" :value="formData.zzmmid" name="zzmm" label="政治面貌" required>
                                <el-select @blur="$refs.zzmmInput.handleBlur()" v-model="formData.zzmmid" :placeholder="'请选择'">
                                    <el-option :label="item.label" :value="item.value" v-for="item in codeList.zzmm"></el-option>
                                </el-select>
                            </inputs>
                        </div>
                        <div class="contentLeftItem">
                            <inputs ref="inputs" :value="formData.duty" name="duty" label="职务职称" type="text" v-model="formData.duty" required></inputs>
                        </div>
                    </div>
                    <div style="width:1px;flex-shrink:0;background:#ededf0;"></div>
                    <div class="contentRight">
                        <div class="contentRightItem descpItem">
                            <div class="xLabel">失范行为</div>
                            <inputs required ref="inputs" :value="formData.descp" name="descp" label="具体内容" type="textarea" v-model="formData.descp" width="100%" :maxlength="200"
                                    desc="200字以内"></inputs>
                        </div>
                        <div style="height:1px;background:#ededf0;"></div>
                        <div class="contentRightItem" style="margin-top: 15px;">
                            <div class="xLabel">处理单位</div>
                            <inputs required ref="inputs" :value="formData.dispose_org" name="dispose_org" label="单位名称" type="text" v-model="formData.dispose_org" width="100%"></inputs>
                        </div>
                        <div style="height:1px;background:#ededf0;"></div>
                        <div class="contentRightItem">
                            <div class="xLabel">处理情况</div>
                            <div class="xValue">
                                <div class="contentRightItemSubitem dispose_yjItem" style="margin-bottom:15px;">
                                    <inputs required ref="inputs" :value="formData.dispose_yj" name="dispose_yj" label="依据" type="textarea" v-model="formData.dispose_yj" width="100%" :maxlength="200"
                                            desc="请输入法律法规名称、文号、条款及内容，200字以内"></inputs>
                                </div>
                                <div class="contentRightItemSubitem">
                                    <inputs required ref="dispose_lbInputs" :value="formData.dispose_lb" name="dispose_lb" label="类别" type="text" v-model="formData.dispose_lb">
                                        <el-select @blur="$refs.dispose_lbInputs.handleBlur()" v-model="formData.dispose_lb" placeholder="请选择">
                                            <el-option :label="item.label" :value="item.value" v-for="item in codeList.dispose_lb"></el-option>
                                        </el-select>
                                    </inputs>
                                </div>
                                <div class="contentRightItemSubitem">
                                    <inputs required ref="inputs" :value="formData.dispose_jl" name="dispose_jl" label="结论" type="textarea" v-model="formData.dispose_jl" width="100%" :maxlength="50"
                                            desc="50字以内"></inputs>
                                </div>
                            </div>
                        </div>
                        <div style="height:1px;background:#ededf0;"></div>
                        <div class="contentRightItem">
                            <div class="xLabel">结果适用</div>
                            <div class="xValue">
                                <div class="contentRightItemSubitem">
                                    <inputs required ref="inputs" :value="formData.result_lb" name="result_lb" label="类别" type="text" v-model="formData.result_lb">
                                        <el-select @blur="$refs.dispose_lbInputs.handleBlur()" v-model="formData.result_lb" placeholder="请选择" @change="result_lbSelectChange">
                                            <el-option :label="item.label" :value="item.value" v-for="item in codeList.result_lb"></el-option>
                                        </el-select>
                                    </inputs>
                                    <inputs :required="showCustomResultLb" v-show="showCustomResultLb" width="100%" ref="inputs" :value="customResultLb" name="customResultLb" label="其它类别" type="text"
                                            v-model="customResultLb"></inputs>
                                </div>
                                <div class="contentRightItemSubitem">
                                    <inputs required ref="inputs" :value="formData.result_s" name="result_s" label="开始时间" type="text" v-model="formData.result_s">
                                        <el-date-picker
                                                type="date"
                                                style="width:auto"
                                                v-model="formData.result_s"
                                                value-format="timestamp"
                                                format="yyyy-MM-dd"
                                                placeholder="选择时间"
                                                :picker-options="result_sOptions"
                                        >
                                        </el-date-picker>
                                    </inputs>
                                </div>
                                <div class="contentRightItemSubitem">
                                    <inputs required ref="inputs" :value="formData.result_e" name="result_e" label="终止时间" type="text" v-model="formData.result_e">
                                        <el-date-picker
                                                type="date"
                                                style="width:auto"
                                                v-model="formData.result_e"
                                                value-format="timestamp"
                                                format="yyyy-MM-dd"
                                                placeholder="选择时间"
                                                :picker-options="result_eOptions"
                                        >
                                        </el-date-picker>
                                    </inputs>
                                </div>
                            </div>
                        </div>
                        <div style="height:1px;background:#ededf0;"></div>
                        <div class="contentRightItem">
                            <div class="xLabel">附件（最大10个）</div>
                            <div style="display:flex;flex-wrap:wrap;margin-left:14px;">
                                <div class="fileCardBox" v-for="item in fileList" v-loading="fileLoading[item.lastModified]">
                                    <i v-show="!$root.isImg(item.fileExtension)" class="fileCardLeft ico attach_other_file_icon" :class="item.fileExtension"></i>
                                    <img v-if="$root.isImg(item.fileExtension)" class="fileCardLeft" :src="$root.getImgFileUrl(item.fid,item.url)" alt="加载失败"
                                         @click="previewFile(item.fid,item.url)">
                                    <image-viewer :visible="showImgViewer" @close="showImgViewer=false" :url="ImgViewerUrl"></image-viewer>
                                    <div class="fileCardRight">
                                        <div class="fileCardRightTop">{{item.name}}</div>
                                        <div class="fileCardRightBottom flex-justify-sb"><span class="fileCardSize">{{item.size}}</span>
                                            <div>
                                                <ul-button v-show="$root.isImg(item.fileExtension)" @click="previewFile(item.fid,item.url)">预览</ul-button>
                                                <ul-button class="red" @click="deleteFile(item)">删除</ul-button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="fileCardBox fileCardAddBox" @click="addFileClk" v-show="Object.keys(fileList).length<10">
                                    <input ref="addFileInput" @change="fileLoad" type="file" v-show="false" name="file"/>
                                    <i class="ico attch_plus fileCardLeft"></i>
                                    <div class="fileCardRight">
                                        <div class="fileCardRightTop">点击上传附件</div>
                                        <div class="fileCardRightBottom">
                                            <div>单个文件最大4MB</div>
                                            <div>建议上传文件类型为JPG、PDF或Word、Excel文件</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div style="height:1px;background:#ededf0;"></div>
                        <div class="contentRightItem">
                            <div class="xLabel">录入人</div>
                            <div class="xValue">
                                <div class="contentRightItemSubitem">
                                    <inputs required ref="inputs" :value="formData.enter_name" name="enter_name" label="姓名" type="text" v-model="formData.enter_name"></inputs>
                                </div>
                                <div class="contentRightItemSubitem">
                                    <inputs required ref="inputs" :value="formData.enter_phone" name="enter_phone" label="电话" type="text" v-model="formData.enter_phone"></inputs>
                                </div>
                            </div>
                        </div>
                        <div style="height:1px;background:#ededf0;"></div>
                        <div class="contentRightItem">
                            <div class="xLabel">审核人</div>
                            <div class="xValue">
                                <div class="contentRightItemSubitem">
                                    <inputs required ref="inputs" :value="formData.check_name" name="check_name" label="姓名" type="text" v-model="formData.check_name"></inputs>
                                </div>
                                <div class="contentRightItemSubitem">
                                    <inputs required ref="inputs" :value="formData.check_phone" name="check_phone" label="电话" type="text" v-model="formData.check_phone"></inputs>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </forms>
        </div>
    </div>
</template>

<script>
    import ImageViewer from '../components/ImageViewer'

    export default {
        name: "recordAddEdit",
        components: {ImageViewer},
        data() {
            let _self = this;
            return {
                baseList: [{label: '学校所在地', value: '四川省成都市'}],
                reason: '',
                result_sOptions: {
                    disabledDate(time) {
                        return _self.formData.result_e ? (time >= _self.formData.result_e) : false
                    },
                },
                result_eOptions: {
                    disabledDate(time) {
                        return _self.formData.result_s ? (time <= _self.formData.result_s) : false
                    },
                },
                formData: {
                    bcode: '',
                    sname: '',
                    uname: '',
                    gender: '',
                    idcard: '',
                    zzmmid: '',
                    duty: '',
                    descp: '',
                    dispose_org: '',
                    dispose_yj: '',
                    dispose_lb: '',
                    dispose_jl: '',
                    result_lb: '',
                    result_s: '',
                    result_e: '',
                    enter_name: '',
                    enter_phone: '',
                    check_name: '',
                    check_phone: '',
                    files: []
                },
                codeList: {
                    sex: [{label: '男', value: 1}, {label: '女', value: 2}],
                    zzmm: [],
                    dispose_lb: [{label: '党纪处分', value: '1'}, {label: '政务处分', value: '2'}, {label: '行政处罚', value: '3'}, {label: '刑事处罚', value: '4'}],
                    result_lb: [{label: '取消评先评优资格', value: '取消评先评优资格'}, {label: '取消职务晋升资格', value: '取消职务晋升资格'}, {label: '取消职称评定资格', value: '取消职称评定资格'},
                        {label: '取消岗位晋升资格', value: '取消岗位晋升资格'}, {label: '取消工资晋级资格', value: '取消工资晋级资格'}, {label: '其他（自行填写）', value: '其他（自行填写）'}],
                },
                showCustomResultLb: false,
                customResultLb: '',
                loading: false,
                orgAreaList: {},
                cascaderProps: {
                    lazy: true,
                    lazyLoad(node, resolve) {
                        node = node.value || '510000'
                        if (_self.orgAreaList[node]) {
                            const nodes = _self.orgAreaList[node].map(item => ({
                                value: item.code,
                                label: item.name2,
                                leaf: item.islast == 1
                            }));
                            // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                            resolve(nodes);
                        }
                        _self.$ajax.post("/api/common/getAreas", {code: node}, {security: 0, token: false}).then(d => {
                            if (node == '510000' && _self.$route.query.bcode) {
                                return _self.getArea(d)
                            }
                            const nodes = d.map(item => ({
                                value: item.code,
                                label: item.name2,
                                leaf: item.islast == 1
                            }));
                            _self.orgAreaList[node] = d
                            // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                            resolve(nodes);
                            if (_self.$route.query.edit) {
                                _self.editInit()
                            }
                        }).then(d => {
                            if (!d) return
                            const nodes = []
                            for (let i of d) {
                                let obj = {}
                                obj.value = i.code
                                obj.label = i.name2
                                obj.leaf = i.islast == 1
                                if (i.children) obj.children = i.children
                                nodes.push(obj)
                            }
                            _self.orgAreaList[node] = d
                            // 通过调用resolve将子节点数据返回，通知组件数据加载完成
                            resolve(nodes);
                            if (_self.$route.query.edit) {
                                _self.editInit()
                            }
                        }).catch(e => {
                            if (!e) return
                            _self.$showToast(e.message)
                        })
                    }
                },
                fileLoading: {},
                isEditInit: false,
                fileList: {},
                fileUploadComplete: true,
                showImgViewer: false,
                ImgViewerUrl: '',
                sourceData: {}
            };
        },
        computed: {
            // fileUploadComplete() {
            //     let a = false
            //     for (let i of this.fileLoading) {
            //     }
            //     return this.fileLoading[this.fileLoading.length-1]
            // }
        },
        watch: {
            fileLoading: {
                handler: function (v) {
                    let complete = []
                    for (let i in v) {
                        if (v[i] == true) {
                            complete.push(1)
                        }
                    }
                    if (complete.length) {
                        this.fileUploadComplete = false
                    } else {
                        this.fileUploadComplete = true
                    }
                },
                deep: true
            },
        },
        created() {
        },
        mounted() {
            if (!this.$route.query.edit) {
                this.addInit()
            }
        },
        methods: {
            done() {
                // this.formData = {
                //     bcode: "510104",
                //     check_name: "啊啊啊",
                //     check_phone: "啊啊啊",
                //     descp: "啊啊啊",
                //     dispose_jl: "啊啊啊",
                //     dispose_lb: "2",
                //     dispose_org: "啊啊啊",
                //     dispose_yj: "啊啊啊",
                //     duty: "啊啊啊",
                //     enter_name: "啊啊啊",
                //     enter_phone: "啊啊啊",
                //     files: [],
                //     length: 0,
                //     gender: 1,
                //     idcard: "啊啊啊",
                //     result_e: 1589640438,
                //     result_lb: "啊啊啊",
                //     result_s: 1589640436,
                //     sname: "啊啊啊",
                //     uname: "啊啊啊",
                //     zzmmid: "9A05FC4FFBFB1169E055000000000001"
                // }
                let num = 0
                if (this.$route.query.edit) {
                    for (let i in this.formData) {
                        if (i != 'files') {
                            if (this.formData[i] != this.sourceData[i]) {
                                num++
                            }
                        } else {
                            for (let j of this.formData[i]) {
                                if (!this.sourceData[i].includes(j)) {
                                    num++
                                }
                            }
                            for (let k of this.sourceData[i]) {
                                if (!this.formData[i].includes(k)) {
                                    num++
                                }
                            }
                        }
                    }
                    if (num == 0) {
                        this.$showAlert('没有改动，无需保存', null, '提示')
                        return
                    }
                }
                if (!this.$refs.form.validate()) {
                    let msgs = this.$refs.form.msgs
                    if (msgs.length === 1 && msgs[0].name == 'idcard') {
                        if (!this.formData.idcard) {
                            this.$showAlert('错误项' + '：' + msgs[0].label + '<br>错误提示：' + msgs[0].msg, null, '填写信息有误')
                            return
                        }
                    } else {
                        this.$showAlert('错误项' + '：' + msgs[0].label + '<br>错误提示：' + msgs[0].msg, null, '填写信息有误')
                        return
                    }
                }
                if (this.$route.query.edit) {
                    this.formData.rid = this.$route.query.id
                    this.formData.etype = 1
                    this.formData.reason = this.reason
                }
                let jsonObj = JSON.stringify(this.formData)
                let pData = JSON.parse(jsonObj)
                if (this.customResultLb) {
                    pData.result_lb = this.customResultLb
                }
                pData.result_s = pData.result_s / 1000
                pData.result_e = pData.result_e / 1000
                this.$ajax.post('/api/record/edit', pData).then(d => {
                    this.$showToast('提交成功')
                    this.$router.back()
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.loading = false
                })
            },
            validateID(card) {
                card = card.toUpperCase();
                var vcity = {
                    11: "北京", 12: "天津", 13: "河北", 14: "山西", 15: "内蒙古",
                    21: "辽宁", 22: "吉林", 23: "黑龙江", 31: "上海", 32: "江苏",
                    33: "浙江", 34: "安徽", 35: "福建", 36: "江西", 37: "山东", 41: "河南",
                    42: "湖北", 43: "湖南", 44: "广东", 45: "广西", 46: "海南", 50: "重庆",
                    51: "四川", 52: "贵州", 53: "云南", 54: "西藏", 61: "陕西", 62: "甘肃",
                    63: "青海", 64: "宁夏", 65: "新疆", 71: "台湾", 81: "香港", 82: "澳门", 91: "国外"
                };
                var reg = /^\d{17}(\d|X)$/i;//忽略x的大小写
                if (reg.test(card) === false) {
                    return '可能不是正确的身份证号码';
                }
                var len = card.length;
                var v = card.substr(0, 2);
                if (vcity[v] == undefined) {
                    return '可能不是正确的身份证号码';
                }
                let y = card.substr(6, 4);
                let m = card.substr(10, 2);
                let d = card.substr(12, 2);
                let date = new Date(y + '-' + m + '-' + d)
                let yy = date.getFullYear() + '';
                let mm = date.getMonth() + 1;
                let dd = date.getDate();
                if (mm < 10) {
                    mm = '0' + mm;
                } else {
                    mm += ''
                }
                if (dd < 10) {
                    dd = '0' + dd;
                } else {
                    dd += ''
                }
                if (yy != y || mm != m || dd != d) {//匹配
                    return '可能不是正确的身份证号码'
                }
                // var t=(Date.now()-date.getTime())/1000/3600/24;
                // if(t<1||t>100*365){//出生日期合理性判断,至少出生1天起到120岁之间
                //     return '非法身份证号:出身日期不合理'
                // }
                if (len == 18) {
                    var arrInt = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
                    var arrCh = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'];
                    var cardTemp = 0, i, v;
                    for (i = 0; i < 17; i++) {
                        cardTemp += card[i] * arrInt[i];
                    }
                    v = arrCh[cardTemp % 11];
                    if (v != card[17]) {
                        return '可能不是正确的身份证号码';
                    }
                }
                return true;
            },
            cascaderChange(v) {
                this.formData.bcode = v[v.length - 1]
            },
            getArea(nodeData) {
                let fCode = this.$route.query.bcode.substring(0, 4) + '00'
                return this.$ajax.post("/api/common/getAreas", {code: fCode}, {security: 0, token: false}).then(d => {
                    d = d.map(item => ({
                        value: item.code,
                        label: item.name2,
                        leaf: item.islast == 1
                    }))
                    for (let i of nodeData) {
                        if (i.code == fCode) {
                            i.children = d
                        }
                    }
                    return nodeData
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                });
            },
            addInit() {
                this.loading = true
                // this.formData.result_s = new Date().getTime()
                // this.formData.result_e = new Date().getTime()
                this.$ajax.post('/api/common/getZzmm', {}, {security: 0, token: false}).then(d => {
                    for (let i of d) {
                        let obj = {}
                        obj.label = i.name
                        obj.value = i.cid
                        this.codeList.zzmm.push(obj)
                    }
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.loading = false
                })
                this.formData.enter_name = this.$store.state.user.UserInfo.uname
            },
            editInit() {
                this.loading = true
                this.$ajax.post('/api/common/getZzmm', {}, {security: 0, token: false}).then(d => {
                    for (let i of d) {
                        let obj = {}
                        obj.label = i.name
                        obj.value = i.cid
                        this.codeList.zzmm.push(obj)
                    }
                    return this.$ajax.post('/api/record/detial', {rid: this.$route.query.id})
                }).then(d => {
                    // console.log(new Date(d.record.result_e))
                    if (this.isEditInit) {
                        this.formData.bcode = d.record.bcode
                        return
                    }
                    d.record.result_s = new Date(d.record.result_s).getTime()
                    d.record.result_e = new Date(d.record.result_e).getTime()
                    let result_lbCodeList = ['取消评先评优资格', '取消职务晋升资格', '取消职称评定资格', '取消岗位晋升资格', '取消工资晋级资格']
                    if (result_lbCodeList.indexOf(d.record.result_lb) < 0) {
                        this.customResultLb = d.record.result_lb
                        this.showCustomResultLb = true
                        d.record.result_lb = '其他（自行填写）'
                    }
                    let files = []
                    for (let i of d.record.files) {
                        let obj = {}
                        obj.fileExtension = this.$root.getFileExtension(i.name)
                        obj.name = i.name
                        obj.size = this.$root.renderSize(i.bufferlimit)
                        obj.fid = i.fid
                        obj.hash = i.hash
                        // if ($root.isImg(obj.fileExtension)) {
                        //     obj.url = $root.getImgFileUrl(obj.fid)
                        // }
                        this.fileList[obj.fid] = obj
                        files.push(i.fid)
                    }
                    d.record.files = files
                    for (let i in this.formData) {
                        // this.$set(this.formData, i, d.record[i])
                        this.formData[i] = d.record[i]
                    }
                    let jsonObj = JSON.stringify(this.formData)
                    this.sourceData = JSON.parse(jsonObj)
                    this.isEditInit = true
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.loading = false
                })
            },
            result_lbSelectChange(v) {
                if (v == '其他（自行填写）') {
                    this.showCustomResultLb = true
                } else {
                    this.customResultLb = ''
                    this.showCustomResultLb = false
                }
            },
            previewFile(fid, localUrl) {
                if (localUrl) {
                    this.ImgViewerUrl = localUrl
                } else {
                    this.ImgViewerUrl = this.$root.getImgFileUrl(fid)
                }
                this.showImgViewer = true
            },
            deleteFile(i) {
                this.formData.files.splice(this.formData.files.indexOf(i), 1)
                this.$delete(this.fileList, i.fid || i.lastModified)
            },
            fileUpload(index) {
            },
            addFileClk() {
                if (Object.keys(this.fileList).length == 10) {
                    this.$showAlert('文件最多添加10份！', null, '提示')
                    return
                }
                this.$refs.addFileInput.value = ''
                this.$refs.addFileInput.click()
            },
            fileLoad(event) {
                let loadFile = event.target.files[0]
                if (loadFile.size <= 0 || loadFile.size > 4194304) {
                    this.$showAlert("文件不得超过4MB，请重新上传", null, '提示');
                    return
                }
                if (this.fileList[loadFile.lastModified]) {
                    this.$showAlert("请勿上传相同文件。", null, '提示');
                    return
                }
                this.$set(this.fileLoading, loadFile.lastModified, true)
                let imgUrlBlob = window.URL.createObjectURL(loadFile);
                this.$set(this.fileList, loadFile.lastModified, {
                    name: loadFile.name,
                    size: this.$root.renderSize(loadFile.size / 1024),
                    fileExtension: this.$root.getFileExtension(loadFile.name),
                    lastModified: loadFile.lastModified,
                    url: imgUrlBlob
                })
                let fData = new FormData()
                fData.append('file' + loadFile.lastModified, loadFile)
                this.$ajax.post('/api/file/upload', fData, {security: 0}).then(d => {
                    this.formData.files.push(d['file' + loadFile.lastModified])
                }).catch(e => {
                    if (!e) return
                    this.$delete(this.fileList, loadFile.lastModified)
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.$set(this.fileLoading, loadFile.lastModified, false)
                })
            },
            // fileFilter(name) {
            //     var dP = name.lastIndexOf('.');
            //     return this.fileFormat.indexOf(name.substr(dP)) >= 0;
            // let rFilter = /^(application\/vnd.ms-excel)$/i; // type的方法
            // if (!rFilter.test(file.type)) {
            //     alert("请选择xls格式的文件");
            //     return;
            // }
            // },
        }
    }
</script>

<style lang="less">
    .recordAddEdit {
        .statusBox {
            background-color: #fff;
            height: 50px;
            line-height: 50px;
            border-radius: 8px;
            padding: 0 20px;
            box-sizing: border-box;
            margin-bottom: 20px;
        }

        .mainBox {
            padding: 20px 0;
            box-sizing: border-box;
        }

        .reasonBox {
            padding: 20px;
            padding-top: 0;
            box-sizing: border-box;
        }

        .contentBox {
            display: flex;
            box-sizing: border-box;

            .xLabel {
                height: 60px;
                line-height: 50px;
                /*margin-left: 16px;*/
                margin-top: 10px;
                font-size: 15px;
                color: #405580;
                font-weight: bold;
            }

            .xValue {
                /*margin-left: 10px;*/
                font-size: 14px;
                color: #333;
            }

            .inlineLabel {
                display: inline-block;
                width: 120px;
            }

            .contentLeft {
                flex-shrink: 0;
                padding: 0 20px;

                .contentLeftItem {
                    margin-bottom: 10px;
                }
            }

            .contentRight {
                flex-grow: 1;
                width: 1px;
                padding: 0 20px;

                .contentRightItem {
                    margin-bottom: 40px;
                    margin-left: 10px;

                    .inputs {
                        .msg {
                            margin-left: 6px;
                        }

                        .desc {
                            color: #b3b3b3;
                        }
                    }

                    .fileCardBox {
                        width: 310px;
                    }

                    .fileCardAddBox {
                        border: 1px dashed #1682F2;
                        cursor: pointer;

                        .fileCardLeft {
                            background-size: unset;
                        }

                        .fileCardRightTop {
                            color: #0080ff;
                            font-size: 14px;
                        }

                        .fileCardRightBottom {
                            color: #b2b2b2;
                            line-height: 20px;
                            font-size: 12px;
                            display: block;
                        }

                        &:hover {
                            border: 1px solid #1682F2;
                        }
                    }

                    .contentRightItemSubitem {
                        margin-bottom: 10px;
                    }
                }
            }
        }
    }
</style>