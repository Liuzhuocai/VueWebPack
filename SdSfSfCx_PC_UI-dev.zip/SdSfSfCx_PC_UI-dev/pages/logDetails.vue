<template>
    <div class="logDetails xPage">
        <div class="watermark"></div>
        <div class="xHeadBox">
            <div class="xTitle font-color-yellow">日志详情</div>
            <div>
                <ul-button @click="$router.back()" class="">返回</ul-button>
            </div>
        </div>
        <div class="mainBox" v-preloader:show.loading.delay="loading">
            <div class="statusBox">
                <div class="statusItem">
                    <span>{{$root.formatTime(action.rtime)}} </span><span> {{action.organize}} </span><span
                        :class="$root.formatActionStyle(action.action)"> {{$root.formatAction(action.action)}} </span>
                    <span>{{action.sname}}</span>-<span>{{action.uname}}</span> 的 失范记录
                </div>
                <div class="statusItem" v-show="action.reason"><span class="font-color-blue">修改原因： </span>{{action.reason}}</div>
            </div>
            <div class="contentBox">
                <div class="contentLeft">
                    <div class="label">失范教师</div>
                    <div class="contentLeftItem">
                        <span class="inlineLabel">学校所在地</span>
                        <div class="inlineValue">
                            <div class="lastValue" v-show="params.bcode_n.last">{{params.bcode_n.last}}</div>
                            <div class="currentValue">{{params.bcode_n.current}}</div>
                        </div>
                    </div>
                    <div class="contentLeftItem">
                        <span class="inlineLabel">学校名称</span>
                        <div class="inlineValue">
                            <div class="lastValue" v-show="params.sname.last">{{params.sname.last}}</div>
                            <div class="currentValue">{{params.sname.current}}</div>
                        </div>
                    </div>
                    <div class="contentLeftItem">
                        <span class="inlineLabel">姓名</span>
                        <div class="inlineValue">
                            <div class="lastValue" v-show="params.uname.last">{{params.uname.last}}</div>
                            <div class="currentValue">{{params.uname.current}}</div>
                        </div>
                    </div>
                    <div class="contentLeftItem">
                        <span class="inlineLabel">性别</span>
                        <div class="inlineValue">

                            <div class="lastValue" v-show="params.gender_n.last">{{params.gender_n.last}}</div>
                            <div class="currentValue">{{params.gender_n.current}}</div>
                        </div>
                    </div>
                    <div class="contentLeftItem">
                        <span class="inlineLabel">身份证件号</span>
                        <div class="inlineValue">
                            <div class="lastValue" v-show="params.idcard.last">{{params.idcard.last}}</div>
                            <div class="currentValue">{{params.idcard.current}}</div>
                        </div>
                    </div>
                    <div class="contentLeftItem">
                        <span class="inlineLabel">政治面貌</span>
                        <div class="inlineValue">
                            <div class="lastValue" v-show="params.zzmmid_n.last">{{params.zzmmid_n.last}}</div>
                            <div class="currentValue">{{params.zzmmid_n.current}}</div>
                        </div>
                    </div>
                    <div class="contentLeftItem">
                        <span class="inlineLabel">职务职称</span>
                        <div class="inlineValue">
                            <div class="lastValue" v-show="params.duty.last">{{params.duty.last}}</div>
                            <div class="currentValue">{{params.duty.current}}</div>
                        </div>
                    </div>
                </div>
                <div style="width:1px;flex-shrink:0;background:#ededf0;"></div>
                <div class="contentRight">
                    <div class="contentRightItem">
                        <div class="label">失范行为</div>
                        <div class="valueBox">
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">具体内容</span>
                                <div class="inlineValue">
                                    <div class="lastValue" v-show="params.descp.last">{{params.descp.last}}</div>
                                    <div class="currentValue">{{params.descp.current}}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="height:1px;background:#ededf0;"></div>
                    <div class="contentRightItem">
                        <div class="label">处理单位</div>
                        <div class="valueBox">
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">单位名称</span>
                                <div class="inlineValue">
                                    <div class="lastValue" v-show="params.dispose_org.last">{{params.dispose_org.last}}</div>
                                    <div class="currentValue">{{params.dispose_org.current}}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="height:1px;background:#ededf0;"></div>
                    <div class="contentRightItem">
                        <div class="label">处理情况</div>
                        <div class="valueBox">
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">依据</span>
                                <div class="inlineValue">
                                    <div class="lastValue" v-show="params.dispose_yj.last">{{params.dispose_yj.last}}</div>
                                    <div class="currentValue">{{params.dispose_yj.current}}</div>
                                </div>
                            </div>
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">类型</span>
                                <div class="inlineValue">
                                    <div class="lastValue" v-show="params.dispose_lb_n.last">{{params.dispose_lb_n.last}}</div>
                                    <div class="currentValue">{{params.dispose_lb_n.current}}</div>
                                </div>
                            </div>
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">结论</span>
                                <div class="inlineValue">
                                    <div class="lastValue" v-show="params.dispose_jl.last">{{params.dispose_jl.last}}</div>
                                    <div class="currentValue">{{params.dispose_jl.current}}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="height:1px;background:#ededf0;"></div>
                    <div class="contentRightItem">
                        <div class="label">结果适用</div>
                        <div class="valueBox">
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">类别</span>
                                <div class="inlineValue">
                                    <div class="lastValue" v-show="params.result_lb.last">{{params.result_lb.last}}</div>
                                    <div class="currentValue">{{params.result_lb.current}}</div>
                                </div>
                            </div>
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">开始时间</span>
                                <div class="inlineValue">
                                    <div class="lastValue" v-show="params.result_s.last">{{$root.formatTime(params.result_s.last)}}</div>
                                    <div class="currentValue">{{$root.formatTime(params.result_s.current)}}</div>
                                </div>
                            </div>
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">终止时间</span>
                                <div class="inlineValue">
                                    <div class="lastValue" v-show="params.result_e.last">{{$root.formatTime(params.result_e.last)}}</div>
                                    <div class="currentValue">{{$root.formatTime(params.result_e.current)}}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="height:1px;background:#ededf0;"></div>
                    <div class="contentRightItem">
                        <div class="label" style="height:50px;">附件</div>
                        <div style="color:#b2b2b2" v-if="params.files&&!Object.keys(params.files).length">无</div>
                        <div class="valueBox" style="display:flex;flex-wrap:wrap;">
                            <div class="fileCardBox" v-for="item in params.files" v-loading="downloadLoading[item.fid]">
                                <i v-show="!$root.isImg($root.getFileExtension(item.name))" class="fileCardLeft ico attach_other_file_icon"
                                   :class="$root.getFileExtension(item.name)"></i>
                                <img v-if="$root.isImg($root.getFileExtension(item.name))" class="fileCardLeft" :src="$root.getImgFileUrl(item.fid)" alt="加载失败" @click="previewFile(item.fid)">
                                <image-viewer :visible="showImgViewer" @close="showImgViewer=false" :url="ImgViewerUrl"></image-viewer>
                                <div class="fileCardRight">
                                    <div class="fileCardRightTop">{{item.name}}</div>
                                    <div class="fileCardRightBottom" :class="{'flex-justify-sb':item.action}">
                                        <!--                                        <span></span>-->
                                        <!--                                        <span class="fileCardSize">{{$root.renderSize(item.bufferlimit)}}</span>-->
                                        <span v-if="item.action" :class="{'font-color-red':item.action=='delete','font-color-blue':item.action=='add'}">
                                    {{item.action=='delete'?'删除了该文件':'新增了该文件'}}</span>
                                        <span>
                                        <ul-button v-show="$root.isImg($root.getFileExtension(item.name))" @click="previewFile(item.fid)">预览</ul-button>
                                        <ul-button @click="downloadFile(item)">下载</ul-button>
                                    </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="height:1px;background:#ededf0;"></div>
                    <div class="contentRightItem">
                        <div class="label">录入人</div>
                        <div class="valueBox">
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">姓名</span>
                                <div class="inlineValue">
                                    <div class="lastValue" v-show="params.enter_name.last">{{params.enter_name.last}}</div>
                                    <div class="currentValue">{{params.enter_name.current}}</div>
                                </div>
                            </div>
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">电话</span>
                                <div class="inlineValue">
                                    <div class="lastValue" v-show="params.enter_phone.last">{{params.enter_phone.last}}</div>
                                    <div class="currentValue">{{params.enter_phone.current}}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="height:1px;background:#ededf0;"></div>
                    <div class="contentRightItem">
                        <div class="label">审核人</div>
                        <div class="valueBox">
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">姓名</span>
                                <div class="inlineValue">
                                    <div class="lastValue" v-show="params.check_name.last">{{params.check_name.last}}</div>
                                    <div class="currentValue">{{params.check_name.current}}</div>
                                </div>
                            </div>
                            <div class="contentRightItemSubitem">
                                <span class="inlineLabel">电话</span>
                                <div class="inlineValue">
                                    <div class="lastValue" v-show="params.check_phone.last">{{params.check_phone.last}}</div>
                                    <div class="currentValue">{{params.check_phone.current}}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <a ref="downloadBtn" v-show="false"></a>
    </div>
</template>

<script>
    import ImageViewer from '../components/ImageViewer'

    export default {
        name: "logDetails",
        components: {ImageViewer},
        data() {
            return {
                baseList: [{label: '行政区划', value: '四川省成都市'}],
                action: [],
                params: {
                    "rid": "",
                    "bcode": "",
                    "bcode_n": '',
                    "sname": "",
                    "uname": "",
                    "gender": '',
                    "gender_n": "",
                    "idcard": "",
                    "zzmmid": "",
                    "zzmmid_n": "",
                    "duty": "",
                    "descp": "",
                    "dispose_org": "",
                    "dispose_yj": "",
                    "dispose_lb": "",
                    "dispose_lb_n": "",
                    "dispose_jl": "",
                    "result_lb": "",
                    "result_s": "",
                    "result_e": "",
                    "enter_name": "",
                    "enter_phone": "",
                    "check_name": "",
                    "check_phone": "",
                    "hidden": '',
                    "edit_time": "",
                    "files": []
                },
                loading: false,
                showImgViewer: false,
                ImgViewerUrl: '',
                downloadLoading: {},
            };
        },
        computed: {},
        watch: {},
        created() {
            this.loading = true
            this.$ajax.post('/api/actions/detial', {id: this.$route.query.id}).then(d => {
                    this.action = d.action
                    for (let i in d.record) {
                        if (i != 'files') {
                            let obj = d.record[i]
                            d.record[i] = {}
                            d.record[i].current = obj
                        }
                        for (let j in d.last_record) {
                            if (i != 'files' && i == j && d.record[i].current != d.last_record[j]) {
                                d.record[i].last = d.last_record[j]
                                d.record[i].current = d.record[i].current
                            } else if (i != 'files' && i == j && d.record[i].current == d.last_record[j]) {
                                d.record[i].last = ''
                            }
                        }
                    }
                    let lastFiles = {}
                    let currentFiles = {}
                    let deleteList = []
                    let addList = []
                    for (let j in d.last_record.files) {
                        lastFiles[d.last_record.files[j].fid] = d.last_record.files[j]
                    }
                    for (let i of d.record.files) {
                        currentFiles[i.fid] = i
                    }
                    let lastFilesKeys = Object.keys(lastFiles)
                    let currentFilesKeys = Object.keys(currentFiles)
                    for (let j of lastFilesKeys) {
                        if (!currentFilesKeys.includes(j)) {
                            deleteList.push(j)
                        }
                    }
                    for (let j of currentFilesKeys) {
                        if (!lastFilesKeys.includes(j)) {
                            addList.push(j)
                        }
                    }
                    let xFileList = Object.assign(lastFiles, currentFiles)
                    for (let i of deleteList) {
                        xFileList[i].action = 'delete'
                    }
                    for (let i of addList) {
                        xFileList[i].action = 'add'
                    }
                    //给对象排序
                    let xFileListArr = Object.keys(xFileList).sort()
                    let xFileListResult = {}
                    for (let i of xFileListArr) {
                        if (xFileList[i].action == 'delete') {
                            xFileListResult[i] = xFileList[i]
                        }
                    }
                    for (let i of xFileListArr) {
                        if (xFileList[i].action == 'add') {
                            xFileListResult[i] = xFileList[i]
                        }
                    }
                    for (let i of xFileListArr) {
                        if (!xFileList[i].action) {
                            xFileListResult[i] = xFileList[i]
                        }
                    }
                    d.record.files = xFileListResult
                    this.params = d.record
                }
            ).catch(e => {
                if (!e) return
                this.$showAlert(e.message, null, '提示')
            }).finally(() => {
                this.loading = false
            })
        },
        mounted() {
            for (let i = 0; i < 7; i++) {
                this.baseList.push(this.baseList[0])
            }
        },
        methods: {
            previewFile(fid) {
                this.ImgViewerUrl = this.$root.getImgFileUrl(fid)
                this.showImgViewer = true
            },
            downloadFile(item) {
                this.$set(this.downloadLoading, item.fid, true)
                this.$ajax.get('/api/file/download?token=' + this.$ajax.token + '&fid=' + item.fid, null, {responseType: 'blob'}).then(d => {
                    let blob = d;
                    this.$refs.downloadBtn.href = window.URL.createObjectURL(blob);
                    this.$refs.downloadBtn.download = item.name;
                    this.$refs.downloadBtn.click();
                    window.URL.revokeObjectURL(this.$refs.downloadBtn.href);
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.$set(this.downloadLoading, item.fid, false)
                })
            },
        }
    }
</script>

<style lang="less">
    .logDetails {
        .statusBox {
            background-color: #fff;
            border-radius: 8px;
            padding: 10px 20px;
            box-sizing: border-box;
            margin-bottom: 20px;
            font-size: 14px;

            .statusItem {
                color: #333;
                line-height: 24px;
                font-size: 14px;
                padding: 6px 0;
                box-sizing: border-box;
            }
        }

        .contentBox {
            display: flex;
            box-sizing: border-box;
            font-size: 14px;
            color: #333;

            .label {
                height: 50px;
                line-height: 50px;
                font-size: 15px;
                color: #405580;
                font-weight: bold;
            }

            .inlineLabel {
                display: inline-block;
                width: 90px;
                height: 50px;
                line-height: 50px;
                color: #b3b3b3;
                flex-shrink: 0;
            }

            .inlineValue {
                margin-top: 13px;
            }

            .lastValue {
                color: red;
                text-decoration: line-through;
                word-break: break-all;
                line-height: 24px;
                margin-bottom: 5px;
            }

            .currentValue {
                word-break: break-all;
                line-height: 24px;
                margin-bottom: 5px;
            }

            .contentLeft {
                flex-shrink: 0;
                padding: 0 20px;

                .contentLeftItem {
                    display: flex;
                    justify-content: flex-start;
                    align-items: flex-start;
                    margin-bottom: 13px;
                }

                .inlineValue {
                    width: 220px;
                }
            }

            .contentRight {
                flex-grow: 1;
                width: 1px;
                padding: 0 20px;

                .valueBox {
                    margin-left: 10px;
                }

                .contentRightItem {
                    margin-bottom: 50px;

                    .contentRightItemSubitem {
                        display: flex;
                        justify-content: flex-start;
                        margin-bottom: 13px;
                    }
                }
            }
        }
    }
</style>