<template>
    <div class="searchLogList xPage">
        <div class="watermark"></div>
        <div class="xHeadBox">
            <div>
                <span class="xTitle font-color-yellow">查询日志</span>
            </div>
            <div>
                <ul-button @click="$router.back()">返回</ul-button>
            </div>
        </div>
        <div class="mainBox" v-preloader:show.loading.delay="loading">
            <div style="height:400px;display:flex;align-items:center;justify-content:center;" v-show="!searchLogList||(searchLogList&&!Object.keys(searchLogList).length)">
                暂无数据。
            </div>
            <div class="logItemOverBox" v-for="item,index in searchLogList">
                <div class="logItemDate">{{index}}</div>
                <div class="logItem" v-for="i in item.list">
                    <span>{{i.time}} </span><span> {{i.organize}} </span><span> {{i.name}} </span><span class="font-color-gray">通过条件</span><span> {{'“'+i.search+'”'}} </span>
                    <span class="font-color-gray">查询到</span><span> {{i.replength}} </span><span class="font-color-gray">条失范记录</span>
                </div>
            </div>
        </div>
        <div class="footBox">
            <pagination :total="total" @change="getData" ref="pager" :page="currentPage" :pageOfCount="limit"></pagination>
        </div>
    </div>
</template>

<script>
    export default {
        name: "searchLogList",
        data() {
            return {
                searchLogList: {},
                total: 0,
                currentPage: 1,
                loading: false,
                limit: 20
            };
        },
        computed: {},
        watch: {},
        created() {
            this.getData()
        },
        mounted() {
        },
        methods: {
            getData(page) {
                page = page || 1
                this.loading = true
                this.$ajax.post('/api/search/slist', {pageNo: page, limit: this.limit}).then(d => {
                    let searchLogList = {}
                    for (let i of d.data) {
                        i.date = this.formatDate(i.search_time)
                        i.time = this.formatTime(i.search_time)
                        if (!searchLogList[i.date]) {
                            searchLogList[i.date] = {}
                            searchLogList[i.date].list = []
                        }
                        searchLogList[i.date].list.push(i)
                    }
                    this.currentPage = page
                    this.total = parseInt(d.total)
                    this.searchLogList = searchLogList
                    console.log(this.searchLogList)
                }).catch(e => {
                    if (!e) return
                    this.$showAlert(e.message, null, '提示')
                }).finally(() => {
                    this.loading = false
                    // this.$hidePreloader();
                })
            },
            formatDate(time) {
                var date = new Date(time);
                var y = date.getFullYear();
                var m = date.getMonth() + 1;
                m = m < 10 ? ('0' + m) : m;
                var d = date.getDate();
                d = d < 10 ? ('0' + d) : d;
                var h = date.getHours();
                h = h < 10 ? ('0' + h) : h;
                var minute = date.getMinutes();
                var second = date.getSeconds();
                minute = minute < 10 ? ('0' + minute) : minute;
                second = second < 10 ? ('0' + second) : second;
                return y + '-' + m + '-' + d
            },
            formatTime(time) {
                var date = new Date(time);
                var y = date.getFullYear();
                var m = date.getMonth() + 1;
                m = m < 10 ? ('0' + m) : m;
                var d = date.getDate();
                d = d < 10 ? ('0' + d) : d;
                var h = date.getHours();
                h = h < 10 ? ('0' + h) : h;
                var minute = date.getMinutes();
                var second = date.getSeconds();
                minute = minute < 10 ? ('0' + minute) : minute;
                second = second < 10 ? ('0' + second) : second;
                return h + ':' + minute + ':' + second;
            }
        }
    }
</script>

<style lang="less">
    .searchLogList {
        .mainBox {
            .logItemOverBox {
                .logItemDate {
                    font-size: 14px;
                    color: #808080;
                    padding-left: 5px;
                    box-sizing: border-box;
                    height: 24px;
                    line-height: 24px;
                    margin-top: 15px;
                    margin-bottom: 6px;
                }

                .logItem {
                    height: 40px;
                    line-height: 40px;
                    border-radius: 5px;
                    padding: 0 12px;
                    box-sizing: border-box;
                    font-size: 12px;
                    color: #333;

                    &:hover {
                        background-color: #ededf0;
                    }
                }
            }
        }
    }
</style>