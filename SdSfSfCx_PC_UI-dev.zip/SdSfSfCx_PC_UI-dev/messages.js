import messages from '@ul/xerror/messages.esm';
import codes from '@ul/xerror/codes';

codes.TOKEN_INVALID = 510;
//公共错误码
codes.HTTP_ERROR_404 = 1404;
//私有错误码
codes.TOKEN_TYPE_ERROR = 10001;
codes.USER_TYPE_ERROR = 20001;
codes.ACTIONS_ERROR = 20100;
codes.FILE_ERROR = 20200;

messages[codes.HTTP_ERROR_404] = '网络错误';
messages[codes.TOKEN_TYPE_ERROR] = '当前用户暂无使用此应用权限';
messages[codes.USER_TYPE_ERROR] = '该账号无权使用此功能';
messages[codes.ACTIONS_ERROR] = '系统错误';
messages[codes.FILE_ERROR] = '文件异常';
messages[codes.TOKEN_INVALID] = '登录超时';
messages[codes.NOT_ALLOW] = '需要返回平台重新登录，本页面即将关闭';
messages[codes.TOKEN_NOT_EXIST] = '登录超时，需要返回平台重新登录，本页面即将关闭';
export default messages;