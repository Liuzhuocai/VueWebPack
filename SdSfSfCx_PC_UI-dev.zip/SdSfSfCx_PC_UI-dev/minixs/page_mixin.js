export default {
    methods:{
        indexMethod(index) {
            return (this.$refs.pager.currentPage - 1) * this.$refs.pager.pageOfCount + index + 1;
        },
    }
}