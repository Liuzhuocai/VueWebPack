// import {Scrollbar,Container,Header,Aside,Button,Transfer,Row
//     ,Card,ButtonGroup,Input,Dialog,Table,TableColumn,Pagination,Breadcrumb,
// FormItem,Form,BreadcrumbItem,Upload,Checkbox,Tree,Radio,RadioGroup,Option,Select} from 'element-ui';
// import {Scrollbar,TableColumn,Pagination} from 'element-ui';
import Table from 'element-ui/packages/table';
import TableColumn from 'element-ui/packages/table-column';
import Tree from 'element-ui/packages/tree';
import Loading from 'element-ui/packages/loading';
import Dialog from 'element-ui/packages/dialog';
import Switch from 'element-ui/packages/switch'
import Popover from "element-ui/packages/popover";
import Select from "element-ui/packages/select";
import Tabs from "element-ui/packages/tabs";
import Option from "element-ui/packages/option";
import TabPane from 'element-ui/packages/tab-pane'
import Icon from 'element-ui/packages/icon'
import dropdown from 'element-ui/packages/dropdown'
import dropdownMenu from 'element-ui/packages/dropdown-menu'
import dropdownItem from 'element-ui/packages/dropdown-item'
import datePicker from 'element-ui/packages/date-picker'
// import timePicker from 'element-ui/packages/time-picker'
import cascader from 'element-ui/packages/cascader'
import radio from 'element-ui/packages/radio'
// import radio from 'element-ui/packages/radio-group'


import CollapseTransition from 'element-ui/lib/transitions/collapse-transition';

// import
import Checkbox from 'element-ui/packages/checkbox'

import 'element-ui/lib/theme-chalk/table.css';
import 'element-ui/lib/theme-chalk/popover.css';
import 'element-ui/lib/theme-chalk/select.css';
import 'element-ui/lib/theme-chalk/option.css';
import 'element-ui/lib/theme-chalk/tabs.css'
import 'element-ui/lib/theme-chalk/tab-pane.css'
import 'element-ui/lib/theme-chalk/switch.css';
import 'element-ui/lib/theme-chalk/table-column.css';
import 'element-ui/lib/theme-chalk/pagination.css';
import 'element-ui/lib/theme-chalk/loading.css';
import 'element-ui/lib/theme-chalk/dialog.css';
import 'element-ui/lib/theme-chalk/tree.css';
import 'element-ui/lib/theme-chalk/checkbox.css';
import 'element-ui/lib/theme-chalk/icon.css';
import 'element-ui/lib/theme-chalk/dropdown.css';
import 'element-ui/lib/theme-chalk/dropdown-menu.css';
import 'element-ui/lib/theme-chalk/dropdown-item.css';
import 'element-ui/lib/theme-chalk/date-picker.css';
import 'element-ui/lib/theme-chalk/cascader.css';
import 'element-ui/lib/theme-chalk/radio.css';
// import 'element-ui/lib/theme-chalk/time-picker.css';

// import 'element-ui/lib/theme-chalk/scrollbar.css';
// import Table from './table-body';
// import CollapseTransition from 'element-ui/lib/transitions/collapse-transition';


//导入自定义全局组件

// import inputs from './components/inputs';
// import inputs_search from './components/inputs-search';
// import inputs_group from './components/inputs-group';
// import page_container from './components/page-container';
// import pagination from './components/pagination';
import inputTemplate from './components/inputTemplate';


import inputs from '../eduplatform_ui/platform-common/components/inputs';
import inputs_search from '../eduplatform_ui/platform-common/components/inputs-search';
// import froms from '../eduplatform_ui/platform-common/components/forms';
import page_container from '../eduplatform_ui/platform-common/components/page-container';
import pagination from '../eduplatform_ui/platform-common/components/pagination';
import forms from '../eduplatform_ui/platform-common/components/forms';
// import ulSelect from '../eduplatform_ui/platform-common/components/ulSelect';
import ulAlert from '../eduplatform_ui/platform-common/plugins/plugin_dialog';
import ulToast from '../eduplatform_ui/platform-common/plugins/plugin_toast';
import ulButton from '../eduplatform_ui/platform-common/components/ul-button';
import ulButtonGroup from '../eduplatform_ui/platform-common/components/ul-button-group';
import popup from '../eduplatform_ui/platform-common/components/popup';
import dialog from '../eduplatform_ui/platform-common/components/dialog';


import ulPreloader from '../eduplatform_ui/platform-common/plugins/plugin_preloader';
import popover from "framework7-vue/components/popover";
import fa from "element-ui/src/locale/lang/fa";

//自定义指令
const popButton = {
    bind(el, binding, vnode) {
        if (binding.value == false) return
        if (binding.value.text) {
            el.disabled = true
            el.classList.add('square')
            el.classList.add('button')
            let cEl = document.createElement("div")
            cEl.innerText = binding.value.text;
            cEl.className = 'pover'
            el.appendChild(cEl);
        } else {
            el.disabled = true
            el.classList.add('square')
            el.classList.add('semiAutoIcon')
            el.classList.add('button')
            let cEl = document.createElement("div")
            cEl.innerText = "该功能需要在'半自动模式'下才能使用";
            cEl.className = 'pover'
            el.appendChild(cEl);
        }
        // vnode.context.$nextTick(() => {
        //     scroll.initScroll(el, binding, vnode);
        // });
    },
    update(el, binding, vnode) {
        if (binding.value == false) return
        if (binding.value.text) {
            el.disabled = true
            el.classList.add('square')
            el.classList.add('button')
            let cEl = document.createElement("div")
            cEl.innerText = binding.value.text;
            cEl.className = 'pover'
            el.appendChild(cEl);
        } else {
            el.disabled = true
            el.classList.add('square')
            el.classList.add('semiAutoIcon')
            el.classList.add('button')
            let cEl = document.createElement("div")
            cEl.innerText = "该功能需要在'半自动模式'下才能使用";
            cEl.className = 'pover'
            el.appendChild(cEl);
        }
        // vnode.context.$nextTick(() => {
        //     scroll.initScroll(el, binding, vnode);
        // });
    },
}

export function install(Vue) {
    Vue.directive('popButton', popButton)

    Vue.use(Table);
    Vue.use(TableColumn);
    Vue.use(Loading);
    Vue.use(Switch);
    Vue.use(Popover);
    Vue.use(Option);
    Vue.use(Select);
    Vue.use(Tabs);
    Vue.use(TabPane);
    Vue.use(Icon);
    Vue.use(dropdown);
    Vue.use(dropdownMenu);
    Vue.use(dropdownItem);
    Vue.use(datePicker);
    Vue.use(cascader);
    Vue.use(radio);
    // Vue.use(timePicker);


    // Vue.use(Main)

    // Vue.use(Container)
    // Vue.use(Header)
    // Vue.use(Aside)
    // Vue.use(Button)
    // Vue.use(Transfer)
    // Vue.use(Row)
    // Vue.use(Card)
    // Vue.use(ButtonGroup)
    // Vue.use(Input)
    Vue.use(Dialog);
    Vue.use(Checkbox);

    // Vue.use(Pagination)
    // Vue.use(Breadcrumb)
    // Vue.use(BreadcrumbItem)
    // Vue.use(FormItem)
    // Vue.use(Form)
    // Vue.use(Upload)
    // Vue.use(Checkbox)
    Vue.use(Tree);
    // Vue.use(Radio)
    // Vue.use(Select)
    // Vue.use(Option)
    // Vue.use(RadioGroup);
    Vue.use(ulAlert)
    Vue.use(ulToast)
    Vue.use(ulPreloader)

//注册自定义全局组件
    Vue.component(inputs.name, inputs);
    Vue.component(inputs_search.name, inputs_search);
    Vue.component(page_container.name, page_container);
    Vue.component(pagination.name, pagination);
    Vue.component(forms.name, forms);
    // Vue.component(ulSelect.name, ulSelect);
    Vue.component(CollapseTransition.name, CollapseTransition);
    Vue.component(inputTemplate.name, inputTemplate);
    Vue.component(ulButton.name, ulButton);
    Vue.component(ulButtonGroup.name, ulButtonGroup);
    Vue.component(popup.name, popup);
    Vue.component(dialog.name, dialog);
// Vue.use(CollapseTransition)

// Vue.component(CollapseTransition.name, CollapseTransition)


}