import XCodes from '@ul/xerror/codes';
import messages from '@ul/xerror/messages.esm';



// XCodes 10000-10999
XCodes.ACCOUNT_LENGTH_WRONG=10000;
XCodes.ACCOUNT_WRONG=10001;
XCodes.PASSWORD_LENGTH_WRONG=10002;
XCodes.CAP_LENGTH_WRONG=10003;
XCodes.LOGOUT_SUCCESS=10004;
XCodes.PASSWORD_CONFIRM_FAILED=10005;
XCodes.NOT_ALLOW=10006;




messages[XCodes.CAP_WRONG]='验证码输入错误，请重新输入新验证码';
messages[XCodes.CAP_EXPIRED]='验证码已过期，请重新输入新验证码';
messages[XCodes.ACCOUNT_LENGTH_WRONG]='用户名长度应该是6-24位';
messages[XCodes.ACCOUNT_WRONG]='用户名应该由字母数字及_@-.特殊符号组成';
messages[XCodes.PASSWORD_LENGTH_WRONG]='密码长度应该是6-24位';
messages[XCodes.CAP_LENGTH_WRONG]='验证码长度应该是4位字母或数字';
messages[XCodes.LOGOUT_SUCCESS]='注销成功';
messages[XCodes.PASSWORD_CONFIRM_FAILED]='密码确认失败，请再次确认密码';
messages[XCodes.NOT_ALLOW]='当前用户类型不能使用该应用，如有问题请联系管理员';
messages[XCodes.ACCOUNT_EXISTED]='用户已经存在';
messages[XCodes.ACCOUNT_NOT_EXIST]='用户不存在或者被禁用';
//老版本的错误
// XCodes.OLD_CAP_WRONG=513;

// XCodes.OLD_ACCOUNT_PASSWORD_WRONG=523;
// XCodes.OLD_ACCOUNT_NOT_EXIST=521;
// XCodes.OLD_PASSWORD_HAS_CHANGED=528;
// XCodes.OLD_TOKEN_INVALID=510;
//
// messages[XCodes.OLD_CAP_WRONG]=messages[XCodes.CAP_WRONG];

// messages[XCodes.OLD_ACCOUNT_PASSWORD_WRONG]=messages[XCodes.ACCOUNT_PASSWORD_WRONG];
// messages[XCodes.OLD_ACCOUNT_NOT_EXIST]=messages[XCodes.ACCOUNT_NOT_EXIST]='用户不存在或者被禁用';
// messages[XCodes.OLD_PASSWORD_HAS_CHANGED]='密码已在其他地方重置，请重新登录';
// messages[XCodes.OLD_TOKEN_INVALID]='用户凭据无效';

