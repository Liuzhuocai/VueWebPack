
export default {
    CLOSE_AUTO_SYNC:"close_auto_sync",
    SET_CAMPUS_INFO:"set_campus_info",
    USER_LOGOUT: 'user_logout',
    GET_USERINFO:'get_userinfo'
}