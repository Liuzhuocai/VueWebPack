import MUTATIONS from './MutationsType';
import ACTIONS from './ActionType';

let Vue = null;
export default {
    state: {
        UserInfo: null,
        ACCOUNT: null
    },
    getters: {
        isLoginned(state, getters, rootState) {
            if (state.UserInfo && Vue.$ajax.token) {
                return true;
            }
            return false;
        },
        userName(state, getters, rootState) {
            if (!state.UserInfo) return [];
            let payload = state.UserInfo;
            let a = [payload.uname]
            if (payload.oname) a.push(payload.oname)
            return a;
            switch (payload.SOURCETYPE) {
                case USER_CONFIG.USERTYPE_STUDENT://学生
                    let b = [payload.XM, payload.SCHOOLNAME];
                    if (payload.CAMPUSCOUNT > 1) {
                        b[1] = b[1] + ' (' + payload.CAMPUSNAME + ')';
                    }
                    return b;
                case USER_CONFIG.USERTYPE_EMPLOYEE://职员
                    let a = [payload.EMPLOYEENAME, payload.ORGNAME]
                    if (payload.CAMPUSCOUNT > 1) {
                        a[1] = a[1] + ' (' + payload.CAMPUSNAME + ')';
                    }
                    return a;
                case USER_CONFIG.USERTYPE_SCHOOL_CAMPUS://校区
                    let c = [null, payload.SCHOOLNAME, null]
                    if (payload.CAMPUSCOUNT > 1) {
                        c[2] = ' (' + payload.CAMPUSNAME + ')';
                    }
                    return c;
                case USER_CONFIG.USERTYPE_SCHOOL://学校
                    return [payload.SCHOOLNAME]
                case USER_CONFIG.USERTYPE_ORG://直属机构/其他机构
                    return [payload.INSTITUTIONNAME]
                case USER_CONFIG.USERTYPE_BUREAU://教育局
                    return [payload.BUREAUNAME];
            }
        },
        NAME(state, getters, rootState) {
            let a = getters.userName;
            if (a.length == 1 || a.length == 2) {
                return a[0];
            } else if (a.length == 3) {
                return a[1];
            }
            return '';
        },
        ORGNAME(state, getters, rootState) {
            let a = getters.userName;
            if (a.length == 2) {
                return a[1];
            } else if (a.length == 3) {
                return a[2];
            }
            return '';
        },
        ANYNAME(state, getters, rootState) {
            let payload = state.UserInfo;
            if (payload) {
                switch (payload.SOURCETYPE) {
                    case USER_CONFIG.USERTYPE_STUDENT://学生
                        let a = payload.GRADE;
                        if (payload.GW_XS_JBXX_ID) {
                            a += '来自国网';
                        } else {
                            a += '学校自增';
                        }
                        return a;
                }
            }
            return '';
        }

    },


    mutations: {
        [MUTATIONS.UPDATE_USERINFO]: function (state, payload) {
            if (payload) {
                state.UserInfo = payload;
                window.sessionStorage.setItem(Vue.$CONFIG.APPID + 'U', JSON.stringify(payload));
            } else {
                state.UserInfo = null;
                window.sessionStorage.removeItem(Vue.$CONFIG.APPID + 'U');
            }
        },
        [MUTATIONS.UPDATE_ACCOUNT]: function (state, payload) {
            if (payload) {
                state.ACCOUNT = payload;
                window.sessionStorage.setItem(Vue.$CONFIG.APPID + 'A', payload);
            } else {
                state.ACCOUNT = null;
                window.sessionStorage.removeItem(Vue.$CONFIG.APPID + 'A');
            }
        },
    },
    actions: {
        [ACTIONS.GET_USERINFO](context, params) {
            return this._vm.$ajax.post(Vue.$CONFIG.GET_USERINFO_URL, params).then(d => {
                context.commit(MUTATIONS.UPDATE_USERINFO, d.user);
                return d;
            });
        },
        [ACTIONS.USER_LOGOUT]: function (context, params) {
            context.commit(MUTATIONS.UPDATE_USERINFO, null);
            if (params) {
                if (params.token === false) {
                    return;
                }
            }
            this._vm.$ajax.token = null;
        }
    }
};

export function userPlugin(store) {
    Vue = store._vm;
    let u = window.sessionStorage.getItem(Vue.$CONFIG.APPID + 'U');
    // store.commit(MUTATIONS.UPDATE_ACCOUNT, window.sessionStorage.getItem(Vue.$CONFIG.APPID + 'A'));
    if (u) {
        store.commit(MUTATIONS.UPDATE_USERINFO, JSON.parse(u));
    }

}
