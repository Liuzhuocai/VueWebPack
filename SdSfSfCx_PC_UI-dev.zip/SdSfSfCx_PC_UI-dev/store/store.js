import Vuex from 'vuex/dist/vuex.esm';
import Vue from 'vue/dist/vue.runtime.esm';

import user_model, {userPlugin} from './user_module';
import key_model from '../../eduplatform_ui/platform-common/stores/modules/key_module';
import common_model from '../../eduplatform_ui/platform-common/stores/modules/breadcrumb_module';

import MUTATIONS_TYPE from './MutationsType'
import USER_MUTATIONS from '../../eduplatform_ui/platform-common/stores/mutations/user_mutations'
import ACTION_TYPE from './ActionType'
import fa from "element-ui/src/locale/lang/fa";
// import CONFIG from '../config';

Vue.use(Vuex);

// const initData = function (store) {
//     let storeage = window.sessionStorage.getItem(CONFIG.APPID + 'U');
//     storeage && store.commit(MUTATIONS_TYPE.UPDATE_USERINFO, JSON.parse(storeage))
// };


const store = new Vuex.Store({
        strict: false,
        plugins: [userPlugin],//是一个函数内容，其函数参数是store
        modules: {
            user: user_model,
            key_model,
            common_model
        },
        state: {
            // switch_automatic: true,
        },
        getters: {
            isST(state, getters, rootState) {
                return state.user.UserInfo && state.user.UserInfo.otype == 1 && state.user.UserInfo.level == 1;
                // return true;
            },
            isQX(state, getters, rootState) {
                if (state.user.UserInfo && state.user.UserInfo.otype && state.user.UserInfo.level) {
                    return state.user.UserInfo && state.user.UserInfo.otype == 1 && state.user.UserInfo.level == 3;
                } else {
                    return true
                }
            },
            isGX(state, getters, rootState) {
                if (state.user.UserInfo && state.user.UserInfo.otype) {
                    return state.user.UserInfo && state.user.UserInfo.otype == 4;
                } else {
                    return true;
                }
            },
        },
        mutations: {
            // [MUTATIONS_TYPE.SWITCH_AUTOMATIC]: function (state, val) {
            //     state.user.UserInfo.ISMANUAL = val;
            // },
        },
        actions: {}
    })
;
export default store;
