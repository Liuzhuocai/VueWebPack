export default {
    SET_BREADCRUMB: 'set_breadcrumb',
    SWITCH_AUTOMATIC: 'switch_automatic',
    UPDATE_USERINFO: 'update_userinfo',
    UPDATE_ACCOUNT: 'update_account',
}