<template>
    <popup ref="popup" :destory-on-hide="false">
        <dialogs title="选择年级主任" column height="100%">
            <!--            <div class="dialog">-->
            <!--                <div class="dialog-title">-->
            <!--                    <div class="dialog-title-row">-->
            <!--                        <div class="dialog-title-column dialog-main-title">-->
            <!--                            <span>选择年级主任</span>-->
            <!--                        </div>-->
            <!--                        <div class="dialog-title-column">-->
            <!--                        </div>-->
            <!--                    </div>-->
            <!--                    <div class="dialog-title-row dialog-toolbar">-->
            <!--                        <div class="dialog-title-column">-->
            <!--                            <inputs-search @searched="handleSearched"></inputs-search>-->
            <!--                        </div>-->
            <!--                        <div class="dialog-title-column buttons">-->
            <!--                            <div class="button white" @click="cancel">取消</div>-->
            <!--                            <div class="button" @click="ok">确定</div>-->
            <!--                        </div>-->
            <!--                    </div>-->
            <!--                </div>-->

            <!--                <div class="dialog-content column" style="flex: 1 1 auto">-->
            <div class="dialog-toolbar">
                <div class="toolbar-cell">
                    <inputs-search @searched="handleSearched" ref="search" class="with-table"></inputs-search>
                </div>
                <div class="toolbar-cell">
                    <ul-button class="secondary" @click="cancel">取消</ul-button>
                    <ul-button class="secondary" @click="ok(0)">设为"无"</ul-button>
                    <ul-button @click="ok">确定</ul-button>
                    <!--                    <ul-button type="secondary" label="取消" @click="cancel"></ul-button>-->
                    <!--                    <div class="button secondary" @click="cancel">取消</div>-->
                    <!--                    <ul-button @click="ok" label="确定"></ul-button>-->
                </div>
            </div>
            <el-table
                    height="100%"
                    border
                    :data="list"
                    v-scroll:el-table
                    highlight-current-row
                    @row-click="handleRowClick"
            >
                <el-table-column label="序号" type="index" :index="$refs.pager&&$refs.pager.indexMethod" align="center"
                                 width="50"></el-table-column>
                <el-table-column label="姓名" property="EMPLOYEENAME" width="200"></el-table-column>
                <el-table-column label="性别" property="GENDERNAME" width="80">
                </el-table-column>
                <el-table-column label="身份证件号" property="IDCARD" width="200"></el-table-column>
                <el-table-column label="电话" property="TELEPHONE" width="200"></el-table-column>
                <el-table-column label="部门" property="DEPARTMENTNAME"
                                 :show-overflow-tooltip="true"></el-table-column>

            </el-table>
            <pagination
                    :total="total"
                    @change="handlePageChange"
                    ref="pager"
                    :page="page"
            ></pagination>
            <!--                </div>-->
            <!--            </div>-->
        </dialogs>
    </popup>
</template>

<script>
    import dialogs from '../../eduplatform_ui/platform-common/components/dialog';
    import ACTIONS_TYPE from '../store/ActionType';

    import popup from '../../eduplatform_ui/platform-common/components/popup.vue';
    import popup_mixin from '../../eduplatform_ui/platform-common/mixins/popup_mixin';

    export default {
        name: "dialog-select-employee",
        components: {dialogs, popup},
        // extends: popup,
        mixins: [popup_mixin],
        data() {
            return {
                total: 0,
                page: 1,
                list: [],
                rowData: {},
            }
        },
        props: {
            title: '',
            subTitle: '',
        },
        created() {
            // this.$store.dispatch(ACTIONS_TYPE.GET_EMPLOYEES_DATA,{page:1})
            //     .then(d=>{
            //         this.list = d.data;
            //         this.total = d.total;
            //         // this.page = 1;
            // })
            this.$ajax.post("/api/school/getEmployees", {}).then(d => {
                    this.list = d;
                }
            )
        },
        // mounted() {
        //     console.log(this.show)
        // },
        methods: {
            handleSearched(val) {
                // this.$store.dispatch(ACTIONS_TYPE.GET_EMPLOYEES_DATA,{page:1,orgname:val})
                //     .then(d=>{
                //         this.list = d.data;
                //         this.total = d.total;
                //         // this.page = 1;
                //     })

                this.$ajax.post("/api/school/getEmployees",
                    // {"_campusid":"9126CA2139D829ECE053D70AA8C0EFC5","EMPLOYEENAME":val}).then(
                    {"EMPLOYEENAME": val}).then(
                    d => {
                        // console.log(d)
                        this.list = d;
                        this.total = d.length;
                    }
                )
            },
            ok(v) {
                if (v == 0) {
                    this.$emit('ok', {PT_EMPLOYEEID: ''})
                    this.rowData = {}
                    this.hide();
                    return
                }
                this.$emit('ok', 'PT_EMPLOYEEID' in this.rowData ? this.rowData : null)
                this.rowData = {}
                this.hide();
            },
            cancel() {
                this.rowData = {}
                this.hide();
            },
            handlePageChange(val) {
                this.$store.dispatch(ACTIONS_TYPE.GET_EMPLOYEES_DATA, {page: val})
                    .then(d => {
                        this.list = d.data;
                        this.total = d.total;
                        // this.page =val;
                    })
            },
            handleRowClick(val) {
                this.rowData = val;
            },
        }
    }
</script>

