<template>
    <div class="indexContainer">
        <banner label="四川省教师违反职业道德信息查询系统" class="app"></banner>
        <div class="index-content">
            <div class="index-frame">
                <transition appear>
                    <slot></slot>
                </transition>
                <transition appear>
                    <router-view class="index-frame-content"></router-view>
                </transition>
            </div>
        </div>
    </div>
</template>
<script>
    import KEY_ACTIONS from '../../eduplatform_ui/platform-common/stores/actions/key_actions'
    import USER_ACTIONS from '../../eduplatform_ui/platform-common/stores/actions/user_actions'
    import querystring from "querystring";
    import MUTATIONS from '../../eduplatform_ui/platform-common/stores/mutations/user_mutations';
    import banner from '../../eduplatform_ui/platform-common/components/banner';
    import XError from '@ul/xerror';

    export default {
        name: "main-page",
        components: {banner},
        props: {
            pageTitle: ''
        },
        directives: {
            ellipsis: {
                // 指令的定义
                // inserted: function (el,binding,vnode) {
                //     console.log(arguments)
                //     console.log(1)
                // },
                update: function (el, binding, vnode) {
                    let len = binding.value && parseInt(binding.value);
                    if (len && el.innerText.length > len) {
                        el.innerText = el.innerText.substr(0, len) + '…';
                    }
                }

            }
        },
        data() {
            return {
                activeMenuId: 0,
                activeMenuUrl: '',
                menuList: [],
                // currentPage:'',
                // showBase:true
            }
        },
        beforeMount() {

        },

        mounted() {
            // this.$root.getMenus({SOURCETYPE:'130'});
            this.getUserInfo();
        },

        methods: {
            selectMenu(item, index) {
                this.activeMenuUrl = item.path;
                // if(this.activeMenuId==item.id) return;
                // this.showBase=item.id==1;
                // this.activeMenuId=item.id;
                // this.$router.push(item.url)
            },
            // getMenus() {
            //     this.menuList = [
            //         {name: '本单位基本信息', id: 1, url: '/index'},
            //         {name: '下属单位', id: 2, url: '/subordinate'},
            //         {name: '直属单位', id: 4, url: '/directlyunder'},
            //         {name: '内设部门', id: 5, url: '/internal'},
            //         {name: '本单位职员', id: 6, url: '/employee'},
            //         {name: '直属学校', id: 7, url: '/school'},
            //         {name: '其他机构', id: 8, url: '/others'},
            //         {name: '职员绑定开关', id: 9, url: '/boundswitch'},
            //         {name: '职员绑定管理', id: 10, url: '/boundmanage'},
            //     ];
            //
            //
            // },
            getWaterMark() {
                let canvas = document.createElement('canvas');
                let size = 100;
                let lineHeight = 18
                let context = canvas.getContext('2d');
                let name = [];
                if (this.$store.state.user.UserInfo.uname) {
                    name.push(this.$store.state.user.UserInfo.uname)
                }
                if (this.$store.state.user.UserInfo.oname) {
                    name.push(this.$store.state.user.UserInfo.oname)
                }
                if (this.$store.state.user.UserInfo.login_time) {
                    name.push(this.$store.state.user.UserInfo.login_time)
                }
                if (this.$store.state.user.UserInfo.ip) {
                    name.push(this.$store.state.user.UserInfo.ip)
                }
                let width = [];
                for (let i of name) {
                    let w = context.measureText(i).width
                    width.push(w);
                    size = Math.max(size, w)
                }
                size = size * 3;
                canvas.width = canvas.height = size;
                context.font = "bold 16px 微软雅黑";
                context.textBaseline = 'bottom'
                context.fillStyle = 'rgba(0,0,0,0.06)';
                context.textAlign = 'center'
                let gap = size * 0.3;
                // let width=context.measureText(name).width;
                let d = 45 * (Math.PI / 180);
                let textHeight = (-name.length * lineHeight >> 1) + (-gap >> 1);
                // textHeight=0
                context.translate(size >> 1, size >> 1)
                context.rotate(-d)
                let j = 0
                for (let i of name) {
                    // context.fillText(i, -width[j]>>1, textHeight+j*lineHeight);
                    context.fillText(i, 0, textHeight + j * lineHeight);
                    if ((name.length == 3 && j == 0) || (name.length == 4 && j == 1)) {
                        textHeight += gap
                    }
                    j++
                }
                let url = canvas.toDataURL('image/png')
                let style = document.createElement('style');
                style.type = 'text/css';
                style.innerHTML =
                    // "    * {\n" +
                    // "            background-color: transparent;\n" +
                    // "            background-image: url(" + url + ");\n" +
                    // // "            pointer-events: none;\n" +
                    // // "            height: 100%;\n" +
                    // // "            width: 100%;\n" +
                    // // "            position: absolute;\n" +
                    // // "            z-index: 100000;\n" +
                    // "        };  " +
                    "  .watermark {\n" +
                    "            background-color: transparent;\n" +
                    "            background-image: url(" + url + ");\n" +
                    "            pointer-events: none;\n" +
                    "            height: 100%;\n" +
                    "            width: 100%;\n" +
                    "            position: absolute;\n" +
                    "            z-index: 100000;\n" +
                    "        };";
                document.getElementsByTagName('head').item(0).appendChild(style);
            },
            getUserInfo() {
                // this.getWaterMark()
                //启动的时候去获取地址栏的token参数
                const search = querystring.parse(window.location.search.substr(1));
                /* IFDEBUG */
                if (this.$CONFIG.testToken && !this.$store.getters.isLoginned) {
                    search.token = this.$CONFIG.testToken;
                }
                /* FIDEBUG */
                if (search.token) {
                    search.token = search.token.replace(/\-/g, '+').replace(/\_/g, '/');//对地址栏的token进行转码
                    this.$ajax.token = search.token;//把token给ajax
                    const path = window.location.href.substr(0, window.location.href.indexOf('?'));
                    window.history.replaceState(null, '', path);
                    delete search.token
                    this.$showPreloader('获取用户信息...');
                    Promise.all([
                        this.$store.dispatch(KEY_ACTIONS.GET_SERVER_KEY_FOR_ENCRYPT),
                        this.$store.dispatch(KEY_ACTIONS.GET_SERVER_KEY_FOR_SIGN)
                    ]).then(d => {
                        return this.$store.dispatch(USER_ACTIONS.GET_USERINFO, {token: this.$ajax.token});
                    }).then(d => {
                        if (this.$root.getPermission(d) == false) {
                            throw XError.C(this.$XCODES.NOT_ALLOW);
                        }
                        this.$store.commit(MUTATIONS.UPDATE_USERINFO, d.user);
                        this.getWaterMark()
                        this.$router.replace('/index');
                        this.$root.$emit('login:success');
                    }).catch(e => {
                        if (!e) return;
                        let title = '获取用户信息失败';
                        if (e.code == this.$XCODES.NOT_ALLOW) {
                            title = '没有权限'
                            this.$store.dispatch(USER_ACTIONS.USER_LOGOUT);
                        }
                        this.$showAlert(e.message, () => {
                            window.close()
                        }, title, '确定');
                    }).finally(() => {
                        this.$hidePreloader();
                    })
                } else if (this.$store.getters.isLoginned) {
                    this.getWaterMark()
                    this.menuList = this.$root.getMenus();
                    if (this.$router.currentRoute.path == '/') {
                        this.$router.replace('/index');
                    }
                } else if (!this.$store.getters.isLoginned) {
                    this.$showAlert('您或许无权限使用系统,点击确定后将会关闭当前窗口，<br>若未自动关闭当前窗口，请手动关闭后返回平台重新登陆', () => {
                        window.close()
                        this.$showPreloader('请关闭当前窗口...');
                    }, '需要返回平台重新登录，本页面即将关闭', '确定')
                }
            }
        }
    }
</script>

<style type="less">
    @import (reference) '../../eduplatform_ui/platform-common/assets/less/web_base';

    .indexContainer {
        display: flex;
        min-width: @minViewWidth;
        flex-direction: column;
        height: 100%;

        .app {
            flex-shrink: 0;

            .banner-title {
                font-weight: bold;
                font-size: 15px;
            }
        }

        .index-content {
            display: flex;
            background-image: url("../assets/imgs/web_bg_img.png");
            background-size: 100% 100%;
            flex: 1 1 auto;
            height: 1px;
            //height: 100%;
            overflow: auto;
            justify-content: center;
        }

        .index-frame {
            position: relative;
            width: 1200px;
            box-sizing: border-box;

            &-content {
                position: absolute;
                top: 0;
                left: 0;
                /*height: 100%;*/
                width: 100%;
                z-index: 2;
            }

            .v-enter {
                opacity: 0;
                transform: translateX(20px);
                z-index: 3;
            }

            .v-enter-active, .v-leave-active {
                transition: all 0.2s cubic-bezier(.1, .51, .35, 1.31);
            }

            .v-enter-to, .v-leave {
                opacity: 1;
                transform: translateX(0);
            }

            .v-leave-active {
                transition-delay: 100ms;
            }

            .v-leave-to {
                opacity: 0;
            }
        }
    }
</style>