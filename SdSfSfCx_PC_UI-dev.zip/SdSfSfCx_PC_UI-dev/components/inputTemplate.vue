<template>
    <div style="height:180px;" v-if="i.inputType=='photo'">照片</div>
    <inputs ref="inputs" :value="ruleform[i.prop]" :name="i.prop" v-else-if="i.inputType=='select'" :label="i.label" :required="i.requireCode">
        <el-select @blur="blurValidate" v-model="ruleform[i.prop]" :placeholder="(disableds[i.prop]&&disableds[i.prop].placeholder)||'请选择'"
                   :disabled="disableds[i.prop]&&(disableds[i.prop].importantDisableds?disableds[i.prop].importantDisableds:disableds[i.prop].disabled)"
                   @change="selectChange(i.prop,ruleform[i.prop])">
            <el-option :label="j.label" :value="j.value" v-for="j in codeValueList[i.prop].list"></el-option>
        </el-select>
    </inputs>
    <inputs ref="inputs" :value="ruleform[i.prop]" :name="i.prop" v-else-if="i.inputType=='datePicker'" :label="i.label" :required="i.requireCode">
        <el-date-picker
                @blur="blurValidate"
                style="width:auto"
                v-model="ruleform[i.prop]"
                value-format="yyyyMMdd"
                placeholder="选择日期"
                :disabled="disableds[i.prop]&&(disableds[i.prop].importantDisableds?disableds[i.prop].importantDisableds:disableds[i.prop].disabled)"
        >
        </el-date-picker>
    </inputs>
    <inputs ref="inputs" :value="ruleform[i.prop]" :name="i.prop" v-else-if="i.inputType=='monthDatePicker'" :label="i.label" :required="i.requireCode"
            :static="disableds[i.prop]&&(disableds[i.prop].importantDisableds?disableds[i.prop].importantDisableds:disableds[i.prop].disabled)">
        <el-date-picker
                @blur="blurValidate"
                style="width:auto"
                v-model="ruleform[i.prop]"
                type="month"
                value-format="yyyyMM"
                placeholder="选择月"
                :disabled="disableds[i.prop]&&(disableds[i.prop].importantDisableds?disableds[i.prop].importantDisableds:disableds[i.prop].disabled)"
        >
        </el-date-picker>
    </inputs>
    <inputs ref="inputs" :value="ruleform[i.prop]" :name="i.prop" v-else-if="i.inputType=='rangeDatePicker'" :label="i.label" :required="i.requireCode">
        <el-date-picker
                @blur="blurValidate"
                v-model="ruleform[i.prop]"
                type="monthrange"
                range-separator="至"
                start-placeholder="开始月份"
                end-placeholder="结束月份"
                :disabled="disableds[i.prop]&&(disableds[i.prop].importantDisableds?disableds[i.prop].importantDisableds:disableds[i.prop].disabled)"
        >
        </el-date-picker>
    </inputs>
    <inputs ref="inputs" :value="ruleform[i.prop]" :name="i.prop" v-else-if="i.inputType=='cascader'" :label="i.label" :required="i.requireCode">
        <el-cascader @blur="blurValidate" :props="cascaderProps" :disabled="disableds[i.prop]&&(disableds[i.prop].importantDisableds?disableds[i.prop].importantDisableds:disableds[i.prop].disabled)"></el-cascader>
    </inputs>
    <inputs ref="inputs" :value="ruleform[i.prop]" :name="i.prop" v-else-if="i.inputType=='radio'" :label="i.label" :type="i.inputType?i.inputType:'text'" v-model="ruleform[i.prop]"
            :required="i.requireCode" :static="disableds[i.prop]&&(disableds[i.prop].importantDisableds?disableds[i.prop].importantDisableds:disableds[i.prop].disabled)"
            :groups="codeValueList[i.prop].list"></inputs>
    <inputs ref="inputs" :value="ruleform[i.prop]" :name="i.prop" v-else-if="!i.inputType" :label="i.label" :type="i.inputType?i.inputType:'text'" v-model="ruleform[i.prop]"
            :required="i.requireCode" :static="disableds[i.prop]&&(disableds[i.prop].importantDisableds?disableds[i.prop].importantDisableds:disableds[i.prop].disabled)"></inputs>
</template>

<script>
    export default {
        name: "inputTemplate",
        props: {
            item: {},
            ruleform: {},
            disableds: {},
            codeValueList: {},
            cascaderProps: {},
        },
        data() {
            return {}
        },
        mounted() {
        },
        computed: {
            i() {
                return this.item
            },
            // ruleform() {
            //     return this.pRuleform
            // },
            // disableds() {
            //     return this.pDisableds
            // },
            // codeValueList() {
            //     return this.pCodeValueList
            // },
            // cascaderProps() {
            //     return this.pCascaderProps
            // }
        },
        methods: {
            checkChild() {
                return this.$refs.inputs;
            },
            selectChange(prop, v) {
                this.$emit('selectChange', prop, v)
            },
            blurValidate() {
                this.$refs.inputs.handleBlur()
            }
        }
    }
</script>

<style scoped>

</style>