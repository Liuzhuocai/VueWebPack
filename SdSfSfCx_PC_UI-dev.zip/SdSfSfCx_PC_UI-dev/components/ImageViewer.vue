<template>
    <el-dialog :visible.sync="visible" append-to-body custom-class="imagePreview" top="0" @close="mClose">
        <div class="closeBtn" @click="mClose"><i class="el-icon-close"></i></div>
        <div class="imgContainer" @click.self="mClose">
            <div class="imgOutContainer" @click.self="mClose">
                <!--                <img :src="url" alt="图片加载失败" @mousedown="mouseE($event,'down')" @mousemove="mouseE($event,'move')"-->
                <!--                     @mouseup="mouseE($event,'up')" @mousewheel="mouseE($event,'wheel')" :style="cStyle">-->
                <div @mousedown="mouseE($event,'down')" @mousemove="mouseE($event,'move')"
                     @mouseup="mouseE($event,'up')" @mousewheel="mouseE($event,'wheel')" :style="cStyle"></div>
            </div>
        </div>
        <div class="imgViewToolbar">
            <i class="el-icon-zoom-in" title="放大" @click="handleImg(1)"></i>
            <i class="el-icon-zoom-out" title="缩小" @click="handleImg(2)"></i>
            <i class="el-icon-refresh" title="还原" @click="handleImg(5)"></i>
            <i class="el-icon-refresh-left" title="向左旋转90°" @click="handleImg(3)"></i>
            <i class="el-icon-refresh-right" title="向右旋转90°" @click="handleImg(4)"></i>
        </div>
    </el-dialog>
</template>

<script>
    export default {
        name: "image-viewer",
        data() {
            return {
                // dialogVisible:false,
                posX: 0,
                posY: 0,
                mouseD: false,
                oldMousePos: {X: 0, Y: 0},
                currentDeg: 0,
                currentRate: 1,
                imageSize: null,
                cStyle: ''
            }
        },
        props: {
            url: {required: true, type: String, default: ''},
            visible: {required: true, type: Boolean, default: false},
        },
        watch: {
            url(v) {
                // let image = new Image()
                // image.src = v
                let image = {width: 500, height: 500}
                this.imageSize = {width: image.width, height: image.height}
                // this.posX = -image.width / 2
                // this.posY = -image.height / 2
                this.oldMousePos = {X: this.posX, Y: this.posY}
                this.setStyle()
            }
        },
        methods: {
            setStyle() {
                let cStyle = `transition: ${this.mouseD ? 'none' : 'transform 230ms'};
            transform:rotate(${this.currentDeg * 90}deg) scale(${parseInt(this.currentRate * 100) / 100});
             margin-left:${this.posX}px;margin-top:${this.posY}px;background-image:url(${this.url});background-size:contain;background-repeat:no-repeat;background-position:center center;
            `
                // margin-left:${this.posX}px;margin-top:${this.posY}px;
                if (this.imageSize) cStyle += `width:${this.imageSize.width}px;height:${this.imageSize.height}px;`
                this.cStyle = cStyle
            },
            mouseE(e, m) {
                if (m == 'wheel') {
                    this.handleImg(e.deltaY > 0 ? 2 : 1)
                }
                if (m == 'down') {
                    this.mouseD = true
                    const x = this.oldMousePos.X, y = this.oldMousePos.Y
                    this.oldMousePos = {X: e.clientX - x, Y: e.clientY - y}
                    this.setStyle()
                }
                if (m == 'move' && this.mouseD) {
                    this.posX = (e.clientX - this.oldMousePos.X)
                    this.posY = (e.clientY - this.oldMousePos.Y)
                    this.setStyle()
                }
                if (m == 'up' && this.mouseD) {
                    this.mouseD = false
                    this.oldMousePos = {X: this.posX, Y: this.posY}
                    this.setStyle()
                }
                e.preventDefault()
                return false
            },
            mClose() {
                this.mouseD = false
                // this.posY = -this.imageSize.height / 2
                // this.posX = -this.imageSize.width / 2
                this.posY = 0
                this.posX = 0
                this.oldMousePos = {X: this.posX, Y: this.posY}
                // this.visible=false
                this.$emit('close', null)
                setTimeout(() => {
                    this.currentDeg = 0
                    this.currentRate = 1
                    this.setStyle()
                }, 201)
            },
            handleImg(m) {
                this.mouseD = false
                switch (m) {
                    case 1:
                        if (this.currentRate <= 0.1) this.currentRate += 0.01
                        else this.currentRate += 0.1
                        break
                    case 2:
                        if (this.currentRate < 0.02) break
                        if (this.currentRate <= 0.1) this.currentRate -= 0.01
                        else this.currentRate -= 0.1
                        this.currentRate = parseInt(this.currentRate * 100) / 100
                        break
                    case 3:
                        this.currentDeg -= 1
                        break
                    case 4:
                        this.currentDeg += 1
                        break
                    case 5:
                        this.currentDeg = 0
                        this.currentRate = 1
                        // this.posY = -this.imageSize.height / 2
                        // this.posX = -this.imageSize.width / 2
                        this.posY = 0
                        this.posX = 0
                        this.oldMousePos = {X: this.posX, Y: this.posY}
                        break
                }
                this.setStyle()
            },
        },
    }
</script>

<style scoped>
    .el-dialog__wrapper {
        overflow: hidden;
    }

</style>
