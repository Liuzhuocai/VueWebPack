<template>
    
</template>

<script>
    export default {
        name: "ulAccordion"
    }
</script>

<style scoped>

</style>