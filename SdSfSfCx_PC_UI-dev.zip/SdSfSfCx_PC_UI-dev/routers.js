import VueRouter from 'vue-router/dist/vue-router.esm';
import Vue from 'vue/dist/vue.runtime.esm';
import Store from './store/store';
import MUTATIONS_TYPE from './store/MutationsType';
import CONFIG from './config';


import index from "./pages/index";
import searchResult from "./pages/searchResult";
import recordDetails from "./pages/recordDetails";
import recordAddEdit from "./pages/recordAddEdit";
import recordList from "./pages/recordList";
import uLogList from "./pages/uLogList";
import logDetails from "./pages/logDetails";
import searchManage from "./pages/searchManage";
import searchLogList from "./pages/searchLogList";


import routelib, {config as routeconfig} from '../eduplatform_ui/platform-common/libs/router_lib';


routeconfig.prefix = Vue.prototype.$CONFIG.APPID;
routeconfig.store = Store;


// function formatNav(route) {
//     const query = route.query;
//     let treeNameList = []
//     if (query.id) {
//         let tree = window.sessionStorage.getItem(CONFIG.APPID + 'INTERNAL_TREE');
//         if (tree) {
//             tree = JSON.parse(tree);
//             let node = tree[query.id];
//             while (node) {
//                 treeNameList.unshift({ name: node.name, url: node.url, active: true });
//                 node = tree[node.parent];
//             }
//         }
//     }
//     return treeNameList;
// }


Vue.use(VueRouter);
const RoutesHash = {};
const Routes = [
    {
        path: '/index',
        name: '首页',
        alias: '/', //别名
        component: index,
    },
    {
        name: '查询管理',
        path: '/searchManage',
        component: searchManage,
    },
    {
        name: '查询结果',
        path: '/searchResult',
        component: searchResult,
    },
    {
        name: '记录详情',
        path: '/recordDetails',
        component: recordDetails,
    },
    {
        name: '新增/修改记录',
        path: '/recordAddEdit',
        component: recordAddEdit,
    },
    {
        name: '我单位录入的失范记录',
        path: '/recordList',
        component: recordList,
    },
    {
        name: '操作日志',
        path: '/uLogList',
        component: uLogList,
    },
    {
        name: '日志详情',
        path: '/logDetails',
        component: logDetails,
    },
    {
        name: '查询日志',
        path: '/searchLogList',
        component: searchLogList,
    },
];

//为了面包屑而转化路由
// function initRoutes(routes, parentRoute, rootRoutes) {
//     for (let i of routes) {
//         if (parentRoute) {
//             i.meta = i.meta || {};
//             i.meta.parent = parentRoute;
//             if (i.path[0] == '/') {
//                 i.path = parentRoute.path + i.path;
//             } else {
//                 i.path = parentRoute.path + '/' + i.path;
//             }

//         }
//         RoutesHash[i.path] = i;
//         rootRoutes.push(i);
//         if (i.children && i.children.length) {
//             initRoutes(i.children, i, rootRoutes);
//             delete i.children;
//         }
//     }
//     return rootRoutes;
// }

const VueRoutes = new VueRouter({
    // routes: initRoutes(Routes, null, []),
    routes: routelib.initRoutes(Routes, null, [], RoutesHash),
    routesHash: RoutesHash
});

//处理面包屑的数据
VueRoutes.afterEach(
    //     (to, from) => {
    //     if (to && to.matched.length) {
    //         let bc = [{ name: to.name, url: to.fullPath, active: true }];
    //         // console.log('op');
    //         if (to.meta && to.meta.formatNav) {
    //             bc[0].url = to.path;
    //             if (!to.meta.navPosition) {
    //                 bc = bc.concat(to.meta.formatNav(to));
    //             } else {
    //                 bc = to.meta.formatNav(to).concat(bc);
    //             }
    //         }

    //         while (to) {
    //             if (to.meta && to.meta.parent) {
    //                 to = to.meta.parent;
    //                 bc.unshift({ name: to.name, url: to.path, active: true });
    //             } else {
    //                 to = null;
    //             }
    //         }
    //         bc[bc.length - 1].active = false;
    //         Store.commit(MUTATIONS_TYPE.SET_BREADCRUMB, bc);
    //         // this.

    //     }
    // }
    routelib.afterEach
);

export default VueRoutes;
