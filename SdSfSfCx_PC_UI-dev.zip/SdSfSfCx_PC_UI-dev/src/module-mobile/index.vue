<template>
    <f7-page class="index" @click.native="clickPage">
        <div class="loginBtn login" @click="showMenu=true">
            <i class="ico ico-avator"></i>
            <span class="vertical-align-middle label">{{userName}}</span>
            <div class="loginBtn-menu" v-if="showMenu">
                <div class="arrow"></div>
                <div class="menus">
                    <div class="menu" @click="changePassword()">
                        <i class="ico ico-lock"></i>
                        <span>修改密码</span>
                    </div>
                    <div class="menu" @click="logout(false)">
                        <i class="ico ico-off"></i>
                        <span>退出登录</span>
                    </div>
                </div>
            </div>
        </div>
        <img src="../assets/imgs/mobile/mobile_banner_img.png" alt="" class="banner">
        <div class="public-service my-apps" style="border-bottom-left-radius:0; border-bottom-right-radius:0;">
            <div class="public-service-info" v-once>
                <div class="public-service-title">我的应用</div>
                <div class="public-service-desc">
                    <p>与我相关的应用</p>
                </div>
            </div>
            <transition-group name="apps-animate" tag="div" class="apps" >
                <app v-for="(item,index) in myAppList" :app-info="item" :key="item.AUTH_CODE" ></app>
            </transition-group>
        </div>
        <div class="gap"></div>
        <div class="public-service normal public-apps" style="">
            <div class="public-service-info" v-once>
                <div class="public-service-title">公众服务</div>
                <div class="public-service-desc">
                    <p>面向社会大众开放的公众服务</p>
<!--                    <p>无需进行身份验证的服务</p>-->
                </div>
            </div>
            <transition-group name="apps-animate" tag="div" class="apps" >
                <app v-for="(item,index) in publicAppList" :app-info="item"  :key="item.AUTH_CODE"></app>
            </transition-group>
        </div>
        <div class="gap"></div>
        <div class="public-service normal level-apps" style="">
            <div class="public-service-info" >
                <div class="public-service-title">各级应用</div>
                <div class="public-service-desc">
                    <p>按应用的提供者(或应用接入申请者)类型，列出了与你相关的应用。</p>
                </div>
            </div>
            <div class="levels-apps-filter">
                <div class="level" v-for="item in levelList" :class="{active:currentLevel==item.type}"  @click="currentLevel=item.type">{{item.name}}</div>
            </div>
            <transition-group name="apps-animate" tag="div" class="apps" >
                <app v-for="(item,index) in levelAppList" :app-info="item" :key="item.AUTH_CODE" :index="index+1"></app>
            </transition-group>
        </div>
        <footers></footers>
    </f7-page>
</template>

<script>
    import ACTIONS_TYPE from '../stores/ActionsType';
    import MUTATIONS_TYPE from '../stores/MutationsType';
    import footers from './component/footers.vue';
    import app from './component/app.vue';
    import CONFIG from '../config';
    export default {
        name: "index",
        components:{
            footers,
            app,
            // login
        },
        data(){
            return {
                levelList:[{name:'省级',type:1},{name:'市级',type:2},{name:'区级',type:4},{name:'校级',type:8},{name:'其他',type:16}],
                currentLevel:1,
                levelAppList:[],
                myAppList:[],
                publicAppList:[],
                apps:{1:[],2:[],4:[],8:[],16:[]},
                showMenu:false
            }
        },
        computed:{
            userName(){
                let payload=this.$store.state.UserInfo;
                if(!payload) return '注销';
                switch(payload.SOURCETYPE){
                    case '220'://学生
                        return payload.XM;
                    case '210'://职员
                        return payload.EMPLOYEENAME;
                    case '140'://校区
                        if(payload.CAMPUSCOUNT>1){
                            return payload.CAMPUSNAME;
                        }
                        return payload.SCHOOLNAME;
                    case '130'://学校
                        return payload.SCHOOLNAME
                    case '120'://直属机构/其他机构
                        return payload.INSTITUTIONNAME
                    case '110'://教育局
                        return payload.BUREAUNAME;
                }
            }
        },
        mounted(){
            // this.getMyAppList();
            if(!this.$store.getters.isLogined){
                this.logout(true);
                return;
            }
            this.getPublicApp();
            // this.getPublicAppListBeforeLogin()
            // this.levelAppList=apps[this.currentLevel];
            this.getAppList();
            this.getAppList(1);
        },
        watch:{

            currentLevel(n,o){
                this.getAppList(n)
                // if(this.apps[n]){
                //     this.levelAppList=this.apps[n];
                // }

            }
        },
        methods:{
            changePassword(){
                this.$f7.views.main.router.navigate({name:'changePassword'});
            },
            logout(force){
                this.showMenu=false;
                if(!force){
                    this.$f7.dialog.confirm('确认要注销当前用户吗?','注销',()=>{
                        // this.logout(true);
                        let pl=this.$f7.dialog.preloader('正在注销...');
                        this.$ajax('post','/api/auth/unbind_wechat',null,{headers:{openid:this.$root.$options.openId}}).then(d=>{
                            this.logout(true);
                            pl.close();
                        }).catch(e=>{
                            this.$root.showToast('注销失败','center');
                            console.log(e)
                        })
                    });
                    return;
                }
                this.$store.commit(MUTATIONS_TYPE.UPDATE_USERINFO,null);
                this.$store.commit(MUTATIONS_TYPE.UPDATE_TOKEN,null);
                this.$root.$options.token=null;
                this.$root.$options.err=null;
                this.$f7.views.main.router.navigate({name:'portal'},{reloadAll:true,clearPreviousHistory:true});
                // this.$f7.views.main.router.back('/portal.html',{force :true,pushState:true});
                // /* IFTRUE_NODEBUG */
                // window.location.href=CONFIG.BASE+'/mobile/portal.html';
                // /* FITRUE_NODEBUG */
                //
                // /* IFDEBUG */
                // window.location.href=CONFIG.BASE+'/portal.html';
                // /* FIDEBUG */
            },
            getPublicApp(){
                this.$store.dispatch(ACTIONS_TYPE.GET_PUBLIC_APP,{count:8,page:1}).then(d=>{
                    var list=[];
                    if(d&&d.total){
                        for(var i of d.data){
                            i.state=1;
                        }
                        list=d.data;
                    }
                    var len=4-list.length;
                    for(let i =0;i<len;i++){
                        list.push({state:0,AUTH_CODE:'0'+i})
                    }
                    this.publicAppList=list;
                })

            },
            clickPage(e){
                if(this.$f7.$(e.target).closest('.loginBtn').length){
                
                }else{
                    this.showMenu=false;
                }
              console.log()
              
            },
            // unbind(){
            //     this.ajax('post','/api/appManager/getMyAppList').then(d=>{
            //         // if(d&&d.length){
            //         //     var len=Math.min(d.length,7)
            //         // }
            //         let len=0,list=[];
            //         for(let i of d){
            //             console.log(d)
            //             // i.ico='../assets/imgs/apps/app_CEE_score_query_icon.png';
            //             // i.ico=CONFIG.APIBase`http://192.168.10.191:9988/assets/imgs/icon/${i.AUTH_CODE}.png`
            //             if(i.ENTRY==1){
            //                 if(len==8){
            //                     list[7]={state:3,AUTH_CODE:'more'};
            //                     break;
            //                 }
            //                 i.authCode=i.AUTH_CODE;
            //                 i.state = 1;
            //                 len=list.push(i);
            //             }
            //         }
            //         len=8-list.length;
            //         for(let i =0;i<len;i++){
            //             list.push({state:0,AUTH_CODE:'0'+i})
            //         }
            //         this.myAppList=list;
            //     }).catch(e=>{
            //
            //     })
            // },


            getAppList(type=0){
                if(type&&this.apps[type].length){
                    this.levelAppList=this.apps[type];
                    return;
                }
                this.$ajax('post','/api/appManager/getAppList',{LEVELS:type,limit:8,pageNo:1},{encrypt:false}).then(d=>{
                    let len=0,list=[];


                    if(d&&d.total){
                        for(var i of d.data){
                            i.state=1;
                        }
                        list=d.data;
                    }
                    len=4-list.length;
                    for(let i =0;i<len;i++){
                        list.push({state:0,AUTH_CODE:'0'+type+i})
                    }

                    if(type==0){
                        this.myAppList=list;
                    }else{
                        this.apps[type]=list;
                        this.levelAppList=list;

                    }
                    // // this.apps={1:[],2:[],3:[],4:[],5:[]}
                    // for(let i of d){
                    //     if(!i.ENTRY) continue;
                    //     i.state=1;
                    //     i.authCode=i.AUTH_CODE;
                    //     if(i.PUBLIC_APP == 1&&plen<9){
                    //         if(plen==8){
                    //             plist[7]={state:3,AUTH_CODE:'more'};
                    //             plen++;
                    //         }else{
                    //             plen=plist.push(i);
                    //         }
                    //     }
                    //     var levels=this.apps[i.LEVELS];
                    //     if(levels.length<8){
                    //         levels.push(i)
                    //     }else{
                    //         levels[7]={state:3,AUTH_CODE:'more'};
                    //     }
                    //     // i.ico='../assets/imgs/apps/app_CEE_score_query_icon.png'
                    // }
                    // let a=null;
                    // len=8-plist.length;
                    // for(let j =0;j<len;j++){
                    //     plist.push({state:0,AUTH_CODE:'0'+j})
                    // }
                    // for(let i in this.apps){
                    //     a=this.apps[i]
                    //     len=8-a.length;
                    //     for(let j =0;j<len;j++){
                    //         a.push({state:0,AUTH_CODE:'0'+i+j})
                    //     }
                    // }
                    //
                    // this.publicAppList=plist;
                    // // if(d&&d.length>8){
                    // //     d.length=7;
                    // //     d.push({state:3})
                    // // }
                    // this.levelAppList=this.apps[1];
                }).catch(e=>{

                })
            },
        }
    }
</script>

<style scoped>
    .index{
        --f7-page-bg-color: #fff;
        /*color:#fff;*/
        .public-service{
            box-shadow: none;
            background: #fff no-repeat right bottom;
            background-size: auto 220px;
            padding-bottom: 0;
            margin-bottom: 20px;
            &.normal{
                border-radius : 0;
                margin-top: 0;
                padding-top: 0;
            }
            &.my-apps{
                background-image :  url("../assets/imgs/mobile/mobile_home_g1_bkimg.png");
            }
            &.public-apps{
                background-image :  url("../assets/imgs/mobile/mobile_home_g2_bkimg.png");
            }
            &.level-apps{
                background-image :  url("../assets/imgs/mobile/mobile_home_g3_bkimg.png");
                margin-bottom: 35px;
            }
        }
        .gap{
            /*margin: 0 25px;*/
            margin: 10px 25px 20px;
            height: 2px;
            background-color : #f5f5f5;
        }
        .levels-apps-filter{
            display: flex;
            margin: 10px 0;
            height: 50px;
            padding: 0 25px;
            justify-content: center;
            align-items: center;
            .level{
                flex:1 1 auto;
                background-color : #e5f2ff;
                font-size: 12px;
                font-weight: bolder;
                color:#0080ff;
                height: 30px;
                line-height: 30px;
                margin-left: 1px;
                text-align: center;
                transition: all 200ms ease-out;
                &.active{
                    color:#fff;
                    background-color : #0080ff;
                }
                &:first-child{
                    margin-left: 0;
                    border-top-left-radius: 10px;
                    border-bottom-left-radius: 10px;
                }
                &:last-child{
                    border-top-right-radius: 10px;
                    border-bottom-right-radius: 10px;
                }
                
            }
        }
        .level-apps{
            .apps{
                position: relative;
                min-height: 280px;
                
            }
            .app{
            each(range(8),{
                &[index='@{index}']{
                    top:70px * (@index - 1);
                }
            })
            &.apps-animate-enter{
                position : absolute;
                
            }
                &.apps-animate-enter-to{
                    position : absolute;
                }
                &.apps-animate-enter-active,{
                    position : absolute;
                }
            }
            
            
            
            
            
        }
    }
</style>