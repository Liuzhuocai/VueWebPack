const config={
    APPID:'JYDSJ_MOBILE',
    DEVICE_MOBILE:1,
    DEVICE_DESKTOP:2,
    // APIBASE:'http://test.scxk750.com/jydsj',
    // BASE:'http',

    // APIBASE:'/jydsj',
    APIBASE:'/api',
    BASE:'http://bigapp.scedu.net',
    //用于约定app图标的文件加载路径
    ICO_APTH:'/apps/icon/'
}
/* IFDEBUG */
// config.APIBASE='http://bigapp.scedu.net/api';
// config.APIBASE='http://192.168.10.118:9988';
config.APIBASE='http://192.168.10.191:9987';
config.BASE='http://192.168.10.25:3002';
config.ICO_APTH='/assets/apps/icon/'
/* FIDEBUG */
export default Object.freeze(config);


