<template>
    <div class="footer-info">
        <div>四川省教育管理信息中心</div>
        <div>四川省成都市青羊区陕西街26号</div>
    </div>
</template>

<script>
    export default {
        name: "footers"
    }
</script>

<style scoped>

</style>