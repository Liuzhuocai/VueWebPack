<template>
    <div class="app" :class="{'app-disabled':!appInfo.state}" @click="goApp">
        <div class="app-ico">
            <img :src="appIco" alt="" class="app-ico-img">
            <span class="app-ico-label" v-if="isPC"><span class="label">桌面端</span></span>
        </div>
        <div class="app-info">
            <div class="app-name">
                {{appName}}
            </div>
            <div class="app-desc">
                {{appDesc}}
            </div>
            <div class="app-state">{{appTips}}</div>
        </div>
    </div>
</template>

<script>
    import CONFIG from '../../config';
    import ACTIONS_TYPE from '../../stores/ActionsType';
    export default {
        name: "app",
        props:{
            appInfo:{
                type:Object,
                default:function(){
                    return {};
                }
            }


        },
        computed:{
            appName(){
                if(!this.appInfo.state) return '敬请期待';
                return this.appInfo.SNAME;
            },
            appDesc(){
                if(!this.appInfo.state) return '';
                return this.appInfo.DESCRIPTION;
            },
            appIco(){
                if(!this.appInfo.state) return '';
                return CONFIG.BASE+CONFIG.ICO_APTH+this.appInfo.AUTH_CODE+'.png';
            },
            isPC(){
                return this.appInfo.state&&CONFIG.DEVICE_DESKTOP==this.appInfo.DEVICE_SUPPORT;
            },
            appTips(){
                if(this.appInfo.state==2) return '- NEW -';
                return '';
            }
            
        },
        methods:{
            goApp(){
                if(this.appInfo.state==0) return;
                if(this.isPC){
                    return this.$root.showToast('请在桌面端上使用','center');
                }
                if(this.appInfo.PUBLIC_APP==1) {
                    if(!this.appInfo.PUBLIC_HOME_PATH){
                        return this.$root.showToast('无法打开应用，该应用没有回调地址,','center');
                    }
                    window.location.href=this.appInfo.PUBLIC_HOME_PATH+'?openid='+this.$root.$options.openId;
                }else if(this.appInfo.PUBLIC_APP==2){
                    let loader=this.$f7.dialog.preloader('正在打开...');
                    this.$store.dispatch(ACTIONS_TYPE.GO_APP,{authCode:this.appInfo.AUTH_CODE,device:CONFIG.DEVICE_MOBILE}).then(d=>{
                        loader.close();
                        if(d.token){
                            let mytoken = d.token.replace(/\+/g,'-').replace(/\//g,'_');
                            window.location.href=d.backpath+mytoken+'&openid='+this.$root.$options.openId;
                        }

                    }).catch(e=>{
                        this.$root.showToast('打开应用失败'+e,'top',{cssClass:'color-red'});
                    })
                    
                    
                    
                }
            }
        }

    }
</script>
<style scoped>

</style>