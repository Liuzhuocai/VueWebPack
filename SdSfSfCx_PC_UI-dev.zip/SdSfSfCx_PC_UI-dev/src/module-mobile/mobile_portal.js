// const a=require('./index.html');
import '../assets/less/mobile_index.less';
// import 'swiper/dist/css/swiper.css';
// import login from '../web/index-login.vue';

// import {Swiper,Pagination,Autoplay,EffectFade} from 'swiper/dist/js/swiper.esm';
// import Vue from 'vue/dist/vue.runtime.esm';

import portal from './portal.vue';
import main from './main.vue';
import {Vue,Store} from '../stores/store';
import {install} from  './importF7';
// import ajax from '../ajaxPlugin';
import CONFIG from './config';

import login from './login.vue';
import index from './index.vue';
import changePassword from './changePassword.vue';

import weixin from '../libs/weixin';
import ajax,{hook} from '../libs/ajax';
import MUTATIONS_TYPE from '../stores/MutationsType';


Vue.use(ajax,{APIBASE:CONFIG.APIBASE,Store:Store});

install(Vue);

weixin.$ajax=Vue.$ajax;
var errors={};
if(weixin.isWeChat()){
    weixin.getWebCode(CONFIG.BASE+'/mobile/portal.html',false).then(d=>{
    // weixin.getWebCode('http://test.scxk750.com/jydsj/mobile/portal.html',false).then(d=>{//内网测试用的地址
    // weixin.getWebCode('http://test.scxk750.com/jydsj/mobile/portal.html',false).then(d=>{//内网测试用的地址
        if(d.phase==2){//登录阶段
            delete d.phase;//删除阶段的属性,传给UI
            start(d);
        }
    }).catch(e=>{
        start({err:e});
    });
}else{
    start({openid:''});
}

function start(params){
    new Vue({
        el:'#app',
        store:Store,
        render:(h)=>h(main),
        f7params: {
            name: 'bigapp_mobile',
            id: 'bigapp_mobile',
            theme:'md',
            routes:[
                {
                    name:'portal',
                    path:'/',
                    component:portal,
                    options:{
                        transition: 'f7-cover-v',
                    }
                },
                {
                    name:'login',
                    path:'/login',
                    component:login,
                    options:{
                        transition: 'f7-cover-v',
                    }
                },
                {
                    name:'index',
                    path:'/index',
                    component:index,
                    options:{
                        transition: 'f7-cover-v',
                    }
                },
                {
                    name:'changePassword',
                    path:'/changePassword',
                    component:changePassword,
                    options:{
                        transition: 'f7-cover-v',
                    }
                }
            ],
            view:{
                pushState:true,
                pushStateSeparator:'#',
                stackPages:false,
                iosDynamicNavbar:false
            },
            lazy:{
                sequential:false
            },
            dialog:{
                buttonOk:'确定',
                buttonCancel:'取消'
            }
        },
        openId:params.openid,
        err:params.err,
        token:params.token,
        created(){
            let _self=this;
            hook.onError=function(e){
                if(e.R){

                    if(e.R==528&&!errors[e.R]){
                        errors[e.R]=true;
                        _self.$store.commit(MUTATIONS_TYPE.UPDATE_USERINFO,null);
                        _self.$store.commit(MUTATIONS_TYPE.UPDATE_TOKEN,null);
                        _self.$root.$options.token=null;
                        _self.$root.$options.err=null;
                        _self.$f7.dialog.create({
                            text:'密码已被修改,需要重新登录',
                            closeByBackdropClick:false,
                            buttons:[{
                                text:'重新登录',
                                onClick(){
                                    errors['528']=false
                                    _self.$f7.views.main.router.navigate({name:'portal'},{reloadAll:true,clearPreviousHistory:true});
                                }
                            }]
                        }).open();
                    }
                }

            };
        },
        methods:{
            showToast(text,position,config){
                config=config||{};
                config.text=text;
                config.position=position||'top';
                config.closeTimeout=2500;
                this.$f7.toast.create(config).open();
            }
        }

    });
}




// console.log(Vue)