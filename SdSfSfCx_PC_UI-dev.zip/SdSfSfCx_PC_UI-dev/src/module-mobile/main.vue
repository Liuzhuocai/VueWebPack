<template>
    <f7-app :params="$root.$options.f7params">
        <f7-view main :load-initial-page="false">
        </f7-view>
    </f7-app>
</template>

<script>
    export default {
        name: "apps",
        data(){
            return {
            }
        },
        mounted(){
            if(this.$store.getters.isLogined){
                this.$f7.views.main.router.navigate('/index',{animate:false})
            }else{
                this.$f7.views.main.router.navigate('/',{animate:false})
            }
            
        },
        methods:{
        
        }
    }
</script>

<style scoped>

</style>