<template>
    <f7-page>
        <div class="loginContainer">
            <div class="login-title">欢迎登录</div>
            <label class="login-input">
                <div class="input-label">用户名</div>
                <input type="text" class="input" name="account" id="account" maxlength="24" minlength="6" placeholder="6-24位字母或数字" v-model.trim="account">
                <span class="input-border"></span>
            </label>
            <label class="login-input">
                <div class="input-label">密码</div>
                <input type="password" class="input" v-model.trim="password" maxlength="24" minlength="6" placeholder="6-24位字母数字及特殊符号">
                <span class="input-border"></span>
            </label>
            <label class="login-input">
                <div class="input-label">验证码</div>
                <input type="text" class="input input-cap" id="cap" maxlength="4" v-model.trim="cap" placeholder="验证码">
                <span class="input-border"></span>
                <span class="cap-svg" v-html="capImg"  @click="getCap()"></span>
                <div style="clear: both"></div>
            </label>
            <div class="login-btn" @click="clickLogin">登录</div>
        </div>
    </f7-page>
</template>

<script>
    import CONFIG from '../config';
    import login_mixins from '../mixins/login_mixin'
    export default {
        name: "login",
        mixins:[login_mixins],
        data:function(){
          return {
              device:CONFIG.DEVICE_MOBILE
          }
        },
        mounted(){
            if(this.$root.$options.openId) this.openid=this.$root.$options.openId;
            this.getCap();
            this.$on('login:success',this.loginSuccess)
        },
        methods:{
            clickLogin(){
                this.login().then(d=>{

                }).catch(e=>{
                    this.$root.showToast(e,'top',{cssClass:'color-red'});
                })
            },
            loginSuccess(){
                this.$f7.views.main.router.navigate({name:'index'});
            }
        }
    }
</script>
<style scoped lang="less">
    //覆盖F7的样式
    @import (reference) '../assets/less/web_base';
    .page{
        --f7-page-bg-color:#fff;
    }
    .loginContainer{
        //background-color: #fff;
        padding: 25px 40px;
        .loginContent{
            width: 900px;
            height: 500px;
            display: flex;
            //margin: 0 auto;
            border-radius: 5px;
            overflow: hidden;
            background-color: #fff;
            box-shadow: 2px 4px 4px rgba(0,0,0,0.3);
        }
        
        .login-title{
            font-size: 23px;
            font-weight: bolder;
            color:@color-gray4;
            line-height: 40px;
        }
        .login-input{
            //border-radius: 5px;
            box-sizing: border-box;
            align-items: center;
            display: block;
            position: relative;
            margin-bottom: 10px;
            
            .input{
                .font-size-18;
                color:@color-gray1;
                line-height: 50px;
                height: 50px;
                &:focus{
                    & + .input-border{
                        border-color: @color-blue1;
                        border-width: 2px;
                    }
                }
            }
            
            
            .input-label{
                font-size: 15px;
                color:@color-gray3;
                padding-top: 12px;
            }
            
            .input-cap{
                width: 50%;
                vertical-align: middle;
                /*position: relative;*/
            }
            .cap-svg{
                display: inline-block;
                height: 40px;
                vertical-align: middle;
                float: right;
                /*position: relative;*/
                /*z-index: 1;*/
            }
            .input-border{
                border-bottom: 1px solid rgb(205, 205, 205);
                position: absolute;
                left:0;
                bottom:0;
                width:100%;
                box-sizing: border-box;
                /*height: 100%;*/
                z-index: 0;
                transition: all 200ms ease-out ;
            }
        }
        .login-btn{
            background-color: #0080ff;
            text-align: center;
            .font-size-16;
            /*padding: 10px 0;*/
            line-height: 45px;
            color:#fff;
            font-weight: bolder;
            height: 45px;
            letter-spacing: 1px;
            border-radius: 10px;
            margin-top: 25px;
            cursor: pointer;
            box-sizing: border-box;
            box-shadow: 0 2px 10px #b2d9ff;
        }
    }
</style>