import Framework7 from 'framework7/framework7-lite.esm';
import Framework7Vue from 'framework7-vue/utils/plugin';

import './importF7.less';
// import 'framework7/css/framework7.bundle.css';


import f7App from 'framework7-vue/components/app';
import f7View from 'framework7-vue/components/view';
import f7Page from 'framework7-vue/components/page';
// import f7ListInput from 'framework7-vue/components/list-input';
// import f7List  from 'framework7-vue/components/list';

import LazyComponent from 'framework7/components/lazy/lazy';
import Toast from 'framework7/components/toast/toast';
import Dialog from 'framework7/components/dialog/dialog';
import Preloader from 'framework7/components/preloader/preloader';
// import Input from 'framework7/components/input/input';
// import Form from 'framework7/components/form/form';
// import List from 'framework7/components/list/list';





export function install(Vue){
    Vue.component(f7App.name, f7App);
    Vue.component(f7View.name, f7View);
    Vue.component(f7Page.name, f7Page);
    // Vue.component(f7ListInput.name, f7ListInput);
    // Vue.component(f7List.name, f7List);


    Framework7.use(Framework7Vue,{'Vue':Vue});
    Framework7.use([LazyComponent,Toast,Preloader,Dialog]);
}