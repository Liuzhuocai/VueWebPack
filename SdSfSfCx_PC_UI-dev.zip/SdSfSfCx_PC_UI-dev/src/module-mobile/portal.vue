<template>
    
    <f7-page>
        <div class="loginBtn" @click="login">登录</div>
        <img src="../assets/imgs/mobile/mobile_banner_img.png" alt="" class="banner">
        <div class="public-service" >
            <div class="public-service-info" v-once>
                <div class="public-service-title">公众服务</div>
                <div class="public-service-desc">
                    <!--                            大数据连着老百姓的衣食住行。教育领域利用互联网、大数据等信息技术，向公众开放公共信息资源，构建一个新型政务服务体系，真正把为民服务的最后一公里变成零距离。-->
                    <!--                            <br>-->
                    <!--                            我们运用大数据促进保障和改善民生，推进互联网+教育、努力推动教育领域公共服务均等化、普惠化、便利化，让老百姓有更多的便利感和切切实实的获得感，提升教育行政管理部门在包括公共服务在内的社会治理能力和水平。-->
                    <p>面向社会大众开放的公众服务</p>
<!--                    <p>无需进行身份验证的服务</p>-->
                </div>
            </div>
            <transition-group name="apps-animate" tag="div" class="apps" >
                <app v-for="(item,index) in publicAppList" :app-info="item" :key="item.AUTH_CODE"></app>
            </transition-group>
        </div>
        <div class="sort-title" v-once>
            <div class="title-text">标准化数据与平台接入服务</div>
            <div class="title-line"></div>
        </div>
        <div class="services" v-once>
            <div class="service">
                <div class="service-title">统一基础数据</div>
                <div class="service-desc">
                    <p>在教育部下发的国家学籍基础数据库上进行补充与扩展，全面覆盖各级教育管理机构、教学机构及教育行业相关从业者、参与者，制定基础数据标准规范及基础数据交换标准规范，建成省级统一的教育基础数据库，为后期的统一学情数据提供基础数据支持。</p>
                    <p>各级教育行政管理部门、学校可申请使用建成后的教育基础数据库，促进本单位教育管理信息化建设，发挥基础数据为教育、教学服务的能力。</p>
                </div>
                <div class="service-bg lazy lazy-fade-in" :data-background="$data._imgs[0]" ></div>
            </div>
            <div class="service">
                <div class="service-title">统一学情数据</div>
                <div class="service-desc">
                    <p>利用大数据智能采集技术，对全省学情数据进行标准化之后的采集与管理，集中存储已有和将来的各类特色应用所产生的业务数据；建立学情数据交换接口，促进全省学情数据的共享交换。</p>
                    <p>后期将建立多维度的学情统计、构建分析模型对学情大数据进行深度挖掘，为教育决策者、管理者和其他参与者的个性化信息展示提供业务数据支撑。</p>
                </div>
                <div class="service-bg lazy lazy-fade-in"  :data-background="$data._imgs[1]"></div>
            </div>
            <div class="service">
                <div class="service-title">统一应用接入</div>
                <div class="service-desc">
                    <p>制定统一的应用接入标准，集成省、市、县（区）及学校等已建/将建的业务系统，将分散、异构的应用和信息资源进行聚合。</p>
                    <p>在统一门户中进行集中管理和访问，实现各种应用系统的无缝接入和集成，提供一个支持信息访问、传递、以及协作的集成化环境，实现个性化业务应用的高效开发、集成、部署与管理。</p>
                </div>
                <div class="service-bg lazy lazy-fade-in"  :data-background="$data._imgs[2]"></div>
            </div>
        </div>
        <div class="sort-title" v-once>
            <div class="title-text">创新信息时代新模式</div>
            <div class="title-text" style="margin: 0">服务教育教学全过程</div>
            <div class="title-line"></div>
        </div>
        <div class="modules policy-maker" v-once>
            <div class="modules-content">
                <div class="module-title text-align-left">教育决策者</div>
                <div class="module-descs">
                    <span class="module-desc">学情大数据模型</span>
                    <span class="module-desc">数据预警分析</span>
                    <span class="module-desc">区域教育发展事态</span>
                    <span class="module-desc">未来数据预测</span>
                    <span class="module-desc">多维度数据统计分析</span>
                    <span class="module-desc">教育发展监测与诊断</span>
                </div>
            </div>
            <div class="policy-maker-bg lazy lazy-fade-in" :data-background="$data._imgs[3]"></div>
        </div>
        <div class="modules admin" v-once>
            <div class="modules-content lazy-fade-in lazy" :data-background="$data._imgs[4]">
                <div class="module-title">教育管理者</div>
                <div class="module-descs">
                    <span class="module-desc">教育管理科学化</span>
                    <span class="module-desc">社会治理精准化</span>
                    <span class="module-desc">公共服务高效化</span>
                </div>
            </div>
            <div class="modules-content lazy-fade-in lazy" :data-background="$data._imgs[5]">
                <div class="modules-content-left">
                    <div class="module-title middle">教学管理者</div>
                    <div class="module-descs">
                        <span class="module-desc">共享为中心的管理模式</span><span class="module-desc">教学资源合理配置</span><span class="module-desc">数据聚集与放大效应</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="modules common-user" v-once>
            <div class="modules-content lazy-fade-in lazy" :data-background="$data._imgs[6]">
                <div class="module-title">教师</div>
                <div class="module-descs">
                    <div class="module-desc-short">
                        <span class="module-desc">数字化</span><span class="module-desc">无纸化</span><span class="module-desc">智能化</span>
                    </div>
                    <div class="module-desc-short">
                        <span class="module-desc">互动性</span><span class="module-desc">时效性</span><span class="module-desc">交流性</span>
                    </div>
                    <div class="module-desc display-block">充实教学内容</div>
                    <div class="module-desc display-block">提升教学质量</div>
                </div>
            </div>
            <div class="modules-content lazy-fade-in lazy" :data-background="$data._imgs[7]">
                <div class="module-title middle">学生</div>
                <div class="module-descs">
                    <div class="module-desc-short">
                        <span class="module-desc">延展课堂</span><span class="module-desc">沟通交流</span>
                    </div>
                    <div class="module-desc-short">
                        <span class="module-desc">心得分享</span><span class="module-desc">主动学习</span>
                    </div>
                    <div class="module-desc-short">
                        <span class="module-desc">激发内驱力</span><span class="module-desc">享受成就感</span>
                    </div>
                </div>
            </div>
            <div class="modules-content lazy-fade-in lazy" :data-background="$data._imgs[8]">
                <div class="module-title middle">家长</div>
                <div class="module-descs">
                    <span class="module-desc display-block">多渠道的信息获取</span>
                    <span class="module-desc display-block">深层次的数据加工</span>
                    <span class="module-desc display-block">及时准确的家校反馈</span>
                </div>
            </div>
        </div>
        <div class="sort-title" v-once>
            <div class="title-text">深化教育数据应用</div>
            <div class="title-text">优化教育治理能力</div>
            <div class="title-line"></div>
        </div>
        <div class="card functions" v-once>
            <div class="functions-content">
                <div class="function lazy-fade-in lazy" :data-background="$data._imgs[9]">
                    <div class="function-title">标准化</div>
                    <div class="function-desc">为消除在大数据应用过程<br>中的信息孤岛、机制壁垒<br>提供了可能</div>
                </div>
                <div class="function lazy-fade-in lazy" :data-background="$data._imgs[10]">
                    <div class="function-title">数据服务</div>
                    <div class="function-desc">满足各级教育局、学校对<br>基础数据的需求，助力各级<br>教育教学管理</div>
                </div>
            </div>
            <div class="functions-content">
                <div class="function lazy-fade-in lazy" :data-background="$data._imgs[11]">
                    <div class="function-title">应用仓库</div>
                    <div class="function-desc">模块化管理接入的各级<br>应用，最终形成覆盖所有<br>从业人员的应用仓库</div>
                </div>
                <div class="function lazy-fade-in lazy" :data-background="$data._imgs[12]">
                    <div class="function-title">个性化的工作平台</div>
                    <div class="function-desc">基于数据之间的联合<br>分析，提供个性化平台、实现<br>千人千面的内容呈现</div>
                </div>
            </div>
            <div class="functions-content">
                <div class="function lazy-fade-in lazy" :data-background="$data._imgs[13]">
                    <div class="function-title">边缘计算</div>
                    <div class="function-desc">就近提供最近端服务，<br>更快的网络服务响应</div>
                </div>
                <div class="function lazy-fade-in lazy" :data-background="$data._imgs[14]">
                    <div class="function-title">流动的信息</div>
                    <div class="function-desc">每一秒都有数据产生，每一秒<br>都在收集、分析、应用和<br>管理数据，每一秒都在彼此<br>分享数据</div>
                </div>
            </div>
            <div class="functions-content">
                <div class="function lazy-fade-in lazy" :data-background="$data._imgs[15]">
                    <div class="function-title">数据链</div>
                    <div class="function-desc">串联起各级教育应用贡献<br>的数据信息形成完美的<br>教育大数据链</div>
                </div>
                <div class="function lazy-fade-in lazy" :data-background="$data._imgs[16]">
                    <div class="function-title">安全的数据</div>
                    <div class="function-desc">数据中心机房、数据交换<br>专用路由器及5G专线<br>等，提供数据本身及数据<br>防护的安全</div>
                </div>
            </div>
        </div>
        <footers v-once></footers>
    </f7-page>
</template>

<script>

    import CONFIG from '../config';
    import app from './component/app';
    import footers from './component/footers';
    import ACTIONS_TYPE from '../stores/ActionsType';
    import MUTATIONS_TYPE from '../stores/MutationsType';

    export default {
        name: "portal",
        components:{app,footers},
        data(){
            return {
                publicAppList:[],
                _imgs:[
                    require('../assets/imgs/mobile/mobile_g1_img1.png'),
                    require('../assets/imgs/mobile/mobile_g1_img2.png'),
                    require('../assets/imgs/mobile/mobile_g1_img3.png'),
                    require('../assets/imgs/mobile/mobile_g2-1_img.png'),
                    require('../assets/imgs/mobile/mobile_g2-2_img1.png'),
                    require('../assets/imgs/mobile/mobile_g2-2_img2.png'),
                    require('../assets/imgs/mobile/mobile_g2-3_img1.png'),
                    require('../assets/imgs/mobile/mobile_g2-3_img2.png'),
                    require('../assets/imgs/mobile/mobile_g2-3_img3.png'),
                    require('../assets/imgs/mobile/mobile_g3_img1.png'),
                    require('../assets/imgs/mobile/mobile_g3_img2.png'),
                    require('../assets/imgs/mobile/mobile_g3_img3.png'),
                    require('../assets/imgs/mobile/mobile_g3_img4.png'),
                    require('../assets/imgs/mobile/mobile_g3_img5.png'),
                    require('../assets/imgs/mobile/mobile_g3_img6.png'),
                    require('../assets/imgs/mobile/mobile_g3_img7.png'),
                    require('../assets/imgs/mobile/mobile_g3_img8.png'),
                ]
            }
        },
        mounted(){
            // this.$ajax('get','/api/common/getCode?code=504',null,{baseURL:'http://192.168.10.191:7787',force:true,encrypt:false});
            this.getPublicAppListBeforeLogin();
            if(this.$root.$options.token){//如果有OPENID那么则获取,对应的用户信息
                this.$store.commit(MUTATIONS_TYPE.UPDATE_TOKEN,this.$root.$options.token);
                this.getUserInfo();
            }else if(this.$root.$options.err){
                let msg=this.$root.$options.err.R?this.$root.$options.err.C:this.$root.$options.err.message
                this.$f7.dialog.alert(msg,'提示',function(){
                    window.location.reload();
                })
            }

        },
        methods:{
            // goApp(item,type){
            //     if(item.state!=3&&item.PUBLIC_HOME_PATH){
            //         window.location.href=item.PUBLIC_HOME_PATH+'&openid='+this.$root.$options.openId;
            //     }
            // },
            login(){
                this.$f7.views.main.router.navigate({name:'login'})
                // window.location.href=CONFIG.BASE+'/web/index.html';
            },
            getPublicAppListBeforeLogin(){
                this.$store.dispatch(ACTIONS_TYPE.GET_PUBLIC_APP,{count:8,page:1}).then(d=>{
                    var list=[];
                    if(d&&d.total){
                        for(var i of d.data){
                            i.state=1;
                        }
                        list=d.data;
                    }
                    var len=4-list.length;
                    for(let i =0;i<len;i++){
                        list.push({state:0,AUTH_CODE:'0'+i})
                    }
                    this.publicAppList=list;
                }).catch(e=>{
                    this.$root.showToast(e.R?e.C:e.message)
                })
            },
            getUserInfo(){
                let pl=this.$f7.dialog.preloader('正在获取用户信息...');
                this.$store.dispatch(ACTIONS_TYPE.GET_SERVER_KEY_FOR_ENCRYPT).then(d=>{
                    return this.$store.dispatch(ACTIONS_TYPE.GET_USERINFO);
                }).then(d=>{
                    this.$f7.views.main.router.navigate({name:'index'})
                    pl.close();
                }).catch(e=>{
                    pl.close();
                    this.$root.showToast(e.R?e.C:e.message)
                })

            }
        }
    }
</script>

<style scoped>

</style>