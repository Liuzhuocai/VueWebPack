<template>
    <f7-page>
        <div class="loginContainer">
            <div class="login-title">修改密码</div>
            <div class="color-blue">{{userName}}</div>
            <div  v-if="step==1">
                <label class="login-input" style="margin-top: 12px">
                    <div class="input-label">旧密码</div>
                    <input type="password" class="input" name="oldpw" id="oldpw" maxlength="24" minlength="6" placeholder="6-24位字母或数字" v-model.trim="oldpw">
                    <span class="input-border"></span>
                </label>
            </div>
            <div v-if="step==2">
                <label class="login-input" style="margin-top: 12px">
                    <div class="input-label">新密码</div>
                    <input type="password" class="input" name="newpw" id="newpw" maxlength="24" minlength="6" placeholder="6-24位字母或数字" v-model.trim="newpw">
                    <span class="input-border"></span>
                </label>
                <label class="login-input" style="margin-top: 12px">
                    <div class="input-label">确认新密码</div>
                    <input type="password" class="input" name="newpw1" id="newpw1" maxlength="24" minlength="6" placeholder="6-24位字母或数字" v-model.trim="newpw1">
                    <span class="input-border"></span>
                </label>
            </div>
            <div class="login-btn" @click="checkpw" >{{step==1?'继续':'确定'}}</div>
        </div>
    </f7-page>
</template>

<script>
    import CONFIG from '../config';
    import MUTATIONS_TYPE from '../stores/MutationsType';
    import sjcl from '../libs/sjcl';
    export default {
        name: "changePassword",
        data:function(){
            return {
                oldpw:'',
                newpw:'',
                newpw1:'',
                step:1,
                oldpw2:''
            }
        },
        computed:{
            userName(){
                let payload=this.$store.state.UserInfo;
                if(!payload) return '';
                switch(payload.SOURCETYPE){
                    case '220'://学生
                        return payload.XM;
                    case '210'://职员
                        return payload.EMPLOYEENAME;
                    case '140'://校区
                        if(payload.CAMPUSCOUNT>1){
                            return payload.CAMPUSNAME;
                        }
                        return payload.SCHOOLNAME;
                    case '130'://学校
                        return payload.SCHOOLNAME
                    case '120'://直属机构/其他机构
                        return payload.INSTITUTIONNAME
                    case '110'://教育局
                        return payload.BUREAUNAME;
                }
            }
        },
        mounted(){
        
        },
        methods:{
            checkpw(type){

                if(this.step==1&&this.oldpw){
                    var spasswd  = sjcl.hash.sha256.hash(this.oldpw);
                    spasswd  = 'A'+sjcl.codec.hex.fromBits(spasswd);
                    var authdata = JSON.stringify({
                        opassword  : spasswd
                    });
                    this.$ajax('post','/api/user/verifyPassword',{_auth:sjcl.encrypt(this.$store.state.ServerPublicKeyForEncrypt,authdata)},{encrypt:false}).then(d=>{
                        // console.log(111)
                        this.step=2;

                    }).catch(e=>{
                        if(e.C){
                            this.$root.showToast(e.C);
                        }else{
                            this.$root.showToast(e.message);
                        }
                        
                    })
                }else if(this.step==2){
                    if(this.newpw&&this.newpw1){
                        if(this.newpw.length<6||this.newpw.length>24){
                            this.$root.showToast('密码长度是6-24位');
                        }else if(this.newpw!=this.newpw1){
                            this.$root.showToast('两次密码不匹配');
                        }else{
                            var spasswd  = sjcl.hash.sha256.hash(this.oldpw);
                            spasswd  = 'A'+sjcl.codec.hex.fromBits(spasswd);
                            var npasswd=sjcl.hash.sha256.hash(this.newpw);
                            npasswd='A'+sjcl.codec.hex.fromBits(npasswd);
                            var authdata = JSON.stringify({
                                opassword  : spasswd,
                                npassword:npasswd
                            });

                            this.$ajax('post','/api/user/changePassword',{_auth:sjcl.encrypt(this.$store.state.ServerPublicKeyForEncrypt,authdata)},{encrypt:false}).then(d=>{
                                // console.log(111)
                                this.$store.commit(MUTATIONS_TYPE.UPDATE_USERINFO,null);
                                this.$store.commit(MUTATIONS_TYPE.UPDATE_TOKEN,null);
                                this.$root.$options.token=null;
                                this.$root.$options.err=null;
                                let _self=this;
                                this.$f7.dialog.create({
                                    text:'密码修改成功',
                                    closeByBackdropClick:false,
                                    buttons:[{
                                        text:'马上登录',
                                        onClick(){

                                            _self.$f7.views.main.router.navigate({name:'portal'},{reloadAll:true,clearPreviousHistory:true});
                                        }
                                    }]
                                }).open();
                            }).catch(e=>{
                                if(e.C){
                                    this.$root.showToast(e.C);
                                }else{
                                    this.$root.showToast(e.message);
                                }
                            })
                        }

                    }
                }
            },
        }
    }
</script>
<style scoped lang="less">
    //覆盖F7的样式
    @import (reference) '../assets/less/web_base';
    .page{
        --f7-page-bg-color:#fff;
    }
    .loginContainer{
        .color-blue{
            color:@color-blue1;
            font-size: 16px;
        }
        //background-color: #fff;
        padding: 25px 40px;
        .loginContent{
            width: 900px;
            height: 500px;
            display: flex;
            //margin: 0 auto;
            border-radius: 5px;
            overflow: hidden;
            background-color: #fff;
            box-shadow: 2px 4px 4px rgba(0,0,0,0.3);
        }
        
        .login-title{
            font-size: 23px;
            font-weight: bolder;
            color:@color-gray4;
            line-height: 40px;
        }
        .login-input{
            //border-radius: 5px;
            box-sizing: border-box;
            align-items: center;
            display: block;
            position: relative;
            margin-bottom: 10px;
            
            .input{
                .font-size-18;
                color:@color-gray1;
                line-height: 50px;
                height: 50px;
                &:focus{
                    & + .input-border{
                        border-color: @color-blue1;
                        border-width: 2px;
                    }
                }
            }
            
            
            .input-label{
                font-size: 15px;
                color:@color-gray3;
                padding-top: 12px;
            }
            
            .input-cap{
                width: 50%;
                vertical-align: middle;
                /*position: relative;*/
            }
            .cap-svg{
                display: inline-block;
                height: 40px;
                vertical-align: middle;
                float: right;
                /*position: relative;*/
                /*z-index: 1;*/
            }
            .input-border{
                border-bottom: 1px solid rgb(205, 205, 205);
                position: absolute;
                left:0;
                bottom:0;
                width:100%;
                box-sizing: border-box;
                /*height: 100%;*/
                z-index: 0;
                transition: all 200ms ease-out ;
            }
        }
        .login-btn{
            background-color: #0080ff;
            text-align: center;
            .font-size-16;
            /*padding: 10px 0;*/
            line-height: 45px;
            color:#fff;
            font-weight: bolder;
            height: 45px;
            letter-spacing: 1px;
            border-radius: 10px;
            margin-top: 25px;
            cursor: pointer;
            box-sizing: border-box;
            box-shadow: 0 2px 10px #b2d9ff;
        }
    }
</style>