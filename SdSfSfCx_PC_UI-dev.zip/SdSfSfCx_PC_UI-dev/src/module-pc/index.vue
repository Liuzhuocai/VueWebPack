<template>
    <div>
        <banner></banner>
        <swiper v-once></swiper>
        <div class="card app-sorts public-service myapps" >
            <div class="desc">
                <div class="desc-title">
                    <span class="desc-main-title">我的应用</span>
                    <div class="tools" style="cursor:not-allowed;color:#9e9e9e;border-color:#9e9e9e;background-color: #dadada;">
                        <div class="tool">管理</div>
                        <div class="tool">更多</div>
                    </div>
                </div>
                <div class="desc-detail">
                    <p>按你的关注度，列出了与你相关的应用。</p>
                    <p>你可点击“管理”去调整应用的先后顺序，把自己关心的、或经常使用的应用显示在前列，方便以后快速进入这些应用。</p>
                </div>
            </div>
            <div class="gap"></div>
            <transition-group name="apps-animate" tag="div" class="apps" >
                <app v-for="(item,index) in myAppList" :key="item.AUTH_CODE" @app:click="goApp(item,2)" :app-info="item"></app>
            </transition-group>
        </div>
        <div class="card app-sorts public-service public-apps" style="">
            <div class="desc">
                <div class="desc-title">
                    <span class="desc-main-title">公众服务</span>
                    <div class="tools" style="cursor:not-allowed;color:#9e9e9e;border-color:#9e9e9e;background-color: #dadada;">
                        <div class="tool" >更多</div>
                    </div>
                </div>
                <div class="desc-detail">
                    <p>此处列出了面向社会公众、无需进行身份验证的服务。</p>
                </div>
            </div>
            <div class="gap"></div>
            <transition-group name="apps-animate" tag="div" class="apps" >
                <app v-for="(item,index) in publicAppList" :app-info="item" :key="item.AUTH_CODE" @app:click="goApp(item,1)"></app>
            </transition-group>
        </div>
        <div class="card app-sorts public-service levels-apps">
            <div class="desc">
                <div class="desc-title">
                    <span class="desc-main-title">各级应用</span>
                </div>
                <div class="desc-detail">
                    <p>按应用的提供者（或应用接入申请者）类型，列出了与你相关的应用。</p>
                </div>
            </div>
            <div class="levels-app-filter">
                <div style="line-height: 90px;height: 90px;display: flex;justify-content: center">
                        <div class="tools" style="cursor:not-allowed;color:#9e9e9e;border-color:#9e9e9e;background-color: #dadada;">
                            <div class="tool">更多</div>
                        </div>
                </div>
                <div class="levels-app-filter-list">
                    <div class="level" v-for="item in levelList" :class="{active:currentLevel==item.type}"  @click="currentLevel=item.type">{{item.name}}<i class="ico ico-arrow-right"></i></div>
                </div>
            </div>
            <div class="gap"></div>
            <transition-group name="apps-animate" tag="div" class="apps" >
                <app v-for="(item,index) in levelAppList" :key="item.AUTH_CODE"  :index="index%4" :app-info="item"   :col="index>3?'row2':'row1'"  @app:click="goApp(item,3)"></app>
            </transition-group>
        </div>
        <footers v-once></footers>
        <appEntrance ref="entrance"></appEntrance>
    </div>
</template>

<script>
    import ACTIONS_TYPE from '../stores/ActionsType';
    import banner from './component/banner.vue';
    import swiper from './component/swiper.vue';
    import footers from './component/footers.vue';
    import app from './component/app.vue';
    
    import appEntrance from './component/app-entrance';

    export default {
        name: "index",
        components:{
            banner,
            swiper,
            footers,
            app,
            appEntrance
        },
        data(){
            return {
                levelList:[{name:'省级',type:1},{name:'市级',type:2},{name:'区级',type:4},{name:'校级',type:8},{name:'其他',type:16}],
                currentLevel:1,
                levelAppList:[],
                myAppList:[],
                publicAppList:[],
                apps:{1:[],2:[],4:[],8:[],16:[]},
            }
        },
        mounted(){
            // this.getMyAppList();
            this.getPublicApp();
            // this.getPublicAppListBeforeLogin()
            // this.levelAppList=apps[this.currentLevel];
            this.getAppList();
            this.getAppList(1);
        },
        watch:{

            currentLevel(n,o){
                this.getAppList(n)
                // if(this.apps[n]){
                //     this.levelAppList=this.apps[n];
                // }

            }
        },
        methods:{
            getPublicApp(){
                this.$store.dispatch(ACTIONS_TYPE.GET_PUBLIC_APP,{count:8,page:1}).then(d=>{
                    var list=[];
                    if(d&&d.total){
                        for(var i of d.data){
                            i.state=1;
                        }
                        list=d.data;
                    }
                    var len=8-list.length;
                    for(let i =0;i<len;i++){
                        list.push({state:0,AUTH_CODE:'0'+i})
                    }
                    this.publicAppList=list;
                })

            },
            // getMyAppList(){
            //     ajax('post','/api/appManager/getMyAppList').then(d=>{
            //         // if(d&&d.length){
            //         //     var len=Math.min(d.length,7)
            //         // }
            //         let len=0,list=[];
            //         for(let i of d){
            //             console.log(d)
            //             // i.ico='../assets/imgs/apps/app_CEE_score_query_icon.png';
            //             // i.ico=CONFIG.APIBase`http://192.168.10.191:9988/assets/imgs/icon/${i.AUTH_CODE}.png`
            //             if(i.ENTRY==1){
            //                 if(len==8){
            //                     list[7]={state:3,AUTH_CODE:'more'};
            //                     break;
            //                 }
            //                 i.authCode=i.AUTH_CODE;
            //                 i.state = 1;
            //                 len=list.push(i);
            //             }
            //         }
            //         len=8-list.length;
            //         for(let i =0;i<len;i++){
            //             list.push({state:0,AUTH_CODE:'0'+i})
            //         }
            //         this.myAppList=list;
            //     }).catch(e=>{
            //
            //     })
            // },
            goApp(item,type){
                this.$refs.entrance.show(item)
                // if(type==1){
                //     console.log(item)
                //     // if(item.PUBLIC)
                //     item.PUBLIC_HOME_PATH&&window.open(item.PUBLIC_HOME_PATH,'_blank');
                //
                //
                // }else{
                //     if(item.state==3){//更多
                //
                //     }else if(item.state!=0){
                //         // var a = document.createElement('a');
                //         //
                //         // a.setAttribute('target','_blank');
                //         // a.style.width=0;
                //         // a.style.height=0;
                //         if(item.PUBLIC_APP==2){
                //             var a=window.open('','_blank');
                //             this.$store.dispatch(ACTIONS_TYPE.GO_APP,{authCode:item.AUTH_CODE}).then(d=>{
                //                 if(d.token){
                //                     let mytoken = d.token.replace(/\+/g,'-').replace(/\//g,'_');
                //                     a.location.href=d.backpath+mytoken;
                //                 }
                //
                //             }).catch(e=>{
                //                 a.close();
                //             })
                //         }else{
                //             item.PUBLIC_HOME_PATH&&window.open(item.PUBLIC_HOME_PATH,'_blank');
                //         }
                //
                //
                //     }
                //
                // }
            },
            getAppList(type=0){
                if(type&&this.apps[type].length){
                    this.levelAppList=this.apps[type];
                    return;
                }
                this.$ajax('post','/api/appManager/getAppList',{LEVELS:type,limit:8,pageNo:1},{encrypt:false}).then(d=>{
                    let len=0,list=[];


                    if(d&&d.total){
                        for(var i of d.data){
                            i.state=1;
                        }
                        list=d.data;
                    }
                    len=8-list.length;
                    for(let i =0;i<len;i++){
                        list.push({state:0,AUTH_CODE:'0'+type+i})
                    }

                    if(type==0){
                        this.myAppList=list;
                    }else{
                        this.apps[type]=list;
                        this.levelAppList=list;

                    }
                    // // this.apps={1:[],2:[],3:[],4:[],5:[]}
                    // for(let i of d){
                    //     if(!i.ENTRY) continue;
                    //     i.state=1;
                    //     i.authCode=i.AUTH_CODE;
                    //     if(i.PUBLIC_APP == 1&&plen<9){
                    //         if(plen==8){
                    //             plist[7]={state:3,AUTH_CODE:'more'};
                    //             plen++;
                    //         }else{
                    //             plen=plist.push(i);
                    //         }
                    //     }
                    //     var levels=this.apps[i.LEVELS];
                    //     if(levels.length<8){
                    //         levels.push(i)
                    //     }else{
                    //         levels[7]={state:3,AUTH_CODE:'more'};
                    //     }
                    //     // i.ico='../assets/imgs/apps/app_CEE_score_query_icon.png'
                    // }
                    // let a=null;
                    // len=8-plist.length;
                    // for(let j =0;j<len;j++){
                    //     plist.push({state:0,AUTH_CODE:'0'+j})
                    // }
                    // for(let i in this.apps){
                    //     a=this.apps[i]
                    //     len=8-a.length;
                    //         a.push({state:0,AUTH_CODE:'0'+i+j})
                    //     }
                    // }
                    //
                    // this.publicAppList=plist;
                    // // if(d&&d.length>8){
                    // //     d.length=7;
                    // //     d.push({state:3})
                    // // }
                    // this.levelAppList=this.apps[1];
                }).catch(e=>{

                })
            },
        }
    }
</script>

<style scoped>

</style>