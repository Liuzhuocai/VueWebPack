<template>
    <div class="banner">
        <div class="banner-content">
            <div class="banner-title">
                <i class="ico ico-logo"></i>
                <span>四川省教育公共信息服务平台</span>
            </div>
            <div class="banner-login" >
                <slot>
                    <div @click="$emit($event.type)" class="display-inline-block banner-login-info">
                        <span class="vertical-align-middle " v-if="userName.length==3">{{userName[1]}}<span class="orgDesc">{{userName[2]}}</span></span>
                        <span class="vertical-align-middle orgDesc" v-if="userName.length==2">{{userName[1]}} - </span>
                        <span class="vertical-align-middle " v-if="userName[0]">{{userName[0]}}</span>
                        <i class="ico ico-avator"></i>
                    </div>
                    <div class="banner-menus" v-if="$store.getters.isLogined">
                        <!--                    <i class="arrow"></i>-->
                        <div class="banner-menus-content">
                            <div class="banner-menu"><i class="ico ico-setting"></i> <span class="vertical-align-middle" @click="changePassword">修改密码</span></div>
                            <div class="banner-menu" @click="logout"><i class="ico ico-logout"></i> <span class="vertical-align-middle">注销</span></div>
                        </div>
    
                    </div>
                </slot>
               
            </div>
        
        </div>
    </div>
</template>

<script>


    // import login from './login.vue';
    import MUTATIONS_TYPE from '../../stores/MutationsType';
    import CONFIG from '../../config';


    export default {
        name: "banner",
        // components:{
        //     login
        // },
        computed:{
            userName(){
                if(this.$store.getters.isLogined){
                    let payload=this.$store.state.UserInfo;
                    switch(payload.SOURCETYPE){
                        case '220'://学生
                            let b=[payload.XM,payload.SCHOOLNAME];
                            if(payload.CAMPUSCOUNT>1){
                                b[1]=b[1]+' ('+payload.CAMPUSNAME+')';
                            }
                            return b;
                        case '210'://职员
                            let a=[payload.EMPLOYEENAME,payload.ORGNAME]
                            if(payload.CAMPUSCOUNT>1){
                                a[1]=a[1]+' ('+payload.CAMPUSNAME+')';
                            }
                            return a;
                        case '140'://校区
                            let c=[null,payload.SCHOOLNAME,null]
                            if(payload.CAMPUSCOUNT>1){
                                c[2]=' ('+payload.CAMPUSNAME+')';
                            }
                            return c;
                        case '130'://学校
                            return [payload.SCHOOLNAME]
                        case '120'://直属机构/其他机构
                            return [payload.INSTITUTIONNAME]
                        case '110'://教育局
                            return [payload.BUREAUNAME];
                    }
                }else{
                    return ['登录']
                }
            }
        },
        methods:{
            logout(){
                this.$store.commit(MUTATIONS_TYPE.UPDATE_USERINFO,null);
                this.$store.commit(MUTATIONS_TYPE.UPDATE_TOKEN,null);


                /* IFTRUE_NODEBUG */
                window.location.href=CONFIG.BASE+'/web/portal.html';
                /* FITRUE_NODEBUG */

                /* IFDEBUG */
                window.location.href=CONFIG.BASE+'/portal.html';
                /* FIDEBUG */
            },
            changePassword(){
                console.log(22)
                /* IFTRUE_NODEBUG */
                window.location.href=CONFIG.BASE+'/web/changePassword.html';
                /* FITRUE_NODEBUG */

                /* IFDEBUG */
                window.location.href=CONFIG.BASE+'/changePassword.html';
                /* FIDEBUG */
            }
        }
    }
</script>

<style scoped>

</style>