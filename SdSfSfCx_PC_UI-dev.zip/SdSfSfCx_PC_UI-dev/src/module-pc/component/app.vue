<template>
    <div class="app" :class="{'app-disabled':!appInfo.state}" @click="goApp">
        <div class="app-ico">
            <img :src="appIco" alt="" class="app-ico-img">
            <span class="app-ico-label" v-if="isMobile">移动端</span>
        </div>
        <div class="app-name">
            {{appName}}
        </div>
        <div class="app-desc">
            {{appDesc}}
        </div>
        <div class="app-state">{{appTips}}</div>
    </div>
</template>

<script>
    import CONFIG from '../../config';
    export default {
        name: "app",
        props:{
            appInfo:{
                type:Object,
                default:function(){
                    return {};
                }
            }
       
            
        },
        computed:{
            appName(){
                if(!this.appInfo.state) return '敬请期待';
                return this.appInfo.SNAME;
            },
            appDesc(){
                if(!this.appInfo.state) return '';
                return this.appInfo.DESCRIPTION;
            },
            appIco(){
                if(!this.appInfo.state) return '';
                return CONFIG.BASE+CONFIG.ICO_APTH+this.appInfo.AUTH_CODE+'.png';
            },
            isMobile(){
                return this.appInfo.state&&CONFIG.DEVICE_MOBILE==this.appInfo.DEVICE_SUPPORT;
            },
            appTips(){
                if(this.appInfo.state==2) return '- NEW -';
                return '';
            }
          
        },
        methods:{
            goApp(){
                if(!this.appInfo.state) return;
                this.$emit('app:click');
            }
        }

    }
</script>
<style scoped>

</style>