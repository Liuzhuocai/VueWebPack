<template>
    <transition name="dialog" appear type="transition" duration="300">
        <div class="loginContainer entranceContainer" v-if="isLogin" >
            <div class="bg"></div>
            <div class="loginContent entranceContent animate-target" style="width: 360px" >
                <div class="entrance-top" style="justify-content: center;font-size: 16px">
                    <span>{{text}}</span>
                </div>
                <!--                <div class="entrance-botton">{{// botztonLabel}}</div>-->
                <div class="entrance-botton" @click="hide">{{btn}}</div>
            </div>
        </div>
        </div>
    </transition>
</template>
<script>

    export default {
        name: "alert",
        data:function(){
            return {
                isLogin:true,
                text:'',
                btn:'确定',
                cb:Function
            }
        },
        mounted(){
            window.document.body.append(this.$el)
        },
        methods:{
            show(){
                this.isLogin=true;
            },
            hide(){
                this.isLogin=false;
                if(this.cb) this.cb();
            
            },
        }

    }
</script>

<style scoped type="less">

</style>