<template>
    <div>
        <div class="footer-detail">
            <div class="card">
                <div class="footer-characteristics">
                    <div class="characteristics">
                        <i class="ico ico-database"></i><span>海量数据</span>
                    </div>
                    <div class="characteristics">
                        <i class="ico ico-monitor"></i><span >实时监控</span>
                    </div>
                    <div class="characteristics">
                        <i class="ico ico-load"></i><span >负载均衡</span>
                    </div>
                    <div class="characteristics">
                        <i class="ico ico-cloud"></i><span>云端计算</span>
                    </div>
                    <div class="characteristics">
                        <i class="ico ico-brain"></i><span >智能学习</span>
                    </div>
                    <div class="characteristics">
                        <i class="ico ico-prevent"></i><span >预测预防</span>
                    </div>
                </div>
                <div class="footer-service">
                    <div class="footer-wechat">
                        <div class="footer-wechat-title">
                            <i class="ico ico-wechat"></i>
                            <span>微信公众号</span>
                        </div>
                        <div class="footer-wechat-qrcode"></div>
                    </div>
                    <div class="footer-gap"></div>
                    <div class="footer-assets">
                        <div class="footer-asset-title">服务对象</div>
                        <div class="footer-asset-desc">决策者</div>
                        <div class="footer-asset-desc">管理者</div>
                        <div class="footer-asset-desc">教师</div>
                        <div class="footer-asset-desc">学生</div>
                    </div>
                    <div class="footer-assets">
                        <div class="footer-asset-title">服务内容</div>
                        <div class="footer-asset-desc">基础数据服务</div>
                        <div class="footer-asset-desc">业务数据归集</div>
                        <div class="footer-asset-desc">各级应用接入</div>
                        <div class="footer-asset-desc">统一工作平台</div>
                    </div>
                    <div class="footer-assets">
                        <div class="footer-asset-title">政府相关</div>
                        <div class="footer-asset-desc">教育部</div>
                        <div class="footer-asset-desc">四川省人民政府</div>
                        <div class="footer-asset-desc">四川政务服务网</div>
                        <div class="footer-asset-desc">四川教育网</div>
                    </div>
                    <div class="footer-assets">
                        <div class="footer-asset-title">教育相关</div>
                        <div class="footer-asset-desc">四川省教育厅</div>
                        <div class="footer-asset-desc">四川省招生考试院</div>
                        <div class="footer-asset-desc">四川省教育科学研究院</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-info">
            <div class="card">
                <div class="footer-info-desc">
                    <div>四川省教育管理信息中心</div>
                    <div>四川省成都市青羊区陕西街26号</div>
                </div>
                <div class="footer-info-tips">为了获得更好的浏览效果，建议您使用 Google Chrome 浏览器</div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "footers"
    }
</script>

<style scoped>

</style>