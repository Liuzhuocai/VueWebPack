<template>
    <div>
        <div class="swiper-container">
            <!--            <div cllass="swiper-bg"></div>-->
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="swiper-slide-content animationContainer">
                        <div class="animationCenter">
                            <div class="animationContent zi"></div>
                            <div class="animationContent zi4"></div>
                        </div>
                        <div class="animationContent zi2"></div>
                        <div class="animationContent zi3"></div>
                        <!--                        <img class="animationContent zi4" src="../../assets/imgs/web/banner_img1_anime.webp"/>-->
                        <!--                        <img class="animationContent zi4" src="../../assets/imgs/web/banner_img1_anime.webp"/>-->
                    
                    </div>
                </div>
                <!--                <div class="swiper-slide">-->
                <!--                    <div class="swiper-slide-content">-->
                <!--                        <img src="../../assets/imgs/web/banner_img1.png" alt="">-->
                <!--                    </div>-->
                <!--                </div>-->
            </div>
            <!-- Add Pagination -->
            <div class="swiper-pagination"></div>
        </div>
        <div class="card-shadow"></div>
    </div>
</template>

<script>
    import 'swiper/dist/css/swiper.css';
    import {Swiper,Pagination,Autoplay,EffectFade} from 'swiper/dist/js/swiper.esm';
    Swiper.use([Pagination,Autoplay,EffectFade]);
    export default {
        name: "swiper",
        mounted () {

            const swiper = new Swiper('.swiper-container', {
                centeredSlides: true,
                loop:false,
                speed:800,
                effect:'fade',
                // slidesPerView: 'auto',
                pagination: {
                    el: '.swiper-pagination',
                    dynamicBullets: true,
                },
                autoplay: {
                    delay: 8000
                },
                fadeEffect:{
                    crossFade:true
                }
            });
        }
    }
</script>

<style scoped>

</style>