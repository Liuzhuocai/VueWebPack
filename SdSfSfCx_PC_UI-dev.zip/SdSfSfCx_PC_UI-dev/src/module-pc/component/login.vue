<template>
    <transition name="dialog" appear type="transition" duration="300">
        <div class="loginContainer" v-if="isLogin" >
            <div class="bg" @click="hide"></div>
            <div class="loginContent animate-target">
                <div class="login-left-side"></div>
                <div class="login-right-side">
                    <i class="ico ico-close" @click="hide()"></i>
                    <div class="login-title">欢迎登录</div>
                    <div class="login-input" style="margin-top: 50px">
                        <span class="input-label">用户名</span>
                        <input type="text" class="input-content" name="account" id="account" placeholder="6-24位字母或数字或_@-." v-model.trim="account" @keyup.enter="login">
                        <label class="input-border" for="account"></label>
                    </div>
                    <label class="login-input">
                        <span class="input-label">密码</span>
                        <input type="password" class="input-content" placeholder="6-24位字符" v-model.trim="password" @keyup.enter="login">
                        <div class="input-border"></div>
                    </label>
                    <div class="login-input" style="padding-right: 0">
                        <span class="input-label">验证码</span>
                        <input type="text" class="input-content" id="cap" maxlength="4" placeholder="4位字母或数字" v-model.trim="cap" @keyup.enter="login">
                        <label class="input-border" for="cap"></label>
                        <span class="input-cap" v-html="capImg" @click="getCap"></span>
                    </div>
                    <div class="login-tip" >
                        <i class="ico ico-caution" v-show="msg"></i>
                        <span class="login-tip-msg" v-show="msg">{{msg}}</span>
                    </div>
                    <div class="login-btn" @click="login">登录</div>
                    <div class="login-other" >
                        <a  class="login-reg-btn" style="cursor:not-allowed;color:#9e9e9e;">找回密码</a><a class="login-reg-btn" style="cursor:not-allowed;color:#9e9e9e;">新用户注册</a>
                    </div>
                    
                </div>
            </div>
        </div>
    </transition>
</template>
<script>
    import login_mixin from '../../mixins/login_mixin'

    export default {
        name: "index-login",
        mixins:[login_mixin],
        data:function(){
            return {
                isLogin:false,
            }
        },
        mounted(){
            // console.log(11122)
        },
        methods:{
            show(){
                this.getCap();
                this.isLogin=true;
            },
            hide(){
                this.isLogin=false;
            },
        }

    }
</script>

<style scoped>

</style>