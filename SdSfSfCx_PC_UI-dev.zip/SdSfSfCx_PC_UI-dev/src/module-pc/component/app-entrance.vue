<template>
        <transition name="dialog" appear type="transition" duration="300">
            <div class="loginContainer entranceContainer" v-if="isLogin">
                <div class="bg" @click="hide"></div>
                <div class="loginContent entranceContent animate-target" >
                    <i class="ico ico-close" @click="hide()"></i>
                    <div class="entrance-top">
                        <div class="entrance-ico">
                            <img :src="appIco" alt="" class="entrance-ico-img">
                            <span class="entrance-ico-label" v-if="isMobile">移动端</span>
                        </div>
                        <div class="entrance-info">
                            <div class="entrance-title">{{appInfo.NAME}}</div>
                            <div class="entrance-desc">{{appInfo.DESCRIPTION}}</div>
                            <div class="entrance-desc-info">
                                <span class="entrance-desc-info-label">提供方：</span>
                                {{appInfo.ORGINIZATION}}
                            </div>
                            <div class="entrance-desc-info">
                                <span class="entrance-desc-info-label">使用环境：</span>
                                {{appDevice}}
                            </div>
                        </div>
                    </div>
                    <div class="entrance-botton" :disabled="isMobile||disabled" @click="enterApp">{{bottonLabel}}</div>
                </div>
            </div>
        </transition>
</template>
<script>
    import CONFIG from '../../config';
    import ACTIONS_TYPE from '../../stores/ActionsType';
    export default {
        name: "app-entrance",
        data:function(){
            return {
                isLogin:false,
                appInfo:{}
            }
        },
        computed:{

            appIco(){
                if(!this.appInfo.AUTH_CODE){
                    return '';
                }
                return CONFIG.BASE+CONFIG.ICO_APTH+this.appInfo.AUTH_CODE+'.png';
            },
            appDevice(){
                let a=[];
                if(this.appInfo.DEVICE_SUPPORT&CONFIG.DEVICE_DESKTOP){
                    a.push('桌面端')
                }
                if(this.appInfo.DEVICE_SUPPORT&CONFIG.DEVICE_MOBILE){
                    a.push('移动端')
                }
                return a.join('、');
            },
            isMobile(){
                return this.appInfo.state&&CONFIG.DEVICE_MOBILE==this.appInfo.DEVICE_SUPPORT;
            },
            bottonLabel(){
                if(this.isMobile) return '请关注微信公众号';
                return '进入';
            },
            disabled(){
                if(this.appInfo.PUBLIC_APP==2){
                    return !(!this.appInfo._backpath);
                }
                return false;
            }

        },
        mounted(){
            // console.log(11122)
        },
        methods:{
            show(item){
                this.appInfo=item;
                if(this.isMobile==false&&item.PUBLIC_APP==2){
                    let time=Date.now();
                    if(item._token&&time<item._tokenExpire){
                        return;
                    }
                    item._backpath='';
                    this.$store.dispatch(ACTIONS_TYPE.GO_APP,{authCode:item.AUTH_CODE}).then(d=>{
                        if(d.token){
                            // item._token= d.token.replace(/\+/g,'-').replace(/\//g,'_');
                            item._tokenExpire=time+15*60*1000;
                            item._backpath=d.backpath+d.token.replace(/\+/g,'-').replace(/\//g,'_');
                        }
                    }).catch(e=>{
                        console.log(e)
                    })
                }
                this.isLogin=true;
            },
            hide(){
                this.isLogin=false;
            },
            enterApp(){
                if(this.isMobile) return;
                if(this.appInfo.PUBLIC_APP==1){
                    window.open(this.appInfo.PUBLIC_HOME_PATH,'_blank')
                }else if(this.appInfo.PUBLIC_APP==2){
                    window.open(this.appInfo._backpath,'_blank')
                }
                this.hide();
            }
        }

    }
</script>

<style scoped>

</style>