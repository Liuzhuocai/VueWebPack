// const a=require('./index.html');
import '../assets/less/web_index.less';
import alert from './component/alert';
// import 'swiper/dist/css/swiper.css';
// import login from '../web/index-login.vue';

// import {Swiper,Pagination,Autoplay,EffectFade} from 'swiper/dist/js/swiper.esm';
import {Vue,Store} from '../stores/store';
import ajax, {hook} from '../libs/ajax';
// import ajax from '../ajaxPlugin';
import CONFIG from '../config';
import index from './index.vue';
import MUTATIONS_TYPE from "../stores/MutationsType";
Vue.use(ajax,{APIBASE:CONFIG.APIBASE,Store:Store});


if(!Store.getters.isLogined){
    /* IFDEBUG */
    window.location.href=CONFIG.BASE+'/portal.html';
    /* FIDEBUG*/

    /* IFTRUE_NODEBUG */
    window.location.href=CONFIG.BASE+'/web/portal.html';
    /* FITRUE_NODEBUG*/
}
// Swiper.use([Pagination,Autoplay,EffectFade]);
// const swiper = new Swiper('.swiper-container', {
//     centeredSlides: true,
//     loop:true,
//     speed:800,
//     effect:'fade',
//     // slidesPerView: 'auto',
//     pagination: {
//         el: '.swiper-pagination',
//         dynamicBullets: true,
//     },
//     autoplay: {
//         delay: 8000
//     },
//     fadeEffect:{
//         crossFade:true
//     }
// });
//
//
// window.showLogin=function(){
//     vue.showLogin();
// }
Vue.component( alert.name, alert )
Vue.config.silent=false;
const errors={};
const vue=new Vue({
    el:'#app',
    store:Store,
    // components:{alert},
    render:(h)=>h(index),
    data:{
        _alert:null
    },
    created(){
        let _self=this;
        hook.onError=function(e){
            if(e.R){
                if(e.R==528&&!errors[e.R]){
                    errors[e.R]=true;
                    _self.$store.commit(MUTATIONS_TYPE.UPDATE_USERINFO,null);
                    _self.$store.commit(MUTATIONS_TYPE.UPDATE_TOKEN,null);
                    _self.alert('密码已被修改,需要重新登录','重新登录',function(){
                        errors['528']=false
                        /* IFTRUE_NODEBUG */
                        window.location.href=CONFIG.BASE+'/web/portal.html';
                        /* FITRUE_NODEBUG */

                        /* IFDEBUG */
                        window.location.href=CONFIG.BASE+'/portal.html';
                        /* FIDEBUG */
                    });
                }
            }

        };
    },
    mounted(){
    },
    methods:{
        alert(text,btn,cb){
            if(!this.$data._alert){
               this.$data._alert=new (Vue.component('alert'));
               this.$data._alert.$mount();
            }
            this.$data._alert.text=text;
            this.$data._alert.btn=btn||'确定';
            this.$data._alert.cb=cb;
            this.$data._alert.show();
        }
    }

})
// console.log(Vue)