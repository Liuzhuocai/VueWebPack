<template>
    
    <div style="background-color:#fff;height: 100%;display: flex;flex-direction: column">
        <banner>
            <div style="color:rgb(107,104,133);font-size: 12px;cursor: pointer;" @click="back">返回首页</div>
        </banner>
        <div class="page-title-bar">
            <div class="title">
                修改密码
            </div>
        </div>
        <div class="changePassword">
            <div class="steps">
                <div class="step" :class="{active:step==1,complate:step>1}">
                    <span class="index">1</span>
                    输入旧密码
                </div>
                <div class="ico ico-arrow-line"></div>
                <div class="step" :class="{active:step==2,complate:step>2}">
                    <span class="index">2</span>
                    设置新密码
                </div>
                <div class="ico ico-arrow-line"></div>
                <div class="step" :class="{active:step==3}">
                    <span class="index" >3</span>
                    密码修改完成
                </div>
            </div>
            <div class="gap"></div>
            <div class="content" v-if="step==1">
                <div class="content-title">请输入旧密码</div>
                <div class="content-desc">请先输入旧密码以通过验证</div>
                <label class="login-input" style="margin-top: 32px">
                    <span class="input-label">旧密码</span>
                    <input type="password" class="input-content" v-model.trim="oldpw">
                    <div class="input-border"></div>
                </label>
                <div class="msg" :class="{error:msg1.type==1,ok:msg1.type==2}">{{msg1.msg}}</div>
                <div class="login-btn" style="margin-top: 32px" @click="checkpw">下一步</div>
            </div>
            <div class="content" v-if="step==2">
                <div class="content-title">设置新密码</div>
                <div class="content-desc">密码需是6-24位</div>
                <label class="login-input" style="margin-top: 32px">
                    <span class="input-label">新密码</span>
                    <input type="password" class="input-content" v-model.trim="newpw" >
                    <div class="input-border"></div>
                </label>
                <label class="login-input" style="margin-top: 16px">
                    <span class="input-label">确认新密码</span>
                    <input type="password" class="input-content" v-model.trim="confignewpw">
                    <div class="input-border"></div>
                </label>
                <div class="msg" :class="{error:msg2.type==1,ok:msg2.type==2}">{{msg2.msg}}</div>
                <div class="login-btn" style="margin-top: 32px" @click="changePW">下一步</div>
            </div>
            <div class="content" v-if="step==3" >
                <div class="content-title">密码修改完成</div>
                <div class="content-desc">密码已经修改完成,请使用新密码登录</div>
                <div class="ico ico-ok-100x100" style="width:320px;padding: 36px 0"></div>
                <div class="login-btn"  @click="back()">马上登录</div>
            </div>
        </div>
    </div>
</template>

<script>
    import CONFIG from '../../config';
    import banner from '../component/banner.vue';
    import sjcl from '../../libs/sjcl';
    import MUTATIONS_TYPE from '../../stores/MutationsType';
    window.document.body.style.backgroundColor='#fff';

    export default {
        name: "changePassword",
        components:{
            banner,

        },
        data(){
            return {
                step:1,
                oldpw:'',
                oldpw2:'',
                step1:false,
                step2:false,
                newpw:'',
                confignewpw:'',
                msg1:{
                    type:1,
                    msg:''
                },
                msg2:{
                    type:2,
                    msg:''
                }
            }
        },
        mounted(){
            // this.getMyAppList();
            // this.getPublicApp();
            // this.getPublicAppListBeforeLogin()
            // this.levelAppList=apps[this.currentLevel];
            // this.getAppList();
            // this.getAppList(1);
        },

        methods:{
            checkpw(type){
                
                if(this.oldpw&&this.oldpw2!=this.oldpw){
                    this.oldpw2=this.oldpw;
                    var spasswd  = sjcl.hash.sha256.hash(this.oldpw);
                    spasswd  = 'A'+sjcl.codec.hex.fromBits(spasswd);
                    var authdata = JSON.stringify({
                        opassword  : spasswd
                    });
                    this.$ajax('post','/api/user/verifyPassword',{_auth:sjcl.encrypt(this.$store.state.ServerPublicKeyForEncrypt,authdata)},{encrypt:false}).then(d=>{
                        // console.log(111)
                        // this.msg1.type=2;
                        // this.msg1.msg='验证成功';
                        this.step=2;
                        this.step1=true;

                    }).catch(e=>{
                        // console.log(e)
                        if(e.C){
                            this.msg1.msg=e.C;
                        }else{
                            this.msg1.msg=e.message;
                        }
                        this.msg1.type=1;
                      
                    })
                }
            },
            changePW(){
                if(this.newpw&&this.confignewpw){
                    if(this.newpw.length<6||this.newpw.length>24){
                        this.msg2.type=1;
                        this.msg2.msg='密码长度是6-24位';
                        return;
                    }else if(this.newpw!=this.confignewpw){
                        this.msg2.type=1;
                        this.msg2.msg='两次密码不匹配';
                        return;
                    }

                }else{
                    return;
                }
                var spasswd  = sjcl.hash.sha256.hash(this.oldpw);
                spasswd  = 'A'+sjcl.codec.hex.fromBits(spasswd);
                var npasswd=sjcl.hash.sha256.hash(this.newpw);
                npasswd='A'+sjcl.codec.hex.fromBits(npasswd);
                var authdata = JSON.stringify({
                    opassword  : spasswd,
                    npassword:npasswd
                });

                this.$ajax('post','/api/user/changePassword',{_auth:sjcl.encrypt(this.$store.state.ServerPublicKeyForEncrypt,authdata)},{encrypt:false}).then(d=>{
                    // console.log(111)
                    this.$store.commit(MUTATIONS_TYPE.UPDATE_USERINFO,null);
                    this.$store.commit(MUTATIONS_TYPE.UPDATE_TOKEN,null);
                    this.msg2.type=2;
                    this.msg2.msg='修改成功';
                    this.step2=true;
                    this.step=3;

                }).catch(e=>{
                    if(e.C){
                        this.msg2.msg=e.C;
                    }else{
                        this.msg2.msg=e.message;
                    }
                    this.msg2.type=1;
                })
            },
            back(){
                if(this.step==3){
                    /* IFTRUE_NODEBUG */
                    window.location.href=CONFIG.BASE+'/web/portal.html';
                    /* FITRUE_NODEBUG */

                    /* IFDEBUG */
                    window.location.href=CONFIG.BASE+'/portal.html';
                    /* FIDEBUG */
                }else{
                    /* IFTRUE_NODEBUG */
                    window.location.href=CONFIG.BASE+'/web/index.html';
                    /* FITRUE_NODEBUG */

                    /* IFDEBUG */
                    window.location.href=CONFIG.BASE+'/index.html';
                    /* FIDEBUG */
                }
            }
        }
    }
</script>

<style scoped type="less">
    /*import (reference) '../../../eduplatform_ui/platform-common/assets/less/web_base';*/
    @import (reference) '../../assets/less/web_base';
    .msg{
        padding: 4px ;
        box-sizing: border-box;
        &.error{
            color:red;
        }
        &.ok{
            color:green;
        }
    }
    .login-input{
        display: flex;
        //border-radius: 5px;
        border: 1px solid transparent;
        padding: 10px 16px;
        box-sizing: border-box;
        align-items: center;
        overflow: hidden;
        position: relative;
        margin-top: 12px;
        height: 42px;
        width:320px;
        &:focus{
            border-color: @color-blue1;
        }
        .input-label{
            flex:0 0 80px;
            .font-size-14;
            color:@color-gray3;
        }
        .input-content{
            flex:1 1 auto;
            width: 100%;
            .font-size-14;
            position: relative;
            z-index: 1;
            &:focus{
                & + .input-border{
                    border-color: @color-blue1;
                }
                
            }
        }
        
        //.cap-svg{
        //    position: relative;
        //    z-index: 1;
        //}
        .input-border{
            border-radius: 5px;
            border: 1px solid rgb(205,218,234);
            position: absolute;
            left:0;
            top:0;
            width:100%;
            box-sizing: border-box;
            height: 100%;
            z-index: 0;
        }
    }
    .login-btn{
        background-color: @color-blue1;
        text-align: center;
        .font-size-16;
        padding: 8px 0;
        color:#fff;
        border-radius: 5px;
        margin-top: 18px;
        cursor: pointer;
        width:320px
    }
    .changePassword{
        width: @indexViewWidth;
        margin: 42px auto 0;
        box-sizing: border-box;
        
        //padding: 42px 0;
        display: flex;
        .steps{
            flex:0 0 240px;
            padding-top: 24px;
        }
        .gap{
            
            height: 600px;
            width: 1px;
            background-color: rgb(230,230,230);
        }
        .content{
            padding-left: 64px;
            &-title{
                font-size: 16px;
                line-height: 64px;
            }
            &-desc{
                font-size: 12px;
                color:@color-gray3;
            }
        }
        .ico-arrow-line{
            margin-left: 36px;
        }
        .step{
            display: flex;
            padding: 0 24px ;
            box-sizing: border-box;
            align-items: center;
            color:@color-gray3;
            font-size: 14px;
            /*margin-bottom: 32px;*/
            height: 64px;
            &.complate{
                color:@color-blue1;
                .index{
                    background-color: rgb(230,244,255);
                }
            }
            &.active{
                color:@color-blue1;
                .index{
                    background-color: rgb(0,143,255);
                    color:#fff;
                }
                .index{
                    background-color: rgb(0,143,255);
                    color:#fff;
                }
            }
            .index{
                flex:0 0 32px;
                border-radius: 100px;
                height: 32px;
                background-color: rgb(230,230,230);
                line-height: 32px;
                text-align: center;
                margin-right: 8px;
                font-size: 16px;
                
            }
        }
    }
</style>