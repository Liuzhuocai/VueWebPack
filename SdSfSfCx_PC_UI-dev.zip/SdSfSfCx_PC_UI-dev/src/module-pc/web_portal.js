// const a=require('./index.html');
import '../assets/less/web_index.less';
// import 'swiper/dist/css/swiper.css';
// import login from '../web/index-login.vue';

// import {Swiper,Pagination,Autoplay,EffectFade} from 'swiper/dist/js/swiper.esm';
// import Vue from 'vue/dist/vue.runtime.esm';

import index from './portal.vue';
import {Vue,Store} from '../stores/store';
import ajax from '../libs/ajax';
// import ajax from '../ajaxPlugin';
import CONFIG from '../config';

Vue.use(ajax,{APIBASE:CONFIG.APIBASE,Store:Store});
// Vue.use(ajax, {APIBase: CONFIG.APIBASE})
// Swiper.use([Pagination,Autoplay,EffectFade]);
// const swiper = new Swiper('.swiper-container', {
//     centeredSlides: true,
//     loop:true,
//     speed:800,
//     effect:'fade',
//     // slidesPerView: 'auto',
//     pagination: {
//         el: '.swiper-pagination',
//         dynamicBullets: true,
//     },
//     autoplay: {
//         delay: 8000
//     },
//     fadeEffect:{
//         crossFade:true
//     }
// });
//
//
// window.showLogin=function(){
//     vue.showLogin();
// }
Vue.config.keyCodes={
    enter:13
}

const vue=new Vue({
    el:'#app',
    store:Store,
    render:(h)=>h(index),
    data:{
    },
    created(){
    },
    methods:{
    }

})
// console.log(Vue)