// const a=require('./index.html');
import '../assets/less/web_index.less';
// import 'swiper/dist/css/swiper.css';
// import login from '../web/index-login.vue';

// import {Swiper,Pagination,Autoplay,EffectFade} from 'swiper/dist/js/swiper.esm';
import {Vue,Store} from '../stores/store';
import ajax from '../libs/ajax';
// import ajax from '../ajaxPlugin';
import CONFIG from '../config';
import changepassword from './pages/changePassword.vue';
Vue.use(ajax,{APIBASE:CONFIG.APIBASE,Store:Store});



if(!Store.getters.isLogined){
    /* IFDEBUG */
    window.location.href=CONFIG.BASE+'/portal.html';
    /* FIDEBUG*/

    /* IFTRUE_NODEBUG */
    window.location.href=CONFIG.BASE+'/web/portal.html';
    /* FITRUE_NODEBUG*/
}
// Swiper.use([Pagination,Autoplay,EffectFade]);
// const swiper = new Swiper('.swiper-container', {
//     centeredSlides: true,
//     loop:true,
//     speed:800,
//     effect:'fade',
//     // slidesPerView: 'auto',
//     pagination: {
//         el: '.swiper-pagination',
//         dynamicBullets: true,
//     },
//     autoplay: {
//         delay: 8000
//     },
//     fadeEffect:{
//         crossFade:true
//     }
// });
//
//
// window.showLogin=function(){
//     vue.showLogin();
// }
Vue.config.silent=false;
const vue=new Vue({
    el:'#app',
    store:Store,
    render:(h)=>h(changepassword),
    data:{
    },
    methods:{

    }

})
// console.log(Vue)