import VueRouter from 'vue-router/dist/vue-router.esm';
import Vue from 'vue/dist/vue.runtime.esm';
//
// import {Store} from './store/store';
// import MUTATIONS_TYPE from './store/MutationsType';
// import CONFIG from './config';
//
// import directlyunder from './pages/directlyunder';
// import internal from './pages/internal';
// import employee from './pages/employee';
// import school from './pages/school';
// import others from './pages/others';
// import internal_add from './pages/internal-pages/add';
// import internal_edit from "./pages/internal-pages/editpage";
// import moresettinf from "./pages/Internaldepartments/moresettinf";
// import addstaffpage from "./pages/Staffcompany/addstaffpage";
// import staffedit from "./pages/Staffcompany/staffedit";
// import staffmore from "./pages/Staffcompany/staffmore";
//
// import subordinate from './pages/subordinate';

// function formatNav(route) {
//     const query = route.query;
//     let treeNameList = []
//     if (query.id) {
//         let tree = window.sessionStorage.getItem(CONFIG.APPID + 'INTERNAL_TREE');
//         if (tree) {
//             tree = JSON.parse(tree);
//             let node = tree[query.id];
//             while (node) {
//                 treeNameList.unshift({name: node.name, url: node.url, active: true});
//                 node = tree[node.parent];
//             }
//         }
//     }
//     return treeNameList;
// }
//

Vue.use(VueRouter);
const RoutesHash = {};
const Routes = [
    {
        path: '/index',
        alias:'/'
    },
    {
        name: '下属单位',
        path: '/subordinate',
        component: subordinate,
    },
    {
        name: '直属单位',
        path: '/directlyunder',
        component: directlyunder,
    },
    {
        name: '内设部门',
        path: '/internal',
        component: internal,
        meta: {
            formatNav: formatNav
        },
        children: [
            {
                name: '新增部门',
                path: 'add',
                component: internal_add,
                meta: {
                    formatNav: formatNav,
                    navPosition: 1
                }
            },
            {
                name: '编辑部门',
                path: 'edit',
                component: internal_add,
                meta: {
                    formatNav: formatNav,
                    navPosition: 1
                }
            },
        ]
    },

    {
        path: '/internal/add',
        component: internal_add,
        meta: {
            name: '新增部门'
        }
    },
    {
        path: '/internal/edit',
        component: internal_add,
        meta: {
            name: '编辑部门'
        }
    },
    {
        name: '本单位职员',
        path: '/employee',
        component: employee,
        meta: {
            formatNav: formatNav
        },
        children: [
            {
                name: '新增部门',
                path: 'addstaffpage',
                component: addstaffpage,
                meta: {
                    formatNav: formatNav,
                    navPosition: 1
                }
            },
            {
                name: '编辑部门',
                path: 'staffedit',
                component: addstaffpage,
                meta: {
                    formatNav: formatNav,
                    navPosition: 1
                }
            },
        ]
    },
    {
        path: '/employee/addstaffpage',
        component: addstaffpage,
        meta: {
            name: '新增部门'
        }
    },
    {
        path: '/employee/staffedit',
        component: addstaffpage,
        meta: {
            name: '编辑部门'
        }
    },
    {
        path: '/others',
        component: others,
        name: '其他部门'
    },
    {
        path: '/school',
        component: school,
        name: '直属学校'
    },
    {path: '/addstaffpage', component: addstaffpage},
    {path: '/staffmore', component: staffmore},
];

//为了面包屑而转化路由
function initRoutes(routes, parentRoute, rootRoutes) {
    for (let i of routes) {
        if (parentRoute) {
            i.meta = i.meta || {};
            i.meta.parent = parentRoute;
            if (i.path[0] == '/') {
                i.path = parentRoute.path + i.path;
            } else {
                i.path = parentRoute.path + '/' + i.path;
            }

        }
        RoutesHash[i.path] = i;
        rootRoutes.push(i);
        if (i.children && i.children.length) {
            initRoutes(i.children, i, rootRoutes);
            delete i.children;
        }
    }
    return rootRoutes;
}
const VueRoutes = new VueRouter({
    routes: initRoutes(Routes, null, []),
    routesHash: RoutesHash
});
// //处理面包屑的数据
// VueRoutes.afterEach((to, from) => {
//
//
//     if (to && to.matched.length) {
//         let bc = [{name: to.name, url: to.fullPath, active: true}];
//         if (to.meta && to.meta.formatNav) {
//             bc[0].url = to.path;
//             if (!to.meta.navPosition) {
//                 bc = bc.concat(to.meta.formatNav(to));
//             } else {
//                 bc = to.meta.formatNav(to).concat(bc);
//             }
//         }
//
//         while (to) {
//             if (to.meta && to.meta.parent) {
//                 to = to.meta.parent;
//                 bc.unshift({name: to.name, url: to.path, active: true});
//             } else {
//                 to = null;
//             }
//         }
//         bc[bc.length - 1].active = false;
//         Store.commit(MUTATIONS_TYPE.SET_BREADCRUMB, bc);
//
//     }
// });

export default VueRoutes;
