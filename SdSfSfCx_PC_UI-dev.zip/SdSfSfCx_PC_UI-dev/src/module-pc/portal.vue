<template>
    <div>
        <!--        <div id="lote" style="width:500px;height:500px"></div>-->
        <banner @click="click_banner"></banner>
        <swiper v-once></swiper>
        <div class="card public-service" >
            <div class="desc">
                <div class="desc-title">
                    <span class="desc-main-title">公众服务</span>
                    <div class="tools portal" style="cursor:not-allowed;color:#9e9e9e;border-color:#9e9e9e;background-color: #dadada;">
                        <div class="tool">更多</div>
                    </div>
                </div>
                <div class="desc-detail">
                    <p>大数据连着老百姓的衣食住行。教育领域利用互联网、大数据等信息技术，向公众开放公共信息资源，构建一个新型政务服务体系，真正把为民服务的最后一公里变成零距离。</p>
                    <p>我们运用大数据促进保障和改善民生，推进互联网+教育、努力推动教育领域公共服务均等化、普惠化、便利化，让老百姓有更多的便利感和切切实实的获得感，提升教育行政管理部门在包括公共服务在内的社会治理能力和水平。</p>
                </div>
            </div>
            <div class="gap"></div>
            <transition-group name="apps-animate" tag="div" class="apps" >
                <app v-for="(item,index) in publicAppList" :key="item.AUTH_CODE" :app-info="item" @app:click="goApp(item,1)"></app>
            </transition-group>
        </div>
        <div class="card sort-title">
            <span class="title-line"></span>
            <span class="title-text">标准化数据与平台接入服务</span>
            <span class="title-line"></span>
        </div>
        <div class="card services">
            <div class="service test" v-scroll="400">
                <div class="service-bg"></div>
                <div class="service-title">统一基础数据</div>
                <div class="service-desc">
                    <p>在教育部下发的国家学籍基础数据库上进行补充与扩展，全面覆盖各级教育管理机构、教学机构及教育行业相关从业者、参与者，制定基础数据标准规范及基础数据交换标准规范，建成省级统一的教育基础数据库，为后期的统一学情数据提供基础数据支持。</p>
                    <p>各级教育行政管理部门、学校可申请使用建成后的教育基础数据库，促进本单位教育管理信息化建设，发挥基础数据为教育、教学服务的能力。</p>
<!--                    <div class="service-detail-link">详情 <i class="ico ico-arrow-right"></i></div>-->
                </div>
            </div>
            <div class="service " v-scroll="400">
                <div class="service-bg"></div>
                <div class="service-title">统一学情数据</div>
                <div class="service-desc">
                    <p>利用大数据智能采集技术，对全省学情数据进行标准化之后的采集与管理，集中存储已有和将来的各类特色应用所产生的业务数据；建立学情数据交换接口，促进全省学情数据的共享交换。</p>
                    <p>后期将建立多维度的学情统计、构建分析模型对学情大数据进行深度挖掘，为教育决策者、管理者和其他参与者的个性化信息展示提供业务数据支撑。</p>
<!--                    <div class="service-detail-link">详情 <i class="ico ico-arrow-right"></i></div>-->
                </div>
            </div>
            <div class="service " v-scroll="400">
                <div class="service-bg"></div>
                <div class="service-title">统一应用接入</div>
                <div class="service-desc">
                    <p>制定统一的应用接入标准，集成省、市、县（区）及学校等已建/将建的业务系统，将分散、异构的应用和信息资源进行聚合。</p>
                    <p>在统一门户中进行集中管理和访问，实现各种应用系统的无缝接入和集成，提供一个支持信息访问、传递、以及协作的集成化环境，实现个性化业务应用的高效开发、集成、部署与管理。</p>
<!--                    <div class="service-detail-link">详情 <i class="ico ico-arrow-right"></i></div>-->
                </div>
            </div>
            
        </div>
        <div class="card sort-title">
            <span class="title-line"></span>
            <span class="title-text">创新信息时代新模式  服务教育教学全过程</span>
            <span class="title-line"></span>
        </div>
        <div class="modules policy-maker" v-scroll="400">
            <div class="card">
                <div class="bg"></div>
                <div class="modules-content">
                    <div class="module-title text-align-left">教育决策者</div>
                    <div class="module-descs">
                        <span class="module-desc">学情大数据模型</span>
                        <span class="module-desc">数据预警分析</span>
                        <span class="module-desc">区域教育发展事态</span>
                        <span class="module-desc">未来数据预测</span>
                        <span class="module-desc">多维度数据统计分析</span>
                        <span class="module-desc">教育发展监测与诊断</span>
                    </div>
                    <div class="button-entry big" @click="click_banner">进入</div>
                </div>
            </div>
        </div>
        <div class="modules admin" v-scroll="400">
            <div class="card">
                <div class="modules-content">
                    <div class="module-title">教育管理者</div>
                    <div class="module-descs">
                        <span class="module-desc">教育管理科学化</span><span class="module-desc">社会治理精准化</span><span class="module-desc">公共服务高效化</span>
                    </div>
                    <div class="button-entry" @click="click_banner">进入</div>
                </div>
                <div class="modules-content">
                    <div class="module-title middle">教学管理者</div>
                    <div class="module-descs">
                        <span class="module-desc">共享为中心的管理模式</span><span class="module-desc">教学资源合理配置</span><span class="module-desc">数据聚集与放大效应</span>
                    </div>
                    <div class="button-entry" @click="click_banner">进入</div>
                </div>
            </div>
        </div>
        <div class="modules common-user" v-scroll="400">
            <div class="card">
                <div class="modules-content">
                    <div class="module-title">教师</div>
                    <div class="module-descs">
                        <div class="module-descs-short">
                            <span class="module-desc">数字化</span><span class="module-desc">无纸化</span><span class="module-desc">智能化</span>
                        </div>
                        <div class="module-descs-short">
                            <span class="module-desc">互动性</span><span class="module-desc">时效性</span><span class="module-desc">交流性</span>
                        </div>
                        <div>
                            <span class="module-desc">充实教学内容</span><span class="module-desc">提升教学质量</span>
                        </div>
                    </div>
                    <div class="button-entry" @click="click_banner">进入</div>
                </div>
                <div class="modules-content">
                    <div class="module-title middle">学生</div>
                    <div class="module-descs">
                        <div >
                            <span class="module-desc">延展课堂</span><span class="module-desc">沟通交流</span>
                        </div>
                        <div >
                            <span class="module-desc">心得分享</span><span class="module-desc">主动学习</span>
                        </div>
                        <div>
                            <span class="module-desc">激发内驱力</span><span class="module-desc">享受成就感</span>
                        </div>
                    </div>
                    <div class="button-entry" @click="click_banner">进入</div>
                </div>
                <div class="modules-content">
                    <div class="module-title middle">家长</div>
                    <div class="module-descs">
                        <div>
                            <span class="module-desc">多渠道的信息获取</span>
                        </div>
                        <div>
                            <span class="module-desc display-block">深层次的数据加工</span>
                        </div>
                        <div>
                            <span class="module-desc display-block">及时准确的家校反馈</span>
                        </div>
                    </div>
                    <div class="button-entry" @click="click_banner">进入</div>
                </div>
            </div>
        </div>
        <div class="card sort-title" style="padding-bottom: 50px">
            <span class="title-line"></span>
            <span class="title-text">深化教育数据应用  优化教育治理能力</span>
            <span class="title-line"></span>
        </div>
        <div class="card functions" v-scroll="500">
            <div class="functions-content">
                <div class="function f1">
                    <div class="function-title">标准化</div>
                    <div class="function-desc">为消除在大数据应用过程中的<br>信息孤岛、机制壁垒提供了可能</div>
                </div>
                <div class="function f2">
                    <div class="function-title">数据服务</div>
                    <div class="function-desc">满足各级教育局、学校对基础数据<br>的需求，助力各级教育教学管理</div>
                </div>
                <div class="function f3">
                    <div class="function-title">应用仓库</div>
                    <div class="function-desc">模块化管理接入的各级应用，最终<br>形成覆盖所有从业人员的应用仓库</div>
                </div>
                <div class="function f4" >
                    <div class="function-title">个性化的工作平台</div>
                    <div class="function-desc">基于数据之间的联合分析，提供个性<br>化平台、实现千人千面的内容呈现</div>
                </div>
            </div>
            <div class="functions-content" >
                <div class="function f5">
                    <div class="function-title">边缘计算</div>
                    <div class="function-desc">就近提供最近端服务，<br>更快的网络服务响应</div>
                </div>
                <div class="function f6">
                    <div class="function-title">流动的信息</div>
                    <div class="function-desc">每一秒都有数据产生，每一秒都在<br>收集、分析、应用和管理数据，每<br>一秒都在彼此分享数据</div>
                </div>
                <div class="function f7">
                    <div class="function-title">数据链</div>
                    <div class="function-desc">串联起各级教育应用贡献的数据信息<br>形成完美的教育大数据链</div>
                </div>
                <div class="function f8">
                    <div class="function-title">安全的数据</div>
                    <div class="function-desc">数据中心机房、数据交换专用路由器<br>及5G专线等，提供数据本身及数据防<br>护的安全</div>
                </div>
            </div>
        </div>
        <footers v-once></footers>
        <login ref="login" @login:success="login"></login>
        <appEntrance ref="entrance"></appEntrance>
    </div>

</template>

<script>
    import banner from './component/banner.vue';
    import swiper from './component/swiper.vue';
    import footers from './component/footers.vue';
    import app from './component/app.vue';
    import login from './component/login.vue';
    import CONFIG from '../config';
    import ACTIONS_TYPE from '../stores/ActionsType';
    import appEntrance from './component/app-entrance';

    export default {
        name: "index",
        components:{
            banner,
            footers,
            swiper,
            app,
            login,
            appEntrance
        },
        directives:{
          scroll:{
              inserted(el,binding){
                  // console.log(el,binding)
                  let running=false;
                  let f=function(event){
                    if(!running&&window.scrollY+window.innerHeight>el.offsetTop+binding.value){
                        running=true;
                        el.className+=' animation';
                    }
                    // console.log(window.scrollY)
                    
                  
                  
                  }
                  
                  f();
                  if(!running) window.addEventListener('scroll', f);
                  
              }
          }
        },
        data(){
            return {
                publicAppList:[]
            }
        },
        mounted(){
            // this.$store.getters.decrypt('hleNzvOidcinVAqYw9vCo2gBizySHwspeB/kbiOjhVD/kGoEaPUquQMXlmmeHSfI396VLjeYXCCXuK3f5G8klpd4k+OpLg51uHLznpeDb/vgcRAqgMhX41EiIXesiw2M1J7ps5cN06SQHcH/drViynspghgRZNrTfVS5Gqc6wpNn+HHqFFaJaZHMA6rIP6nTuAygwHhKnLOw/sx5iF037Lz85qAKoQTWnS8tQxVe7sowsGqDHw+A8kTQbBxpx4PPm8/byE6J8aTdys+KRCxmBz2DakDAF+EuJrD1iOfTna30Ff9J8DrhIB7KKQFDmPiMQ/8W2b8qHLdCW7AaWSXhkt1T0TK9THjtjsHLhbk=');
            // console.log(11)
            // lottie.loadAnimation({
            //     container: document.getElementById('lote'), // the dom element that will contain the animation
            //     renderer: 'svg',
            //     loop: true,
            //     autoplay: true,
            //     path: '/assets/data.json' // the path to the animation json
            // });
            this.getPublicAppListBeforeLogin();
        },
        methods:{
            click_banner(){
                if(this.$store.getters.isLogined){
                    this.login();
                }else{
                    this.$refs.login.show()
                }
                
            },
            login(){
                /* IFTRUE_NODEBUG */
                window.location.href=CONFIG.BASE+'/web/index.html';
                /* FITRUE_NODEBUG */
                
                /* IFDEBUG */
                window.location.href=CONFIG.BASE+'/index.html';
                /* FIDEBUG */
            },
            getPublicAppListBeforeLogin(){
                this.$store.dispatch(ACTIONS_TYPE.GET_PUBLIC_APP,{count:8,page:1}).then(d=>{
                    var list=[];
                    if(d&&d.total){
                        for(var i of d.data){
                            i.state=1;
                        }
                        list=d.data;
                    }
                    var len=8-list.length;
                    for(let i =0;i<len;i++){
                        list.push({state:0,AUTH_CODE:'0'+i})
                    }
                    this.publicAppList=list;
                 
                })
            },
            goApp(item,type){

                this.$refs.entrance.show(item)
                
                // if(item.state!=3&&item.PUBLIC_HOME_PATH){
                //     window.open(item.PUBLIC_HOME_PATH,'_blank')
                // }
            }
        }
    }
</script>

<style scoped>

</style>