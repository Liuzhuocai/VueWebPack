// const a=require('./index.html');
import '../assets/less/web.less';
import Vue from 'vue/dist/vue.runtime.esm';
// import 'swiper/dist/css/swiper.css';
// import login from '../web/index-login.vue';

// import {Swiper,Pagination,Autoplay,EffectFade} from 'swiper/dist/js/swiper.esm';
// import Vue from 'vue/dist/vue.runtime.esm';

import index from './web.vue';
// import {Vue,Store} from '../store';
import ajax from '../libs/ajax';
import CONFIG from '../config';
Vue.use(ajax, {APIBASE: CONFIG.APIBASE})
// Swiper.use([Pagination,Autoplay,EffectFade]);
// const swiper = new Swiper('.swiper-container', {
//     centeredSlides: true,
//     loop:true,
//     speed:800,
//     effect:'fade',
//     // slidesPerView: 'auto',
//     pagination: {
//         el: '.swiper-pagination',
//         dynamicBullets: true,
//     },
//     autoplay: {
//         delay: 8000
//     },
//     fadeEffect:{
//         crossFade:true
//     }
// });
//
//
// window.showLogin=function(){
//     vue.showLogin();
// }

const vue=new Vue({
    el:'#app',
    render:(h)=>h(index),
})
// console.log(Vue)