<template>
    <div class="login" >
        <div class="welcome">欢迎使用</div>
        <div class="content" >
            <div class="loginFromApp" v-show="appName">
                <div class="tips">即将使用四川省教育厅公众信息服务平台统一认证登录</div>
                <div class="fromApp">{{appName}}</div>
            </div>
            <div>
                <label class="inputs">
                    <span class="label">帐号</span>
                    <input type="text" class="input" placeholder="6-24位字母或数字" minlength="6" maxlength="24" id="account" v-model.trim="account">
                    <span class="input-border"></span>
                </label>
                <label class="inputs">
                    <span class="label">密码</span>
                    <input type="password" class="input" placeholder="6-24位字母数字及特殊符号" minlength="6" maxlength="24" id="password" v-model.trim="password">
                    <span class="input-border"></span>
                </label>
                <label class="inputs">
                    <span class="label">验证码</span>
                    <input type="text" class="input capInput" placeholder="4位字母数字" maxlength="4" minlength="4" v-model.trim="cap">
                    <span class="input-border"></span>
                    <span class="cap" v-html="capSvg" @click="getCap"></span>
                    <span style="clear: both"></span>
                </label>
            </div>
            <div class="msg">{{msg}}</div>
        </div>
        <div class="btns">
            <div class="loginBtn" :disabled="!appName||!$data._ckey" @click="login">登录</div>
        </div>
    </div>

</template>

<script>


    import sso_index from '../mixins/sso_mixin';

    export default {
        name: "sso_web",
        mixins:[sso_index],
        data:function(){
          return {
              device:2//固定值PC2,手机1
          }
        },
        mounted(){
            this.getServerInfo();
        }
    }
</script>

<style scoped>

</style>