<template>
    <div>
        <div class="header">
            <div class="img"></div>
            <div class="content">
                <span class="mainTitle">统一认证登录</span>
                <span class="gap" v-show="appName"></span>
                <span class="subTitle">{{appName}}</span>
            </div>
        </div>
        <div class="login">
            <label class="inputs">
                <input type="text" class="input" placeholder="用户名 (6-24位字母或数字)" minlength="6" maxlength="24" id="account" v-model.trim="account">
                <span class="input-border"></span>
            </label>
            <label class="inputs">
                <input type="password" class="input" placeholder="密码 (6-24位字母数字及特殊符号)" minlength="6" maxlength="24" id="password" v-model.trim="password">
                <span class="input-border"></span>
            </label>
            <label class="inputs">
                <input type="text" class="input capInput" placeholder="验证码" maxlength="4" minlength="4" v-model.trim="cap">
                <span class="input-border"></span>
                <span class="cap" v-html="capSvg" @click="getCap"></span>
                <span style="clear: both"></span>
            </label>
            <div class="msg">{{msg}}</div>
            <div class="btns">
                <div class="loginBtn" :disabled="!appName||!$data._ckey" @click="login">登录</div>
            </div>
        </div>
    </div>

</template>

<script>
    import sso_index from '../mixins/sso_mixin';
    export default {
        name: "sso_mobile",
        mixins:[sso_index],
        props:{
            openId:{
                default:'',
                type:String
            },
            err:{
                default:'',
                type:String
            },
            auth_code:{
                default:'',
                type:String
            }
        },
        data:function(){
            return {
                device:1,//固定值PC2,手机1,
            }
        },
        mounted () {
            if(this.err){
                this.msg=this.err;
            }else{
                this.openid=this.openId;
                this.getServerInfo(this.auth_code)
            }


        }
    }
</script>
