import '../assets/less/mobile.less';
import Vue from 'vue/dist/vue.runtime.esm';
import ajax from '../libs/ajax';
import index from './mobile.vue';
import CONFIG from '../config';
import weixin from '../libs/weixin';

Vue.use(ajax,{APIBASE:CONFIG.APIBASE});

weixin.$ajax=Vue.$ajax;

if(weixin.isWeChat()){
    weixin.getWebCode(CONFIG.BASE+'/sso/mobile.html',true).then(d=>{
//     weixin.getWebCode('http://test.scxk750.com/jydsjweb/mobile.html',true).then(d=>{//内网测试用的地址
        if(d.phase==2){//登录阶段
            delete d.phase;//删除阶段的属性,传给UI
            if(d.cb){
                d.backpath=d.cb;
            }
            if(d.token||d.cb){//如果有token表示有openid,可以重定向
                var p='&';
                if(d.backpath.indexOf('?')<0){
                    p='?';
                }
                if(d.backpath.indexOf('token=')<0) {
                    p+='token=';
                }
                window.location.href=d.backpath+p+(d.token?d.token:'')+'&openid='+d.openid;
            }else{//没有token表示,没有绑定,需要登录进行绑定
                delete d.token;
                start({props:d});
            }

        }
    }).catch(e=>{
        start({props:{err:e}});
    });
}else{
    start({props:{openId:''}});
}

function start(params){
    new Vue({
        el:'#app',
        render:(h)=>h(index,params)
    });
}
