export default {
    INIT_COMPLATE                    : 'init_complate',
    UPDATE_CURRENT_STUDENT           : 'update_current_student',
    UPDATE_NEXT_STUDENT              : 'update_next_student',
    UPDATE_KEYS_FOR_ENCRYPT          : 'update_keys_for_encrypt',
    UPDATE_SECTION_GRADE             : 'update_section_grade',
    UPDATE_COLLECT_LIST              : 'update_collect_list',
    UPDATE_USERINFO: 'update_userinfo',
    // UPDATE_COLLECT_LIST_FILTER_CONFIG: 'update_collect_list_filter_config',
    UPDATE_TOKEN                     : 'update_token',
}