import Vuex from 'vuex/dist/vuex.esm';
import Vue from 'vue/dist/vue.runtime.esm';
import MUTATIONS_TYPE from './MutationsType';
import ACTIONS_TYPE from './ActionsType';
import sjcl from '../libs/sjcl.js';
import CONFIG from '../config';
Vue.use(Vuex);
// import SemesterStore from './store/semesterStore';
// import ClassroomStore from './store/classroomStore';
// import ClassStore from './store/classStore';
// import CourseStore from './store/courseStore';
const initData = function (store) {
    let token=window.sessionStorage.getItem('token');
    store.commit(MUTATIONS_TYPE.UPDATE_TOKEN, token);
    if(token){
        store.commit(MUTATIONS_TYPE.UPDATE_KEYS_FOR_ENCRYPT, window.sessionStorage.getItem('PKE'));
        let u=window.sessionStorage.getItem('U');
        if(u){
            store.commit(MUTATIONS_TYPE.UPDATE_USERINFO, JSON.parse(u));
        }

    }
    // var p = window.sessionStorage.getItem('P');
    // if (s && p) {
    //     store.commit(MUTATIONS_TYPE.UPDATE_COLLECT_LIST, JSON.parse(s))
    //     store.commit(MUTATIONS_TYPE.UPDATE_COLLECT_LIST_FILTER_PARAMS, JSON.parse(p))
    //     store.commit(MUTATIONS_TYPE.UPDATE_CURRENT_STUDENT, parseInt(window.sessionStorage.getItem('CI')))
    //     store.commit(MUTATIONS_TYPE.UPDATE_NEXT_STUDENT, parseInt(window.sessionStorage.getItem('NI')))
    // }
}

const store = new Vuex.Store({
    strict: false,
    plugins: [initData],
    state: {
        UserInfo:null,
        InstitutionName:'',
        Token: '',
        ServerPublicKeyForEncrypt:null,
        PublicKeyForEncrypt:null,
        // PrivateKeyForEncrypt:null,
        DHKey:null,
        // PrivateKeyForEncrypt:null,
    },

    getters: {
        isLogined(state,getters,rootState){
            return state.UserInfo&&state.Token;
        },
        encrypt(state){
            return (data)=>{
                if(state.DHKey) {
                    let aes_key = state.DHKey.substr (0, 32);//取前32位为aes秘钥
                    let iv = sjcl.codec.hex.toBits (state.DHKey.substr (-16));//取后16位为向量
                    let salt = sjcl.codec.hex.toBits (state.DHKey.substr (-32));//取后32位为盐
                    let result=sjcl.encrypt (aes_key, JSON.stringify(data), {mode: 'ccm', cipher: 'aes', iv: sjcl.codec.base64.fromBits(iv), salt: sjcl.codec.base64.fromBits(salt)});
                    return JSON.parse(result).ct;
                }
            };
        },
        decrypt(state){
            return (data)=>{
                if(state.DHKey) {
                    var aes_key = state.DHKey.substr (0, 32);//取前32位为aes秘钥
                    var iv = sjcl.codec.hex.toBits (state.DHKey.substr (-16));//取后16位为向量
                    var salt = sjcl.codec.hex.toBits (state.DHKey.substr (-32));//取后32位为盐
                    var scrypt = JSON.stringify ({
                        ct   : data,
                        mode: 'ccm',
                        cipher: 'aes',
                        salt: sjcl.codec.base64.fromBits(salt),
                        iv  : sjcl.codec.base64.fromBits(iv)
                    });
                    return sjcl.decrypt (aes_key, scrypt);
                }
            };
        }
    },

    mutations: {
        [MUTATIONS_TYPE.UPDATE_KEYS_FOR_ENCRYPT]: function (state, payload) {
            if (payload) {
                //生成服务器密钥对象
                state.ServerPublicKeyForEncrypt = new sjcl.ecc.elGamal.publicKey(sjcl.ecc.curves.k256,sjcl.codec.base64.toBits(payload));
                //公钥下来后生成自己的加密密钥对.
                let ckeypair = sjcl.ecc.elGamal.generateKeys(sjcl.ecc.curves.k256); // crypte pub and pri key
                let cpub = ckeypair.pub.get();
                //存下自己的公钥,用于发送给服务器解密,这个是字符串,不是对象
                state.PublicKeyForEncrypt = sjcl.codec.base64.fromBits(cpub.x.concat(cpub.y));
                //存下自己的私钥,用于自己的数据加密
                // state.PrivateKeyForEncrypt = ckeypair.sec;
                //使用服务器公钥和自己的私钥计算dh;
                state.DHKey=sjcl.codec.hex.fromBits(ckeypair.sec.dhJavaEc(state.ServerPublicKeyForEncrypt));
                window.sessionStorage.setItem('PKE', payload);
            } else {
                state.ServerPublicKeyForEncrypt=null;
                state.PublicKeyForEncrypt=null;
                // state.PrivateKeyForEncrypt=null;
                state.DHKey=null;
                state.Token=null;
                window.sessionStorage.removeItem('PKE');
            }

        },
        [MUTATIONS_TYPE.UPDATE_TOKEN]           : function (state, payload) {
            state.Token = payload;
            if (payload) {
                window.sessionStorage.setItem('token', payload);
            } else {
                state.ServerPublicKeyForEncrypt=null;
                state.PublicKeyForEncrypt=null;
                // state.PrivateKeyForEncrypt=null;
                state.DHKey=null;
                state.Token=null;
                window.sessionStorage.removeItem('token');
            }
        },
        [MUTATIONS_TYPE.UPDATE_USERINFO]: function (state, payload) {
            if (payload) {
                state.UserInfo=payload;
                window.sessionStorage.setItem('U', JSON.stringify(payload));
            } else {
                state.UserInfo=null;
                window.sessionStorage.removeItem('U');
            }
        },

    },
    actions: {
        [ACTIONS_TYPE.GET_SERVER_KEY_FOR_ENCRYPT](context, params) {
            if(context.state.ServerPublicKeyForEncrypt){
                return context.state.ServerPublicKeyForEncrypt;
            }
            return this._vm.$ajax('get','/api/auth/getCpk',null,{force:true,encrypt:false}).then(d=>{
                context.commit(MUTATIONS_TYPE.UPDATE_KEYS_FOR_ENCRYPT,d.cpk);
                return context.state.ServerPublicKeyForEncrypt;
            });
        },
        [ACTIONS_TYPE.GET_USERINFO](context, params) {
            if(context.state.UserInfo) return context.state.UserInfo;
            return this._vm.$ajax('post','/api/user/infoByToken',null).then(d=>{
                context.commit(MUTATIONS_TYPE.UPDATE_USERINFO,d);
                return context.state.UserInfo;
            });
        },
        [ACTIONS_TYPE.GO_APP](context, params) {
            if(!params.authCode){
                return Promise.reject('无效应用code');
            }
            params.device=params.device==CONFIG.DEVICE_MOBILE?CONFIG.DEVICE_MOBILE:CONFIG.DEVICE_DESKTOP;//PC2 mobile 1

            return this._vm.$ajax('post', '/api/auth/appListChangeToken/'+params.authCode,{deviceType:params.device},{encrypt:false});
        },
        [ACTIONS_TYPE.GET_PUBLIC_APP](context, params) {
            params.count=params.count||8;//PC2 mobile 1
            params.page=params.page||1;//PC2 mobile 1
            var data={
                pageNo:params.page||1,
                limit:params.count||8
            }
            return this._vm.$ajax('post', '/api/appManager/getPublicAppList',data,{force:true,encrypt:false});
        },
        // [ACTIONS_TYPE.GET_CLASS](context, params) {
        //     if (params && params.GradeID) {
        //         if (context.state.SchoolClass && context.state.SchoolClass[params.GradeID]) {
        //             return context.state.SchoolClass[params.GradeID];
        //         }
        //         return this._vm.$ajax('post', '/student/sclass', {GradeID: params.GradeID}).then(d => {
        //             if (d.length) {
        //                 d.unshift({ID: 0, NAME: '所有班级'})
        //                 context.state.SchoolClass[params.GradeID] = d;
        //                 return d;
        //             }
        //         }).catch(e => {
        //             console.log(e)
        //         })
        //     }
        //
        // },
        // [ACTIONS_TYPE.GET_STUDENT](context, params) {
        //     var data = {
        //         CurrentPage: params.CurrentPage,
        //         IsHavePic: params.IsHavePic,
        //         JYJD: params.JYJD,
        //         Page: params.Page || 200,
        //     }
        //     if (params.NAME) data.NAME = params.NAME;
        //     if (params.GRADE) data.GRADE = params.GRADE;
        //     if (params.ClassID) data.ClassID = params.ClassID;
        //     if (params.StartTime) data.StartTime = params.StartTime;
        //     if (params.EndTime) data.EndTime = params.EndTime;
        //     return this._vm.$ajax('post', '/student/list', data);
        // },
        // [ACTIONS_TYPE.NEXT_STUDENT](context, params) {
        //     var length = context.getters.CollectListLength;
        //     if (params.startIndex >= length || params.startIndex < 0) return;
        //     var item, current = -1, next = -1;
        //     for (var i = params.startIndex; i < length; i++) {
        //         item = context.state.CollectList[i];
        //         if (!item.stat && current < 0) {
        //             if (params.selectStudent == true) {
        //             } else {
        //                 current = i
        //                 context.commit(MUTATIONS_TYPE.UPDATE_CURRENT_STUDENT, current)
        //             }
        //         }
        //         if (current >= 0) {
        //             next = i + 1;
        //             if (next >= length) {
        //                 next = -1;
        //                 break;
        //             }
        //         } else {
        //             next = i;
        //         }
        //         item = context.state.CollectList[next];
        //         if (next != context.state.CurrentIndex && !item.stat) {
        //             break;
        //         }else{
        //             next=-1;
        //         }
        //
        //     }
        //     console.log(next)
        //     context.commit(MUTATIONS_TYPE.UPDATE_NEXT_STUDENT, next)
        // },
        // [ACTIONS_TYPE.UPLOAD_PHOTO](context, params) {
        //     if (params && params.STUID && params.PHOTO) {
        //         return this._vm.$ajax('post', '/upload/photo', {STUID: params.STUID, photo: params.PHOTO})
        //     }
        // },
        // [ACTIONS_TYPE.GET_SHARED_LIST](context, params) {
        //     if (context.state.CollectListFilterParams && context.state.CollectListFilterParams.JYJD) {
        //         var data = {};
        //         console.log(context.state.CollectListFilterParams)
        //         data.IsHavePic = context.state.CollectListFilterParams.IsHavePic;
        //         data.JYJD = context.state.CollectListFilterParams.JYJD;
        //         if (context.state.CollectListFilterParams.GRADE) data.GRADE = context.state.CollectListFilterParams.GRADE;
        //         if (context.state.CollectListFilterParams.ClassID) data.ClassID = context.state.CollectListFilterParams.ClassID;
        //         if (context.state.CollectListFilterParams.NAME) data.NAME = context.state.CollectListFilterParams.NAME;
        //         if (context.state.CollectListFilterParams.StartTime) data.StartTime = context.state.CollectListFilterParams.StartTime;
        //         if (context.state.CollectListFilterParams.EndTime) data.EndTime = context.state.CollectListFilterParams.EndTime;
        //         return this._vm.$ajax('post', '/download/share', data);
        //     }
        // },
        // [ACTIONS_TYPE.DOWNLOAD_PHOTO](context, params) {
        //     if (params && params.CLASSES) {
        //         return this._vm.$ajax('post', '/download/url', {ClassID: params.CLASSES})
        //     }
        // },
        // [ACTIONS_TYPE.EXPIRE_DOWNLOAD](context, params) {
        //     return this._vm.$ajax('post', '/download/urlexpire')
        // },
        // [ACTIONS_TYPE.CHECK_DOWNLOAD](context, params) {
        //     return this._vm.$ajax('post', '/download/geturl')
        // },
        // [ACTIONS_TYPE.BREAK](context, params) {
        //     context.commit(MUTATIONS_TYPE.UPDATE_COLLECT_LIST, [])
        //     context.commit(MUTATIONS_TYPE.UPDATE_COLLECT_LIST_FILTER_PARAMS, {})
        //     context.commit(MUTATIONS_TYPE.UPDATE_CURRENT_STUDENT, -1)
        //     context.commit(MUTATIONS_TYPE.UPDATE_NEXT_STUDENT, -1)
        // },
    },
})


export {store as Store,Vue};
// exports.Vue=Vue;