export default {
    GET_SERVER_KEY_FOR_ENCRYPT: 'get_server_key_for_encrypt',
    GET_USERINFO: 'get_userinfo',
    GO_APP: 'go_app',
    GET_PUBLIC_APP:'get_public_app'
}