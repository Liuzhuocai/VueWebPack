
// import ajax from '../libs/ajax';
import sjcl from '../libs/sjcl.js';
import querystring from 'querystring';
// console.log(sjcl)
export default {
    data:function(){
        return {
            capSvg:'',
            capHash:'',
            capSign:'',
            msg:'',

            account:'',
            password:'',
            cap:'',

            openid:'',

            appName:'',
            appCode:null,
            _ckey:null,



        };
    },
    mounted(){
        // this.getServerInfo();
    },
    methods:{
        getServerInfo(code){
            if(!code){
                var r=querystring.parse(window.location.search.substr(1));
                if(r.auth_code){
                    code=r.auth_code;
                }else{
                    this.msg='没有应用授权码,无法进行登录';
                    return;
                }
            }

            this.appCode=code;
            this.$ajax('post','/api/auth/getCpkAndApp',{'auth_code':this.appCode},{force:true,encrypt:false}).then(d=>{
                this.$data._ckey = new sjcl.ecc.elGamal.publicKey(sjcl.ecc.curves.k256,sjcl.codec.base64.toBits(d.cpk));
                this.appName=d.app.NAME;
                this.getCap();
            }).catch(e=>{
                if(e.R){
                    this.msg=e.C;
                }else{
                    this.msg=e;
                }

            });
            // }
        },
        getCap:function(){
            this.$ajax('get','/v1/auth/captcha',null,{force:true,encrypt:false}).then(d=>{
                if(d.data){
                    this.capSvg=d.data;
                    this.capHash=d.hash;
                    this.capSign=d.sign;
                }
            }).catch(e=>{
                this.msg=e;
            });
        },
        login(){

            if(!this.$data._ckey||!this.appName){
                return;
            }
            this.msg='';
            if(this.account.length<6||this.account.length>24){
                this.msg='帐号长度应该是6-24位';
            }else if(/[^0-9A-Za-z_@\-\.]/.test(this.account)){
                this.msg='帐号应该由字母数字及_@-.特殊符号组成';
            }else if(this.password.length<6||this.password.length>24){
                this.msg='密码长度应该是6-24位';
            }else if(this.cap.length!=4){
                this.msg='验证码长度应该是4位字母数字';
            }
            if(this.msg) return;
            let cap=this.cap.toUpperCase();
            var scap = sjcl.hash.sha256.hash(cap);
            scap = sjcl.codec.base64.fromBits(scap);
            if (scap != this.capHash) {
                this.msg='验证码错误';
                return this.getCap();
            }
            var spasswd  ='A'+sjcl.codec.hex.fromBits(sjcl.hash.sha256.hash(this.password));
            var authdata = JSON.stringify({
                login   : this.account,
                passwd  : spasswd,
                captcha : cap,
                deviceType : this.device  //如果是手机 该参数写:1  PC该参数写:2
            });
            // encrypt and pack
            this.$ajax('post','/v1/auth/login/'+this.appCode,{_auth:sjcl.encrypt(this.$data._ckey,authdata),_capsign:this.capSign},{force:true,encrypt:false,headers:{openid:this.openid}}).then(d=>{
                if(d.token){
                    let mytoken = d.token.replace(/\+/g,'-').replace(/\//g,'_');
                    window.location.href = d.backpath +  mytoken;
                }
            }).catch(e=>{
                if(e.R){
                    this.msg=e.C;
                }else{
                    this.msg=e;
                }
            });
        }

    }
};