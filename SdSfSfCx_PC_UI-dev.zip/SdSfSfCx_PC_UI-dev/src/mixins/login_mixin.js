
import sjcl from '../libs/sjcl';
import ACTIONS_TYPE from '../stores/ActionsType';
import MUTATIONS_TYPE from '../stores/MutationsType';





// console.log(sjcl)
export default {
    data:function(){
        return {
            capImg:'',
            cap:'',
            account:'',
            password:'',
            capHash:'',
            capSign:'',
            msg:'',
            openid:'',
            _isLoginning:false
        };
    },
    mounted(){
        // this.getServerInfo();
    },
    methods:{
        login(){
            if(this.$data._isLoginning) return;
            var cap=this.cap.toUpperCase();
            this.msg='';
            if(this.account.length<6||this.account.length>24){
                this.msg='帐号长度应该是6-24位';
            }else if(/[^0-9A-Za-z_@\-\.]+/g.test(this.account)){
                this.msg='帐号应该由字母数字及_@-.特殊符号组成';
            }else if(this.password.length<6||this.password.length>24){
                this.msg='密码长度应该是6-24位';
            }else if(cap.length!=4){
                this.msg='验证码长度应该是4位字母数字';
            }
            if(this.msg){
                return Promise.reject(this.msg);
            }
            var scap = sjcl.hash.sha256.hash(cap);
            scap = sjcl.codec.base64.fromBits(scap);
            if (scap != this.capHash) {
                this.getCap();
                this.msg='验证码错误';
                return Promise.reject(this.msg);
            }
            var spasswd  = sjcl.hash.sha256.hash(this.password);
            spasswd  = 'A'+sjcl.codec.hex.fromBits(spasswd);
            var authdata = JSON.stringify({
                login   : this.account,
                passwd  : spasswd,
                captcha : cap
            });

            this.msg='正在登陆...';
            return this.$store.dispatch(ACTIONS_TYPE.GET_SERVER_KEY_FOR_ENCRYPT).then(d=>{
                authdata = sjcl.encrypt(d,authdata);
                authdata = {
                    _auth    : authdata,
                    _capsign : this.capSign,
                };
                return this.$ajax('post','/api/auth/login/',authdata,{force:true,encrypt:false,headers:{openid:this.openid}});
            }).then(d=>{
                this.msg='登录成功，正在获取用户信息...';
                // this.$store.commit(MUTATIONS_TYPE.UPDATE_TOKEN,d.token.replace(/\+/g,'-').replace(/\//g,'_'))
                this.$store.commit(MUTATIONS_TYPE.UPDATE_TOKEN,d.token)
                return this.$ajax('post','/api/user/infoByToken',null);
            }).then(d=>{
                this.$store.commit(MUTATIONS_TYPE.UPDATE_USERINFO,d)
                this.$emit('login:success');
            }).catch(e=>{
                if(e.R){
                    this.msg=e.R+'-'+(e.C||'未知错误');
                }else{
                    this.msg=e;
                }
                return Promise.reject(this.msg);
            }).finally(()=>{
                this.$data._isLoginning=false;
            });
        },
        getCap(){
            this.$ajax('get','/api/auth/captcha',null,{force:true,encrypt:false}).then(d=>{
                this.capImg=d.data;
                this.capHash=d.hash;
                this.capSign=d.sign;
            }).catch(e=>{
                this.msg=e;
                // console.log(e)
            });
        },

    }
};